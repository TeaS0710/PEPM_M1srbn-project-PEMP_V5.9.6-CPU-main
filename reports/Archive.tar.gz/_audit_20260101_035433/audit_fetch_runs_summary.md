# Audit des runs de scraping (fetch/crawl)

- Root: `/home/teas/programmes/PEPM_M1srbn-project-PEMP_V5.9.4-CPU-main/corpus_full(DANGER)/fetch/xml_update`
- Pattern: `crawl-*`
- Runs: **20**
- Date: `20260101_035433`

## Résumé (par run)

| Run | Jobs | 200 | Err | Refetch | Pages MB | Store MB | Flags |
|---|---:|---:|---:|---:|---:|---:|---|
| crawl-actionfrancaise-20251003_000000 | 41688 | 38270 | 0 | 12245 | 1236.5 | 4.3 | REFETCH_MANY |
| crawl-cce-full-20250927_234505 | 97 | 97 | 0 | 210 | 8.0 | 0.1 | REFETCH_MANY |
| crawl-contretemps-20250928_003525 | 5318 | 5054 | 0 | 48344 | 1159.0 | 0.9 | REFETCH_MANY |
| crawl-eco-full-20250928_000354 | 727 | 725 | 0 | 3832 | 97.1 | 0.2 | REFETCH_MANY |
| crawl-er-20251003_231234 | 554581 | 463030 | 2014 | 63937 | 6049.3 | 55.3 |  |
| crawl-fdesouche-20251003_231247 | 199291 | 194625 | 23 | 26726 | 5363.6 | 59.7 |  |
| crawl-hut-fr-20251003_231255 | 2127 | 2121 | 0 | 2622 | 257.1 | 0.6 | REFETCH_MANY |
| crawl-initiative-communiste-20250928_003234 | 32675 | 32456 | 0 | 114627 | 4589.6 | 7.0 | REFETCH_MANY |
| crawl-jean-jaures-20250928_003513 | 33655 | 32177 | 0 | 36243 | 2790.5 | 19.1 | VERY_LARGE_BODY(>10MB),REFETCH_MANY |
| crawl-lfi-full-20250928_000133 | 11936 | 11702 | 0 | 9359 | 1215.5 | 2.0 | REFETCH_MANY |
| crawl-lo-full-20250928_001323 | 70752 | 70698 | 0 | 171298 | 3022.1 | 10.7 | REFETCH_MANY |
| crawl-lr-full-20250928_001404 | 889 | 882 | 0 | 6259 | 209.2 | 0.3 | REFETCH_MANY |
| crawl-lundi-am-20250928_003202 | 7233 | 7169 | 0 | 36672 | 1137.9 | 0.9 | REFETCH_MANY |
| crawl-npa-full-20250928_001251 | 12656 | 12259 | 0 | 14350 | 479.1 | 5.4 | REFETCH_MANY |
| crawl-polemia-20250928_003004 | 10950 | 10885 | 1 | 32208 | 1122.0 | 0.7 | REFETCH_MANY |
| crawl-ps-full-20250928_000302 | 2054 | 1405 | 5 | 4104 | 118.0 | 0.5 | HTTP_FAIL_MANY,REFETCH_MANY |
| crawl-revperm-20250928_003219 | 54977 | 53572 | 1 | 189639 | 5091.6 | 5.9 | REFETCH_MANY |
| crawl-rn-full-20250927_234616 | 648 | 646 | 0 | 219 | 22.4 | 0.2 | REFETCH_MANY |
| crawl-terranova-20250928_003520 | 3159 | 2872 | 0 | 11118 | 248.4 | 0.6 | REFETCH_MANY |
| crawl-ucl-20250928_003510 | 22564 | 21966 | 0 | 14811 | 419.4 | 2.4 | REFETCH_MANY |

## Détails

- Un JSON par run est écrit dans `per_run/*.json` (inclut top status codes, top raisons de refetch, etc.).
- Le CSV complet est `audit_fetch_runs_summary.csv`.
