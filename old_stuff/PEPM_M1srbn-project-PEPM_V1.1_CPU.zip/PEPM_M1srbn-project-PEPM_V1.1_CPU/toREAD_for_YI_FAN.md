# Projet PEPM By Yi Fan && Adrien
# Guide « Yi_Fan » du projet

---

**SI TU NE COMPREND PAS UTULISE CHATGPT OU DEEPSEEK**

## 1) En deux phrases

Ce dépôt entraîne un **classifieur de textes en français** (spaCy) à partir d’un corpus **TEI** produit par des crawls web. Le pipeline va de **HTML → TEI → TSV → DocBin (.spacy) → entraînement → évaluation**, avec un soin particulier sur l’**équilibrage des classes** et la **robustesse CPU/RAM**.

---

## 2) À quoi ça ressemble (arborescence)

```
data/
  raw/corpus/corpus.xml     # TEI consolidé (tous les docs)
  interim/...               # splits et dérivés temporaires
  processed/spacy/          # .spacy (DocBin) + labels.json
logs/                       # journaux d'exécution
models/                     # modèles entraînés (model-best / model-last)
reports/                    # métriques, rapports
scripts/                    # outils: prépa, train, éval
Makefile                    # recettes reproductibles
README.md                   # doc étendue
```

Cette structure « raw / interim / processed / models / reports » est pensée pour la **reproductibilité** et l’hygiène de projet.

---

## 3) Notions Importantes (les tâches)

* **Exo (idéologie binaire)** : classer les textes en **gauche** / **droite** via un mappage `ideology.yml`.
* **Endo (multi-classe “partis”)** : classer selon des catégories issues du champ **`crawl`** (multi-classe).

La **vérité terrain** est le jeu **JOB** (test), **intouchable** : on n’y fait **aucun équilibrage** ni « nettoyage » orienté résultat. On n’équilibre que **TRAIN**.

---

## 4) Visuel du Pipe

```
[HTML (crawls)]
      └─(extraction + dédup)→ [TEI: data/raw/corpus/corpus.xml]
                                 └─(split 80/20, filtres, map labels)→ [TSV: train.tsv + job.tsv]
                                                                   └─→ [DocBin .spacy + labels.json]
                                                                                 └─→ [Train spaCy]
                                                                                 └─→ [Évaluation + rapports]
```

* **Extraction TEI** : lecture de tous les crawls, texte + métadonnées, **déduplication** des textes (MD5), et écriture d’un **unique** `teiCorpus.xml`.
* **Split TEI → TSV** : 80/20 **stratifié** par label, **TRAIN** équilibrable (options), **JOB** laissé tel quel. Le label vient du champ **`crawl`** ou d’un **mappage** (idéologie).
* **TSV → DocBin** : conversion en binaire spaCy + écriture d’un **`labels.json`** ordonné (stabilité des runs).

---

## 5) Les trois stratégies d’équilibrage (sur TRAIN uniquement)

1. **`cap_docs`** : plafonne le **nombre de documents** par label (souvent couplé à `--oversample` pour remonter les classes rares).
2. **`cap_tokens`** : plafonne le **nombre de tokens** par label – utile quand les longueurs de textes varient beaucoup.
3. **`alpha_total`** : **échantillonnage tempéré** vers une taille totale `total` avec des quotas ∝ `count(label)^alpha` (0<α≤1).
   Astuce : commencez **sans équilibrage**, lisez les **comptes par label**, récupérez Nmax, puis relancez avec **`cap_docs + oversample`** (cap = Nmax).

---

## 6) CPU, threads, RAM : garder la machine fluide

* **Limiter les threads BLAS** (env): `OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `MKL_NUM_THREADS`, `NUMEXPR_NUM_THREADS`.
* **`n_process` / `--workers`**: mettez une valeur raisonnable (souvent ≤ nb de cœurs utiles).
* **Mémoire** : utiliser le **sharding** (ex. 10k–25k docs par shard) pour les .spacy, réduire **`--max-tokens`** si besoin.
* **GPU (AMD/ROCm)** : volontairement **en pause** (instabilité CuPy/ROCm) → on standardise le **mode CPU** robuste.

---

## 7) Commandes « qu’on tape vraiment »

### 7.1 Check rapide de l’environnement

```bash
make sysinfo        # infos système
make check          # mini pipeline end-to-end (échantillon), détecte les gros soucis
```

Le check journalise, vérifie les libs, fait un petit split et entraîne 1 epoch pour valider le pipeline.

### 7.2 Idéologie (binaire) — parcours rapide (quick)

```bash
make prepare_ideo_quick   # TEI -> TSV -> DocBin (train/job shardés) + labels.json
make train_ideo_quick     # entraînement CPU (cnn par défaut)
make eval_ideo_quick      # évaluation spaCy -> reports/ideo_quick_metrics.json
```

Les **labels** viennent du mapping `ideology.yml` (gauche/droite).

### 7.3 « Partis » (endo, multi-classe) — parcours rapide

```bash
make prepare_quick
make train_quick
make eval_quick
```

TSV avec colonnes typiques : `id`, `label`, `crawl`, `text`. (JOB reste non-équilibré.)

### 7.4 Variantes « full » (plus de tokens / plus long)

```bash
make prepare_ideo_full && make train_ideo_full && make eval_ideo_full
make prepare_full      && make train_full      && make eval_full
```

### 7.5 Évaluation « streaming » (RAM-friendly, gros JOB)

```bash
make eval_ideo_quick_stream
make eval_ideo_full_stream
```

Ces cibles utilisent un script qui **streame** les exemples et évite les gros pics mémoire.

---

## 8) Ce que fait l’entraînement (sous le capot)

Le script de train **génère** une config spaCy, active un **textcat** à **classes exclusives** (multiclasse), fixe le **batcher compounding** (`start→stop`), le **dropout**, la **seed** et la **fréquence d’éval**. Il peut initialiser les **labels** à partir de `labels.json` si fourni.

**Deux architectures** prêtes à l’emploi :

* `arch=cnn` (*tok2vec/CNN*), baseline CPU robuste ;
* `arch=bow` (*TextCatBOW*), plus simple pour des démos.

---

## 9) Lire les métriques (sans se tromper)

* **Accuracy** monte avec la classe majoritaire (dangereusement trompeur si JOB est très déséquilibré).
* **Macro-F1** fait la moyenne **par classe** (bon thermomètre d’équité).
* **Weighted-F1** pèse par la taille de classe (souvent proche de l’accuracy si la minoritaire est négligée).
* **Matrice de confusion** : regardez qui confond quoi (brut + normalisée).

---

## 10) Dépannage express (FAQ)

* **`[E867] textcat requiert ≥ 2 labels`**
  Votre train/job n’a **qu’une seule** classe (ou `labels.json` n’en expose qu’une).
  ➜ Ajoutez une 2ᵉ classe (binaire **LABEL**/**NOT_LABEL**) **ou** passez en `textcat_multilabel`. (Concrètement : assurez-vous que vos TSV ont bien **≥ 2 labels distincts** et que `labels.json` les liste tous.)

* **`[E1014] Error loading DocBin` / « pas un .spacy »**
  Vous pointez vers **un dossier** au lieu d’un **fichier .spacy**, ou inversement. Entraînez/évaluez **sur un fichier** OU **sur un dossier de shards** — pas mélange. (Les cibles “full/quick” du Makefile ont été pensées dans ce sens.)

* **OOM / lenteur / machine qui souffle**
  Baissez `--max-tokens`, utilisez le **sharding** (`--shard-size 10_000` ou 25k), réduisez `--workers` et **plafonnez** les threads BLAS (variables d’env).

* **Résultats « bizarres » (accuracy OK, Macro-F1 nul)**
  JOB très **déséquilibré** → commencez par **équilibrer TRAIN** (voir §5), vérifiez la **qualité d’extraction**, la **langue**, et évitez une troncature trop agressive (`max_tokens`).

---

## 11) Pourquoi ces choix d’ingénierie ?

* **TEI unique** : déduplication simple et métadonnées homogènes.
* **JOB “intouchable”** : refléter **le monde réel** (même s’il est déséquilibré).
* **Équilibrage TRAIN** : améliorer l’apprentissage **sans biaiser l’évaluation**.
* **DocBin** : format compact & rapide pour spaCy.
* **Makefile** : industrialise les runs, centralise les paramètres.

---

## 12) Mini « pas à pas » pour un premier run

1. **Vérifier l’env** : `make sysinfo && make check`
2. **Idéologie rapide** :

   ```bash
   make prepare_ideo_quick
   make train_ideo_quick
   make eval_ideo_quick   # -> reports/ideo_quick_metrics.json
   ```
3. **Lire macro-F1** et la matrice de confusion ; si faible → revoir §5 (équilibrage), §6 (RAM/threads), §9 (lecture métriques).
