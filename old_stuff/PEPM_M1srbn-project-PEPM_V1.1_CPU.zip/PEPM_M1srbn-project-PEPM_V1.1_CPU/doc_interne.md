# Documentation interne — Pipeline PEPM (spaCy textcat)

Ce document décrit **le fonctionnement complet du pipeline** (de l’extraction TEI à l’entraînement/évaluation spaCy), les **scripts**, les **cibles Makefile**, et des **recettes** prêtes à l’emploi, en mode **CPU** et **multilingue “passe-plat”** (LANG=`xx`).

---

## 1) Vue d’ensemble

**But** : classer des textes (ex. *idéologie* “droite/gauche”) à partir d’un corpus TEI consolidé.

**Chaîne de traitement :**

1. *(optionnel)* Extraction web → **corpus TEI** unique (`corpus.xml`).
2. **Split + équilibrage TRAIN** → `train.tsv` / `job.tsv` (+ `corpus_train.xml` / `corpus_job.xml`).
3. **Conversion TSV → DocBin spaCy** (shards `.spacy` + `labels.json`).
4. **Entraînement spaCy** (arch=`cnn` par défaut) → `models/.../model-best|last`.
5. **Évaluation**: `spacy evaluate` et/ou **éval streaming** (faible RAM) → `reports/*.json`.

---

## 2) Arborescence (conseillée)

```
data/
  raw/corpus/corpus.xml
  interim/ideo/           # train.tsv, job.tsv, corpus_*.xml…
  processed/spacy/        # *.spacy, *_labels.json
models/
reports/
logs/
scripts/
Makefile
```

Les **journaux** sont stockés sous `logs/` avec un niveau INFO/DEBUG (et copie console). Des **seeds** stables et des versions fixées facilitent la reproductibilité.

---

## 3) Scripts & responsabilités

### 3.1 Extraction TEI (optionnel)

`scripts/tei_corpus_mp.py` : scanne les crawls, extrait, **déduplique** (MD5 du texte), et écrit un **TEI** consolidé (`for_txm/corpus.xml`). Support **multi-process**, filtres (langue via fastText si modèle présent), options IO rapides (isal).

### 3.2 Split & équilibrage (TRAIN seul)

`scripts/tei_to_train_job.py` :

* Lit `corpus.xml` en **streaming** (iterparse), multi-process, filtre par **min-chars**/**max-tokens**.
* Produit `train.tsv`, `job.tsv` (+ **sous-corpus TEI** *train*/*job*).
* **Équilibrages** disponibles pour **TRAIN uniquement** :

  * `cap_docs` (+ `--oversample`) : duplique la minoritaire **sans couper** la majoritaire.
  * `cap_tokens` : plafonne par **tokens**.
  * `alpha_total` : quotas ∝ `count(label)^α` pour une taille **totale** visée (*lisse* sans égaliser brutalement).

Arguments utiles : `--label-field {crawl|ideology}` + `--ideology-map` (YAML obligatoire en mode *ideology*).

### 3.3 DocBin spaCy (TSV → .spacy)

`scripts/build_spacy_corpus.py` :

* Lit un TSV (`text`, `label`), gère **alias** de colonnes.
* Option `--balance oversample` (ré-échantillonnage simple), **limitation stratifiée** (`--limit`) et **sharding** `.spacy` via `--shard-size`. Écrit aussi `*_labels.json`.

### 3.4 Entraînement spaCy (CPU)

`scripts/spacy_train_core.py` :

* Génère une **config auto** via `init_config(...)` avec pipeline **`textcat`** ; si `arch=cnn` et `optimize="accuracy"`, spaCy ajoute **`tok2vec`** → pipeline effectif `['tok2vec','textcat']`. Les **vectors statiques** sont désactivés par défaut.
* Force **classes exclusives** pour BOW/Ensemble (TextCat BOW/linear).
* Fige les **seeds** (`fix_random_seed`, `PYTHONHASHSEED`).
* Batching **compounding**, fréquence d’éval, etc., sont paramétrés dans la config écrite (`auto_config.cfg`).

**Arch** :

* `arch=bow` → `optimize="efficiency"` (rapide, baseline).
* `arch=cnn` → `optimize="accuracy"`, avec `tok2vec`.

### 3.5 Évaluation

* **Standard** : `spacy evaluate` → JSON dans `reports/`.
* **Streaming (faible RAM)** : `scripts/eval_textcat_stream.py` lit le **TSV** en **chunks**, infère avec `nlp.pipe`, et écrit un **`classification_report`** scikit-learn (macro/weighted F1, etc.).

---

## 4) Makefile — cibles clés & variables

### Cibles (extraits)

* `setup` : installe `requirements`, télécharge le **modèle multilingue** `xx_sent_ud_sm` (tokenisation/segmentation générique).
* `prepare_ideo_quick|full` : split + TSV/TEI selon **idéologie**.
* `train_ideo_quick|full` : entraînement.
* `eval_ideo_quick|full` : évaluation.
* `eval_ideo_*_stream` : évaluation **streaming**.
* `clean` : ménage.

### Variables importantes

* **Multilingue passe-plat** : `LANG=xx` (Makefile le positionne par défaut dans votre extrait).
* **Équilibrage** : `BALANCE={none|cap_docs|cap_tokens|alpha_total}` + `CAP_PER_LABEL|CAP_TOKENS|OVERSAMPLE|ALPHA|TOTAL`.
* **Limites & tailles** : `IDEO_QUICK_TSV_LIMIT`, `JOB_LIMIT_IDEO_QUICK`, `*_MAX_TOKENS`, `*_BATCH`, `*_SHARD`.
* **Perf CPU** : `WORKERS`, `OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `MKL_NUM_THREADS`, `NUMEXPR_NUM_THREADS`.
* **Reproductibilité** : `SEED`.

> Astuce : gardez **threads BLAS modestes** (1–4) si vous parallélisez côté spaCy/process pour éviter la sur-contention. Le README évoque de **plafonner les threads BLAS** en cas de lenteur/OOM.

---

## 5) Recettes prêtes à l’emploi

### 5.1 Démarrage “SAFE” (idéologie, multilingue)

```bash
# 0) Environnement
make clean && make setup && make sysinfo

# 1) Préparation sans équilibrage (échantillon limité)
make LANG=xx IDEO_QUICK_TSV_LIMIT=20000 prepare_ideo_quick

# 2) Entraînement CPU, checkpoints fréquents
make LANG=xx EVAL_FREQ=50 EPOCHS_IDEO_QUICK=10 train_ideo_quick

# 3) Évaluation (stratifiée, faible RAM) + variante streaming
make JOB_LIMIT_IDEO_QUICK=1000 eval_ideo_quick
make JOB_LIMIT_IDEO_QUICK=1000 eval_ideo_quick_stream
```

Les séquences d’exploitation et le mode **RAM-friendly** (JOB limité, streaming) sont également présentés dans le rapport technique.

### 5.2 Équilibrage TRAIN “sans coupe”

```bash
# Lire Nmax (taille de la classe majoritaire dans TRAIN)
NMAX=$(awk -F'\t' 'NR>1{c[$$2]++} END{for(k in c){if(c[k]>m)m=c[k]} print m}' data/interim/ideo/train.tsv)

# Reconstruire le TRAIN avec duplication des minoritaires
make BALANCE=cap_docs CAP_PER_LABEL=$NMAX OVERSAMPLE=--oversample prepare_ideo_quick

# Ré-entraîner + évaluer
make train_ideo_quick
make eval_ideo_quick
```

Stratégies `cap_docs`, `cap_tokens`, `alpha_total` et recommandations d’usage : voir § “Gérer les classes déséquilibrées”.

---

## 6) Détails techniques (pour devs)

### 6.1 Split & logs

* `tei_to_train_job.py` **compte** les docs par label, applique **limit/dedup** avant split, et imprime des **stats** (utile pour choisir un équilibrage).
* En mode `--label-field ideology`, un **mapping YAML** est requis ; le script contrôle sa présence et **échoue proprement** si absent.

### 6.2 DocBin & labels

* Le **DocBin** est créé via `nlp.pipe` multi-process avec `--batch-size` tunable ; `labels.json` alimente l’étape d’init (`initialize.components.textcat.labels`).

### 6.3 Config spaCy auto

* `init_config(lang=..., pipeline=["textcat"], optimize=...)` pilote la **composition de pipeline** (BOW vs tok2vec) ; en `cnn/accuracy` on obtient typiquement **`tok2vec+textcat`**. Les **vectors statiques** sont désactivés pour rester **CPU-friendly**.
* Classes **exclusives** : `_set_exclusive()` force `exclusive_classes=True` (BOW) ou dans `linear_model` (Ensemble), évitant les surprises multi-label pour un binaire “droite/gauche”.

### 6.4 Seeds & batching

* `fix_random_seed` + `PYTHONHASHSEED` pour reproductibilité ; **batcher `batch_by_padded`** avec schéma **compounding** (`start→stop`).

---

## 7) Multilingue (LANG=`xx`) — “passe-plat”

* Le Makefile télécharge `xx_sent_ud_sm` en **setup** : tokenisation/segmentation **générique** acceptable pour **faire passer** des contenus hétérogènes sans casser le pipe.
* Le **classifieur** spaCy (`textcat`) reste **agnostique** à la langue du moment que la tokenisation est raisonnable.
* Bonnes pratiques :

  * Garder `--max-tokens` **modéré** (ex. 350–600) pour limiter le bruit.
  * Équilibrer **TRAIN** (pas JOB) pour compenser les dérives de distribution **par langue**.
  * Sur corpus très hétérogène, préférer `arch=cnn` (tok2vec) à `bow`. (cf. choix `optimize="accuracy"`).

---

## 8) Évaluation & lecture des scores

* **Macro-F1** à prioriser (équité entre classes).
* **Streaming** si RAM limitée ou **JOB** volumineux : `eval_textcat_stream.py` produit un `classification_report` scikit-learn (precision/recall/F1 par classe + macro/weighted).
* Attention aux **distributions déséquilibrées** (accuracy trompeuse) ; le README détaille les caveats et baselines honnêtes.

---

## 9) Performance & stabilité

* **Limiter threads BLAS** (OPENBLAS/MKL/NUMEXPR) quand on parallélise ailleurs (WORKERS, nlp.pipe).
* Baisser `--max-tokens` et **augmenter graduellement** `batch-start/stop`.
* En cas d’absence de `model-best/`, l’évaluation peut **tomber** sur `model-last/`; réduire `EVAL_FREQ` pour capturer le meilleur.

---

## 10) Dépannage rapide

* **Aucun doc**: chemin/crawl, extraction trop stricte, ou TEI invalide → activer `huge_tree`, nettoyer entités.
* **OOM / lenteur**: réduire `max_tokens`, plafonner threads BLAS, **éval streaming**.
* **Une seule classe dans TRAIN**: relancer la prépa (augmenter limites, activer équilibrage).

---

## 11) Annexes — commandes utiles (idéologie)

Baseline RAM-friendly & équilibrage sans coupe (résumé) : voir les séquences prêtes à l’emploi **§5** (issues du rapport technique).

---

### TL;DR (dev)

* **Prépare** (split + équilibrage TRAIN), **convertis** en DocBin, **entraîne** (`arch=cnn`), **évalue** (macro-F1), **itère**.
* En **multilingue**, restez `LANG=xx` (tokenisation générique), gardez `max_tokens` modestes, et **équilibrez TRAIN**.
* Surveillez **logs/**, **reports/**, et le `auto_config.cfg` généré pour tracer vos runs.
