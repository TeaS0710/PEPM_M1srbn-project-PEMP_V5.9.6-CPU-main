#Projet PEPM By Yi Fan && Adrien
#!/usr/bin/env python3
# scripts/pipeline_check.py
from __future__ import annotations
import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path


def run(cmd: list[str]) -> None:
    print("[RUN]", " ".join(cmd))
    result = subprocess.run(cmd, check=False)
    if result.returncode != 0:
        raise SystemExit(result.returncode)


def build_from_corpus(tmp_dir: Path, corpus: Path, limit: int) -> tuple[Path, Path]:
    splits = tmp_dir / "splits"
    run(
        [
            sys.executable,
            "scripts/tei_to_train_job.py",
            "--corpus",
            str(corpus),
            "--outdir",
            str(splits),
            "--train-prop",
            "0.8",
            "--label-field",
            "crawl",
            "--min-chars",
            "150",
            "--max-tokens",
            "400",
            "--limit",
            str(limit),
            "--procs",
            "2",
            "--seed",
            "42",
        ]
    )
    return splits / "train.tsv", splits / "job.tsv"

def ensure_two_classes(train_tsv: Path, job_tsv: Path, tmp_dir: Path) -> tuple[Path, Path]:
    import pandas as pd
    df = pd.read_csv(train_tsv, sep="\t")
    label_col = None
    for cand in ("label", "ideology", "party", "crawl", "category"):
        if cand in df.columns:
            label_col = cand
            break
    if not label_col:
        print("[WARN] Aucune colonne label reconnue dans le TRAIN — fallback synthétique.")
        return build_synthetic(tmp_dir)
    nunique = df[label_col].nunique(dropna=True)
    if nunique < 2:
        print(f"[WARN] TRAIN à {nunique} classe(s) ({label_col}) — fallback synthétique A/B pour le check.")
        return build_synthetic(tmp_dir)
    return train_tsv, job_tsv

def build_synthetic(tmp_dir: Path) -> tuple[Path, Path]:
    import pandas as pd

    train_tsv = tmp_dir / "train.tsv"
    job_tsv = tmp_dir / "job.tsv"
    texts = [f"Texte démonstration {i}" for i in range(100)]
    labels = ["A"] * 50 + ["B"] * 50
    pd.DataFrame({"text": texts, "label": labels}).to_csv(train_tsv, sep="	", index=False)
    pd.DataFrame({"text": texts[:40], "label": labels[:40]}).to_csv(job_tsv, sep="	", index=False)
    return train_tsv, job_tsv


def main() -> None:
    parser = argparse.ArgumentParser(description="Vérifie que le pipeline minimal fonctionne")
    parser.add_argument("--corpus", type=Path, help="Chemin vers un corpus TEI (facultatif)")
    parser.add_argument("--limit", type=int, default=200, help="Nombre maximum de documents à extraire pour le test")
    parser.add_argument("--lang", type=str, default="fr")
    args = parser.parse_args()

    tmp_dir = Path(tempfile.mkdtemp(prefix="pipeline_check_"))
    print("[TMP]", tmp_dir)

    run([sys.executable, "scripts/sysinfo.py"])
    run([sys.executable, "scripts/check_imports.py"])

    if args.corpus and args.corpus.exists():
        train_tsv, job_tsv = build_from_corpus(tmp_dir, args.corpus, args.limit)
    else:
        print("[INFO] Aucun corpus fourni: génération de données synthétiques")
        train_tsv, job_tsv = build_synthetic(tmp_dir)
    train_tsv, job_tsv = ensure_two_classes(train_tsv, job_tsv, tmp_dir)

    run(
        [
            sys.executable,
            "scripts/build_spacy_corpus.py",
            "--tsv",
            str(train_tsv),
            "--out",
            str(tmp_dir / "train.spacy"),
            "--labels-out",
            str(tmp_dir / "labels.json"),
            "--lang",
            args.lang,
            "--workers",
            "2",
            "--shard-size", "0",
        ]
    )

    run(
        [
            sys.executable,
            "scripts/build_spacy_corpus.py",
            "--tsv",
            str(job_tsv),
            "--out",
            str(tmp_dir / "job.spacy"),
            "--labels-out",
            str(tmp_dir / "labels.json"),
            "--lang",
            args.lang,
            "--workers",
            "2",
            "--shard-size", "0",
        ]
    )

    run(
        [
            sys.executable,
            "scripts/spacy_train_core.py",
            "--train",
            str(tmp_dir / "train.spacy"),
            "--dev",
            str(tmp_dir / "job.spacy"),
            "--out",
            str(tmp_dir / "spacy_model"),
            "--lang",
            args.lang,
            "--arch",
            "bow",
            "--epochs",
            "1",
            "--batch-start",
            "16",
            "--batch-stop",
            "64",
            "--eval-freq",
            "50",
            "--labels", str(tmp_dir / "labels.json"),
        ]
    )

    result = {
        "tmp_dir": str(tmp_dir),
        "train_tsv": str(train_tsv),
        "job_tsv": str(job_tsv),
    }
    print("[OK] Pipeline check succeeded")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
