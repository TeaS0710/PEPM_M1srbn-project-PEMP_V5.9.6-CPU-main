
import argparse, os, json, pickle
from pathlib import Path
from typing import List, Tuple, Dict

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix
import matplotlib.pyplot as plt

def get_llm_embeddings(texts: List[str]) -> np.ndarray:
    """
    Placeholder for LLM/transformers embeddings (CamemBERT/FlauBERT).
    Returns random vectors (fixed seed) so the pipeline remains runnable offline.
    Replace with real embeddings when environment allows (transformers, torch).
    """
    rng = np.random.RandomState(123)
    return rng.normal(size=(len(texts), 256))

def load_text_corpus_from_folders(data_dir: Path) -> Tuple[List[str], List[str]]:
    X, y = [], []
    for label_dir in sorted(data_dir.iterdir()):
        if not label_dir.is_dir():
            continue
        label = label_dir.name
        for p in sorted(label_dir.glob('*.txt')):
            try:
                txt = p.read_text(encoding='utf-8').strip()
            except Exception:
                txt = p.read_text(errors='ignore').strip()
            if txt:
                X.append(txt)
                y.append(label)
    return X, y

def evaluate(y_true, y_pred, labels: List[str]) -> Dict:
    acc = accuracy_score(y_true, y_pred)
    prec, rec, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average='macro', zero_division=0
    )
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    return {
        'accuracy': acc,
        'precision_macro': prec,
        'recall_macro': rec,
        'f1_macro': f1,
        'confusion_matrix': cm.tolist()
    }

def plot_confusion_matrix(cm: np.ndarray, labels: List[str], out_png: Path, title: str):
    fig = plt.figure(figsize=(5,4), dpi=120)
    plt.imshow(cm, interpolation='nearest')
    plt.title(title)
    plt.xticks(range(len(labels)), labels, rotation=45, ha='right')
    plt.yticks(range(len(labels)), labels)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            plt.text(j, i, cm[i, j], ha='center', va='center')
    plt.tight_layout()
    plt.savefig(out_png)
    plt.close(fig)

def run():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data_dir', type=str, required=True)
    ap.add_argument('--test_size', type=float, default=0.3)
    ap.add_argument('--random_state', type=int, default=42)
    ap.add_argument('--out_dir', type=str, default='outputs')
    args = ap.parse_args()

    data_dir = Path(args.data_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    X, y = load_text_corpus_from_folders(data_dir)
    labels = sorted(set(y))

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=args.random_state, stratify=y
    )

    experiments = {
        'count_nb': Pipeline([
            ('vec', CountVectorizer(ngram_range=(1,2), min_df=1)),
            ('clf', MultinomialNB())
        ]),
        'tfidf_svm': Pipeline([
            ('vec', TfidfVectorizer(ngram_range=(1,2), min_df=1)),
            ('clf', LinearSVC())
        ]),
        'tfidf_lr': Pipeline([
            ('vec', TfidfVectorizer(ngram_range=(1,2), min_df=1)),
            ('clf', LogisticRegression(max_iter=200))
        ]),
    }

    rows = []
    for name, pipe in experiments.items():
        pipe.fit(X_train, y_train)
        y_pred = pipe.predict(X_test)
        metrics = evaluate(y_test, y_pred, labels)
        cm = np.array(metrics['confusion_matrix'])
        with open(out_dir / f'model_{name}.pkl', 'wb') as f:
            pickle.dump(pipe, f)
        plot_confusion_matrix(cm, labels, out_dir / f'cm_{name}.png', f'CM - {name}')
        row = {'experiment': name}
        for k, v in metrics.items():
            if k != 'confusion_matrix':
                row[k] = v
        rows.append(row)

    df = pd.DataFrame(rows)
    df.to_csv(out_dir / 'metrics.csv', index=False)
    with open(out_dir / 'labels.json', 'w', encoding='utf-8') as f:
        json.dump(labels, f, ensure_ascii=False, indent=2)
    print('Done. Metrics at', out_dir / 'metrics.csv')

if __name__ == '__main__':
    run()
