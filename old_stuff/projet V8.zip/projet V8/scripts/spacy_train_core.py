# scripts/spacy_train_core.py
from __future__ import annotations
import os, argparse, json
from pathlib import Path
import spacy
from spacy.cli.init_config import init_config
from spacy.cli.train import train as spacy_train
from utils_runtime import set_threads, print_torch_env
from logging_setup import get_logger
log = get_logger("spacy_train_core")  # ou "hf_train"


def _set_exclusive(cfg: dict):
    try:
        model = cfg["components"]["textcat"]["model"]
        arch = model.get("@architectures","")
        if "TextCatBOW" in arch:
            model["exclusive_classes"] = True
        elif "TextCatEnsemble" in arch and "linear_model" in model:
            model["linear_model"]["exclusive_classes"] = True
    except Exception:
        pass

def _disable_static_vectors(cfg: dict):
    # évite l’indexing des “static vectors” si le FR n’en a pas
    try:
        emb = cfg["components"]["tok2vec"]["model"]["embed"]
        if "include_static_vectors" in emb:
            emb["include_static_vectors"] = False
    except Exception:
        pass

def _set_transformer_name(cfg: dict, name: str):
    try:
        cfg["components"]["transformer"]["model"]["name"] = name
    except Exception:
        pass

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--dev",   type=Path, required=True)
    ap.add_argument("--out",   type=Path, required=True)
    ap.add_argument("--lang",  type=str,  default="fr")
    ap.add_argument("--arch",  choices=["bow","cnn","trf"], default="cnn")
    ap.add_argument("--hf-model", type=str, default="camembert-base")
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--dropout", type=float, default=0.1)
    ap.add_argument("--eval-freq", type=int, default=300)
    ap.add_argument("--batch-start", type=int, default=32)
    ap.add_argument("--batch-stop",  type=int, default=512)
    ap.add_argument("--accumulate", type=int, default=2)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--gpu", type=int, default=-1, help="-1=CPU; 0..=GPU id (nécessite CuPy)")
    args = ap.parse_args()

    set_threads(args.threads)
    print_torch_env()

    # GPU spaCy => nécessite CuPy (sinon spaCy lève/retrograde)
    if args.gpu >= 0:
        try:
            spacy.require_gpu(args.gpu)  # lève si CuPy absent
            print(f"[spaCy] GPU enabled (id={args.gpu})")
        except Exception as e:
            print("[spaCy] GPU not available (CuPy required) -> using CPU:", e)

    # pipeline minimal textcat
    if args.arch == "bow":
        cfg = init_config(lang=args.lang, pipeline=["textcat"], optimize="efficiency")
    elif args.arch == "cnn":
        cfg = init_config(lang=args.lang, pipeline=["textcat"], optimize="accuracy")
        _disable_static_vectors(cfg)
    else:  # trf
        import spacy_transformers  # noqa: F401
        cfg = init_config(lang=args.lang, pipeline=["transformer","textcat"], optimize="accuracy")
        _set_transformer_name(cfg, args.hf_model)

    # entraînement: RAM-friendly
    cfg["training"]["max_epochs"] = int(args.epochs)
    cfg["training"]["dropout"] = float(args.dropout)
    cfg["training"]["accumulate_gradient"] = max(1, int(args.accumulate))
    cfg["training"]["eval_frequency"] = max(50, int(args.eval_freq))
    cfg["training"]["batcher"] = {
        "@batchers": "spacy.batch_by_padded.v1",
        "discard_oversize": True,
        "buffer": 128,
        "size": {
            "@schedules": "compounding.v1",
            "start": int(args.batch_start),
            "stop": int(args.batch_stop),
            "compound": 1.001
        }
    }

    # exclusivité multi-classe au bon endroit
    _set_exclusive(cfg)

    # chemins
    cfg.setdefault("paths", {})
    cfg["paths"]["train"] = str(args.train)
    cfg["paths"]["dev"]   = str(args.dev)
    cfg["paths"]["vectors"] = None
    cfg.setdefault("initialize", {})["vectors"] = None

    # logger
    cfg["training"]["logger"] = {"@loggers": "spacy.ConsoleLogger.v1", "progress_bar": True}

    # sauvegarde config & train
    args.out.mkdir(parents=True, exist_ok=True)
    cfg_path = args.out / "auto_config.cfg"
    cfg.to_disk(cfg_path)
    print("[CONFIG] training.batcher:", json.dumps(cfg["training"]["batcher"], indent=2))
    print(f"[INFO] Config écrite → {cfg_path}")
    spacy_train(config_path=str(cfg_path), output_path=str(args.out), overrides={}, use_gpu=args.gpu)

if __name__ == "__main__":
    main()
