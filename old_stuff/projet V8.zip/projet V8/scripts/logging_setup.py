# scripts/logging_setup.py
from __future__ import annotations
import logging, os, sys, time
from pathlib import Path

_DEF_FMT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

def get_logger(name: str = "pipeline", level: str | None = None) -> logging.Logger:
    lvl = (level or os.getenv("LOG_LEVEL") or "INFO").upper()
    logger = logging.getLogger(name)
    if logger.handlers:
        logger.setLevel(lvl)
        return logger

    logger.setLevel(lvl)
    logger.propagate = False

    # Console
    sh = logging.StreamHandler(sys.stdout)
    sh.setLevel(lvl)
    sh.setFormatter(logging.Formatter(_DEF_FMT))
    logger.addHandler(sh)

    # Fichier
    logdir = Path(os.getenv("LOG_DIR", "logs"))
    logdir.mkdir(parents=True, exist_ok=True)
    ts = time.strftime("%Y%m%d-%H%M%S")
    logfile = logdir / f"run-{ts}.log"
    fh = logging.FileHandler(logfile, encoding="utf-8")
    fh.setLevel(lvl)
    fh.setFormatter(logging.Formatter(_DEF_FMT))
    logger.addHandler(fh)

    logger.info("logging to %s", logfile)
    return logger
