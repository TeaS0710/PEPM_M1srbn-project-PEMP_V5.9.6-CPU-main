# scripts/check_imports.py
from __future__ import annotations
import importlib, pkgutil

pkgs = [
    "lxml", "pandas", "numpy", "scikit_learn", "sklearn",
    "spacy", "thinc", "torch", "transformers", "psutil"
]
print("[CHECK] Imports/versions:")
for m in pkgs:
    name = m
    if m == "scikit_learn": name = "sklearn"
    try:
        mod = importlib.import_module(name)
        ver = getattr(mod, "__version__", "?")
        print(f"  - {name}: {ver}")
    except Exception as e:
        print(f"  - {name}: FAIL ({e})")

# Modèle spaCy fr (optionnel)
try:
    import spacy
    spacy.blank("fr")
    print("  - spacy.fr: OK (blank)")
except Exception as e:
    print("  - spacy.fr: FAIL", e)

# GPU PyTorch ?
try:
    import torch
    print(f"  - torch.cuda.is_available(): {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print("    GPU0:", torch.cuda.get_device_name(0))
except Exception as e:
    print("  - torch.cuda: FAIL", e)
