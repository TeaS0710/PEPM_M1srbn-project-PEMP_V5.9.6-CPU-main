# scripts/utils_runtime.py
from __future__ import annotations
import os

def set_threads(n: int) -> int:
    n = max(1, int(n))
    for k in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
        os.environ[k] = str(n)
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    return n

def print_torch_env():
    try:
        import torch
        ok = torch.cuda.is_available()
        devs = []
        if ok:
            for i in range(torch.cuda.device_count()):
                try:
                    name = torch.cuda.get_device_name(i)
                    mem = torch.cuda.get_device_properties(i).total_memory/1e9
                    devs.append(f"{name} ({mem:.1f}GB)")
                except Exception:
                    devs.append("GPU?")
        print(f"[TORCH] {torch.__version__} | cuda_available={ok} | gpus={devs}")
    except Exception as e:
        print("[TORCH] not available:", e)
