# PEPM_M1srbn — README étendu (pipeline complet, choix techniques & enjeux)

> **Objectif global.** Construire une chaîne **reproductible** pour entraîner un **classifieur de textes en français** (spaCy) à partir d’un **corpus TEI** issu de crawls web (extraction HTML → TEI → TSV → DocBin → entraînement → évaluation), tout en **maîtrisant les déséquilibres** de classes, la **consommation CPU/RAM**, et la **qualité des métriques** (accuracy vs macro‑F1).

---

### Installation

```bash
python3 -m venv .venv && source .venv/bin/activate
make setup
```

### Vérifications rapides

```bash
make sysinfo      # infos machine + threads BLAS
make check        # dépendances + mini test pipeline
```

---

### Pipelines “quick” & “full”

```bash
make prepare_quick      # split + .spacy (sous-ensemble)
make train_quick        # entraînement rapide
make pipeline_quick     # prepare_quick + train_quick

make prepare_full       # split + .spacy (corpus complet)
make train_full         # entraînement complet
make pipeline_full      # prepare_full + train_full
```

---

### Baseline (non équilibré, prudent)

```bash
# Reset + install
make clean
make setup
make sysinfo

# Idéologie (droite/gauche) — sans équilibrage
make WORKERS=4 BALANCE=none prepare_ideo
make WORKERS=4 train_ideo
make eval_ideo                    # → reports/ideo_metrics.json

# Partis (multiclasse) — sans équilibrage
make WORKERS=4 BALANCE=none QUICK_LIMIT=1000 prepare_quick
make WORKERS=4 train_quick
make eval_parties                 # → reports/parties_metrics.json
```

**Safety checks (optionnels)**

```bash
# Vérifier ≥ 2 labels en TRAIN (idéologie)
awk -F'\t' 'NR>1{c[$2]++} END{for(k in c) printf "%7d %s\n", c[k], k}' data/interim/ideo/train.tsv
cat data/processed/spacy/ideo_labels.json

# Vérifier répartition partis
awk -F'\t' 'NR>1{c[$2]++} END{for(k in c) printf "%7d %s\n", c[k], k}' data/interim/quick/train.tsv | sort -nr | head
cat data/processed/spacy/quick_labels.json
```

---

### Équilibrage **sans coupe** (TRAIN uniquement)

```bash
# Idéologie — cap_docs + oversample au niveau de la majoritaire
NMAX=$(awk -F'\t' 'NR>1{c[$2]++} END{for(k in c){if(c[k]>m)m=c[k]} print m}' data/interim/ideo/train.tsv)
make WORKERS=4 BALANCE=cap_docs CAP_PER_LABEL=$NMAX OVERSAMPLE=--oversample prepare_ideo
make WORKERS=4 train_ideo
make eval_ideo

# Partis — même principe
NMAX=$(awk -F'\t' 'NR>1{c[$2]++} END{for(k in c){if(c[k]>m)m=c[k]} print m}' data/interim/quick/train.tsv)
make WORKERS=4 BALANCE=cap_docs CAP_PER_LABEL=$NMAX OVERSAMPLE=--oversample prepare_quick
make WORKERS=4 train_quick
make eval_parties
```

> Variantes d’équilibrage :
> `BALANCE=cap_tokens CAP_TOKENS=200000` • `BALANCE=alpha_total ALPHA=0.5 TOTAL=4000`

---

### Séquence **SAFE** (RAM-friendly)

```bash
# 0) Reset & infos
make clean && make setup && make sysinfo

# 1) Idéologie — baseline puis éval légère
make WORKERS=4 BALANCE=none prepare_ideo
make WORKERS=4 EVAL_FREQ=1 train_ideo
make JOB_LIMIT=500  eval_ideo
make JOB_LIMIT=1000 eval_ideo
make JOB_LIMIT=2000 eval_ideo
# (finale pleine : make JOB_LIMIT=0 eval_ideo)

# 2) Partis — baseline rapide
make WORKERS=4 BALANCE=none QUICK_LIMIT=1000 prepare_quick
make WORKERS=4 EVAL_FREQ=1 train_quick
make JOB_LIMIT=500  eval_parties
make JOB_LIMIT=1000 eval_parties
```

*(Si tu as la cible “stream”)*

```bash
# Évaluation streaming (charge mémoire minimale)
make eval_ideo_stream
```

---

### Rappels “safety”

* Pas de `--limit` au **TEI→TSV** (réduction = côté DocBin ou éval).
* Le **JOB** n’est **jamais équilibré** ; on peut seulement le **limiter** à l’éval via `JOB_LIMIT`.
* Si erreur spaCy **E867**, ton TRAIN n’a **qu’un seul label** → refaire `prepare_*` (ou activer l’oversampling).
* Garde `WORKERS` modestes (2–4) et les threads BLAS capés (déjà exportés dans le Makefile).
* Si `model-best/` absent, l’éval bascule sur `model-last/` (fallback déjà géré).


### Extraits du Makefile (résumé des cibles)

* **Variables principales** (défauts) :

  * `RAW_CORPUS=data/raw/corpus/corpus.xml`, `INTERIM=data/interim`, `QUICK_SPLITS=$(INTERIM)/quick`, `FULL_SPLITS=$(INTERIM)/full`
  * `SPACY_DATA=data/processed/spacy`, `MODELS_DIR=models`
  * `TRAIN_PROP=0.8`, `MIN_CHARS=200`, `QUICK_MAX_TOKENS=600`, `FULL_MAX_TOKENS=1500`, `QUICK_LIMIT=2000`, `WORKERS=2`
  * autres variables utilisées par l’entraînement : `LANG`, `ARCH`, `EPOCHS_QUICK`, `EPOCHS_FULL`, `BATCH_START`, `BATCH_STOP`, `EVAL_FREQ`, `SEED`.

* **`prepare_quick`**

  1. `scripts/tei_to_train_job.py` → `$(QUICK_SPLITS)/train.tsv` & `job.tsv`
  2. `scripts/build_spacy_corpus.py` → `$(SPACY_DATA)/quick_train.spacy` & `quick_job.spacy` (+ `quick_labels.json`)

* **`train_quick`**

  * `scripts/spacy_train_core.py` avec :
    `--train $(SPACY_DATA)/quick_train.spacy \  --dev $(SPACY_DATA)/quick_job.spacy \  --out $(MODELS_DIR)/spacy_quick \  --lang $(LANG) --arch $(ARCH) \  --epochs $(EPOCHS_QUICK) --n-process $(WORKERS) --seed $(SEED) \  --batch-start $(BATCH_START) --batch-stop $(BATCH_STOP) --eval-freq $(EVAL_FREQ) \  --labels $(SPACY_DATA)/quick_labels.json`

* **`prepare_full`**

  * comme `prepare_quick` mais vers `$(FULL_SPLITS)` et `$(SPACY_DATA)/full_*`

* **`train_full`**

  * comme `train_quick` mais vers `$(MODELS_DIR)/spacy_full` et variables `EPOCHS_FULL`/`full_labels.json`

* **Pipelines**

  * `pipeline_quick`: `prepare_quick` → `train_quick`
  * `pipeline_full` : `prepare_full` → `train_full`

* **Nettoyage**

  * `make clean` : supprime quick/full splits et artefacts `.spacy` & modèles `spacy_quick`/`spacy_full`.

### Overrides utiles (à la volée)

```bash
make pipeline_quick WORKERS=4 ARCH=cnn EPOCHS_QUICK=10 BATCH_START=32 BATCH_STOP=512 EVAL_FREQ=200 SEED=42 LANG=fr
make prepare_full  WORKERS=8 FULL_MAX_TOKENS=1200 MIN_CHARS=150
```

---

## 0) Carte mentale du pipeline

```
[Pages HTML (.html/.html.gz)] --(extraction)-->  [teiCorpus.xml]
[teiCorpus.xml] --(split 80/20 + équilibrage TRAIN)--> [train.tsv, job.tsv]
[*.tsv] --(DocBin spaCy)--> [train.spacy, job.spacy, labels.json]
[.spacy] --(training spaCy CPU)--> [models/spacy_model]
[models + job.spacy] --(éval)--> [metrics.json, classification_report.txt, confusion.png]
```

**Invariants méthodologiques**

* Le **JOB** (jeu de test) est **la réalité** ; **intouchable** (pas d’équilibrage ni de « nettoyage » orienté résultat).
* L’**équilibrage** s’applique **avant entraînement**, **sur le TRAIN uniquement** (cap_docs, cap_tokens, alpha_total).
* Les scripts sont **streaming** et **multiprocesseurs** pour tenir sur machine perso ; pas de dépendance GPU obligatoire.

---

## 1) Acquisition & extraction : minet → TEI

### 1.1 Crawl cible (minet)

* **Focus‑crawl** ciblé sur un domaine/source : reprise continue, compression en transit & disque, **export CSV** (métadonnées) + **fichiers HTML** (chemins stables).
* Bonnes pratiques :

  * filtrer les URL (regex d’exclusion : tags, RSS, paramètres UTM/
    fbclid, doublons paginés) ;
  * **throttle** progressif ;
  * vérifier `data.csv` et l’**arborescence** avant extraction.

### 1.2 Extraction TEI (HTML → teiCorpus.xml)

* Lecture de **tous** les dossiers `crawl*` ; prise en charge des **.html** et **.html.gz**.
* **Trafilatura** pour le texte + métadonnées (title, url, date si disponible).
* **Déduplication exacte** à l’échelle **texte** (MD5) afin d’éviter d’entraîner plusieurs fois sur le même contenu.
* Ajout de mots‑clés TEI (`<keywords>`) : **domain**, **suffix**, **class** (CORE/PERIPHERY/CONTEXT selon hôtes), **crawl**, **published**, **date_source**, **folder_path**/**folder**.
* Sortie : **un seul** `teiCorpus.xml` ; chaque document dans son propre `<TEI>`.

**Conseil** : si l’extraction trouve peu de texte, vérifier la qualité du HTML (scripts bloquants, pages vides, contenu dans des widgets) et ajuster `favor_precision` si besoin (rappel vs précision).

---

## 2) TEI → TSV (split 80/20 stratifié + rééquilibrage TRAIN optionnel)

### 2.1 Pré‑filtres

* **min_chars** : longueur minimale de texte (éviter les bribes).
* **max_tokens** : coupe douce des textes trop longs (limiter le temps de train sans casser la sémantique globale).
* **limit** : plafond global pour les essais rapides.
* **dedup_text** : déduplication **avant split** (sur MD5 du texte).

### 2.2 Split & labels

* **Split 80/20 stratifié** par **label** (seed fixe).
* Le label provient par défaut du **champ TEI `crawl`** ; fallback possible sur `folder`/`folder_path`, ou **mappage** (ex. *ideology*) via une table.

### 2.3 Rééquilibrage (TRAIN uniquement)

Trois stratégies complémentaires :

1. **`cap_docs`** — *plafond de documents par label*

   * Si `oversample` activé et `cap_per_label` ≥ taille de la classe **majoritaire**, on **dupplique** les minoritaires pour atteindre le cap **sans couper** les majoritaires.
   * Utiliser `offset` pour « tourner » à travers les documents lors de runs successifs et couvrir tout le stock sur plusieurs essais.

2. **`cap_tokens`** — *plafond de tokens par label*

   * Adapté quand les tailles de documents sont très **inégales** (blogs courts vs transcriptions longues).
   * Duplication possible si la somme de tokens reste insuffisante.

3. **`alpha_total`** — *échantillonnage tempéré*

   * On cible une taille totale `total` avec des quotas ∝ `count(label)^alpha` (0<α≤1).
   * Plus **doux** qu’un équilibrage parfait : on **lisse** les extrêmes sans « laminer » les gros labels.

**Astuce** : d’abord **aucun équilibrage** pour mesurer les **comptes par label** (logs), récupérer Nmax (train), puis relancer avec `cap_docs + oversample` (cap=Nmax) pour un **train équilibré sans couper**.

---

## 3) TSV → DocBin (.spacy)

* Conversion des `.tsv` (colonnes `text`, `label`) en **DocBin** spaCy.
* Génération d’un **`labels.json`** ordonné (stabilité des runs).
* Option **`--balance oversample`** au niveau DocBin (rarement utile si l’équilibrage est déjà géré en amont, mais pratique pour des **essais pédagogiques**).

---

## 4) Entraînement spaCy (CPU) & évaluation

### 4.1 Architecture & config

* Deux profils réplicables :

  * **`arch=cnn`** (*tok2vec/CNN*) : **rapide** et robuste (baseline recommandée en CPU).
  * **`arch=bow`** (*TextCatBOW*) : plus simple, utile en démonstration ou si l’on veut un point de comparaison « classique ».
* Points de config saillants :

  * **classes exclusives** (multiclasse) activées automatiquement quand c’est supporté ;
  * **batcher** *padded + compounding* (`start→stop`) ;
  * **dropout** modéré (0.1–0.3) ;
  * **eval_frequency** raisonnable pour voir la courbe (sans casser le débit) ;
  * **n_process** calé sur le nombre de cœurs **réellement disponibles** (tenir compte d’OpenBLAS/MKL/OMP).

### 4.2 Métriques & lecture

* **Accuracy** : varie fortement avec la **distribution** du JOB ;
* **Macro‑F1** : reflète la qualité moyenne **par classe**, donc sévère si certaines classes sont **rares** ou mal apprises ;
* **Weighted‑F1** : pèse par la taille de classe, souvent proche de l’accuracy si les classes rares sont négligées ;
* **Matrice de confusion** : clé pour voir les **porosités** (qui confond quoi ?), à regarder en brut et normalisée.

### 4.3 « Premiers résultats pourris » & baselines honnêtes

* **Majority baseline** : si le JOB est déséquilibré, prédire *toujours la classe majoritaire* peut donner une accuracy élevée (ex. 80%) mais **Macro‑F1 très basse** — c’est **volontairement trompeur**.
* **Random 50/50** (binaire équilibrée) : accuracy **≈ 50%**, precision/recall **≈ 0.5**, F1 **≈ 0.5** ; variance non négligeable sur petits JOB.
* **CNN naïf** (peu d’epochs, pas d’équilibrage train, textes tronqués sévèrement) : on voit apparaître un **biais majoritaire** ;
  l’accuracy peut sembler « correcte » mais **Macro‑F1 s’effondre** → signe d’un **mismatch** entre TRAIN (éventuellement équilibré) et JOB (asymétrique) **ou** d’un manque de **signal lexical** sur certaines classes.

**Antidotes progressifs** :

1. s’assurer que le **TRAIN** porte assez de signal pour **chaque classe** (cap_tokens/alpha_total > cap_docs si tailles très inégales) ;
2. limiter la **troncature** (max_tokens) si elle « coupe » les indices pertinents ;
3. augmenter doucement **epochs** et **batch_stop** ;
4. vérifier les **textes sources** (qualité d’extraction, langue, bruit, doublons résiduels).

---

## 5) CPU, threads & contraintes mémoire

* **Pas de tempête de threads** : régler `OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `MKL_NUM_THREADS`, `NUMEXPR_NUM_THREADS` (8–12 suffit souvent).
* **n_process** raisonnable dans les scripts (construction DocBin, entraînement) : typiquement `min(cores, 8)`.
* **RAM** :

  * extraction TEI en **streaming** → **O(N)** documents, mémoire **bornée** ;
  * split & rééquilibrage opèrent sur des **structures légères** (listes/dicos) ;
  * DocBin compact (binaire) → stockage dense.
* **Disque** : prévoir de l’espace pour `teiCorpus.xml`, les `.spacy`, les modèles et rapports.

---

## 6) GPU en pause (CuPy/ROCm AMD) → mode CPU‑only multi‑process

> **Décision actuelle** : nous **mettons en pause** la variante **GPU** car la chaîne spaCy/Thinc s’appuie côté GPU sur **CuPy**, dont la **compatibilité ROCm (AMD)** est encore **instable/contraignante** selon les versions (wheels spécifiques, ABI, toolchains), et produit des **comportements non‑déterministes**/plantages difficiles à diagnostiquer sur certaines cartes.

**Conséquence** : on standardise le **mode CPU‑only**, en s’appuyant sur :

* des scripts **streaming** (lecture séquentielle, `iterparse` XML) ;
* un **multi‑process** raisonné (`--workers / --n-process`) ;
* des **batchs composés** (`--batch-start/--batch-stop`) ;
* des **caps** contrôlant la taille des exemples (`--max-tokens`, `cap_tokens`).

**Bonnes pratiques CPU**

* Plafonner les threads BLAS : `OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `MKL_NUM_THREADS`, `NUMEXPR_NUM_THREADS` (souvent 8–12).
* `WORKERS`/`--n-process` ≤ nb de cœurs logiques utiles (ne pas cumuler avec BLAS illimité).
* Préférer **`cap_tokens`** si les tailles de documents varient beaucoup ; sinon **`cap_docs`** + `--oversample` pour un TRAIN équilibré **sans couper**.

**Gestion RAM (points durs)**

* **DocBin** : format binaire compact, mais la **tokenisation** peut gonfler transitoirement la RAM → réduire `--max-tokens`, augmenter `--workers` prudemment.
* **Équilibrage** : duplication = plus de textes en mémoire ; surveiller la taille du TRAIN.
* **IO** : éviter de charger *tout* en mémoire ; privilégier les **générateurs** et les **fichiers temporaires** (splits TSV, sous‑TEI).

> On réévaluera la piste GPU quand la combinaison **spaCy/Thinc + CuPy ROCm** sera suffisamment **stable** dans ton environnement (wheels ROCm packagées, toolchain homogène). En attendant, le pipeline CPU est **robuste, reproductible** et suffisant pour les objectifs pédagogiques/benchmarks.

---

## 7) Complexité, temps mur & « interminable »

### 7.1 Ordres de grandeur (asymptotiques)

* **Extraction TEI** : ~ **O(F)** où *F* = nombre de fichiers HTML. Les opérations dominantes sont la lecture/IO et l’extraction de texte (quasi‑linéaire), parallélisées.
* **Dédup MD5** : **O(N)** (insertions dans un set) sur le nombre de documents retenus.
* **Split 80/20 + stats** : **O(N)**.
* **Équilibrage** :

  * `cap_docs` : **O(N)** ;
  * `cap_tokens` : **O(N)**, avec boucle de rattrapage si cap non atteint ;
  * `alpha_total` : **O(N)** pour quotas + sampling.
* **Construction DocBin** : **O(total_tokens)** (tokenisation), parallélisée.
* **Entraînement CNN** : ~ **O(epochs × total_tokens)**.

> **Exponential ?** Non : rien n’est exponentiel par nature ici. On ne fait **pas** de recherche combinatoire explosive. Les « sensations d’infini » viennent surtout d’IO disque/réseau, de parse HTML, et du tokenizing sur **beaucoup de texte**.

### 7.2 Temps pratiques

* Goulots typiques : **IO disques** (HTML compressés), **parse** des pages « lourdes », **tokenisation**.
* Accélérateurs :

  * parallélisme calibré ;
  * taille de **batch** progressive ;
  * réduire **max_tokens** si nécessaire (attention à l’impact signal) ;
  * **limiter/échantillonner** intelligemment pour prototyper, puis augmenter progressivement.

---

## 8) Méthodo d’évaluation et interprétation

1. **Toujours** conserver un JOB **réaliste** (asymétrique si le monde l’est).
2. Rapporter **accuracy + macro‑F1 + weighted‑F1** ; joindre la **confusion** (brute/normalisée).
3. Consigner les **hyperparamètres** (epochs, batch, dropout) et la **distribution** (train vs job).
4. Si macro‑F1 < 0.5 avec accuracy > 0.7 : suspecter un **biais majoritaire** → revoir **équilibrage train**, **max_tokens**, **qualité extraction**, et les classes **proches** (porosité sémantique).

---

## 9) Commandes types (recettes)

### 9.1 Extraction TEI (HTML → TEI)

```bash
python3 scripts/tei_corpus_mp.py
# → for_txm/corpus.xml
```

### 9.2 TEI → TSV (split + équilibrage TRAIN)

* **Essai sans équilibrage** :

```bash
python3 scripts/tei_to_train_job.py \
  --corpus data/raw/corpus/corpus.xml \
  --outdir data/interim/quick \
  --train-prop 0.8 --label-field crawl \
  --min-chars 200 --max-tokens 600 --limit 20000 \
  --procs 4 --seed 42 --dedup-text
```

* **Équilibrage sans couper (duplication)** :

```bash
python3 scripts/tei_to_train_job.py \
  --corpus data/raw/corpus/corpus.xml \
  --outdir data/interim/quick \
  --train-prop 0.8 --label-field crawl \
  --min-chars 200 --max-tokens 600 --limit 20000 \
  --procs 4 --seed 42 --dedup-text \
  --balance-train cap_docs --oversample --cap-per-label Nmax --offset 0
```

* **Équilibrage par tokens** :

```bash
python3 scripts/tei_to_train_job.py \
  --corpus data/raw/corpus/corpus.xml \
  --outdir data/interim/quick \
  --train-prop 0.8 --label-field crawl \
  --min-chars 200 --max-tokens 600 --limit 20000 \
  --procs 4 --seed 42 --dedup-text \
  --balance-train cap_tokens --cap-tokens-per-label 200000 --offset 0
```

* **Équilibrage tempéré (alpha)** :

```bash
python3 scripts/tei_to_train_job.py \
  --corpus data/raw/corpus/corpus.xml \
  --outdir data/interim/quick \
  --train-prop 0.8 --label-field crawl \
  --min-chars 200 --max-tokens 600 --limit 20000 \
  --procs 4 --seed 42 --dedup-text \
  --balance-train alpha_total --alpha 0.5 --total 32000
```

### 9.3 TSV → DocBin

```bash
python3 scripts/build_spacy_corpus.py \
  --tsv data/interim/quick/train.tsv \
  --out data/processed/spacy/train_try.spacy \
  --labels-out data/processed/spacy/labels_try.json \
  --lang fr --workers 4

python3 scripts/build_spacy_corpus.py \
  --tsv data/interim/quick/job.tsv \
  --out data/processed/spacy/job_try.spacy \
  --labels-out data/processed/spacy/labels_try.json \
  --lang fr --workers 4
```

### 9.4 Entraînement (CPU)

```bash
python3 scripts/spacy_train_core.py \
  --train data/processed/spacy/train_try.spacy \
  --dev   data/processed/spacy/job_try.spacy \
  --out   models/spacy_quick \
  --lang fr --arch cnn \
  --epochs 8 --dropout 0.2 \
  --batch-start 32 --batch-stop 512 \
  --eval-freq 200 --n-process 4
```

---

## 10) Bonnes pratiques « prod‑perso »

* **Journaux** dans un dossier daté (`logs/`), niveau INFO/DEBUG, plus copie console.
* **`sysinfo`** et **`check_imports`** en début de run pour diagnostiquer l’environnement.
* **Seeds** figés et versions fixées (requirements + labels.json) pour des comparaisons saines.
* **Snapshots** des modèles (`model-best`) et des rapports d’éval ; ne garder que ce qui sert (rotation).

---

## 11) Dépannage rapide

* **Aucun doc dans TEI** : chemin de crawl erroné, pages vides, extraction trop stricte (ajuster `favor_precision`).
* **XMLSyntaxError** : activer `huge_tree`, nettoyer les entités suspectes.
* **OOM / lenteur** : réduire `max_tokens`, augmenter batch graduellement, baisser `n_process` et plafonner les threads BLAS.
* **Scores incohérents** : vérifier **labels** (mappings stables), **équilibrage TRAIN**, qualité d’extraction, et la **langue** (filtre FR si besoin).

---

## 12) Roadmap qualitative (courte)

1. **Filtre de langue** FR strict + heuristiques anti‑spam.
2. **Préférence** `cap_tokens` ou `alpha_total` si hétérogénéité de tailles.
3. **Diagnostics** par longueur/domaine/période ; rapports agrégés.
4. Option **Transformers** (GPU) si besoin d’un saut de perfs sur des classes sémantiquement proches.

---

## 13) Annexes

### 13.1 Arborescence conseillée

```
data/
  raw/corpus/corpus.xml
  interim/quick/      # train.tsv, job.tsv, corpus_*.xml
  interim/full/
  processed/spacy/    # *.spacy, labels.json
logs/
models/
reports/
scripts/
Makefile
```

### 13.2 Rappels de complexité (résumé)

| Étape                                             | Complexité               | Remarques                                                |
| ------------------------------------------------- | ------------------------ | -------------------------------------------------------- |
| Extraction TEI                                    | O(F)                     | F = nb de fichiers ; dominé par IO/parse ; multi‑process |
| Dédup texte                                       | O(N)                     | hash MD5 + set                                           |
| Split 80/20                                       | O(N)                     | stratifié par label                                      |
| Équilibrage (cap_docs / cap_tokens / alpha_total) | O(N)                     | boucles linéaires + duplications éventuelles             |
| DocBin                                            | O(total_tokens)          | tokenisation multi‑process                               |
| Entraînement CNN                                  | O(epochs × total_tokens) | batch compounding                                        |

### 13.3 Interpréter un « 0.72 acc / 0.45 macro‑F1 »

* Répartition **très asymétrique** côté JOB → accuracy tirée vers la majoritaire.
* **Rappel** faible sur classes rares → macro‑F1 **basse** ; travailler l’**équilibrage TRAIN**, **max_tokens**, et la **qualité des textes**.

---

*Fin du README étendu.*
