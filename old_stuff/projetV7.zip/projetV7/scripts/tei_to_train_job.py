#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TEI -> TSV/TEI (80/20 stratifié) + rééquilibrage PRE-TRAIN (optionnel)

- Lecture streaming du teiCorpus via lxml.iterparse(tag=TEI)
- Chaque <TEI> est sérialisé en bytes puis traité en PARALLÈLE (multiprocessing)
- Filtres: longueur min, trim par max_tokens (sur le texte), limite globale (--limit)
- Split stratifié 80/20 par label
- ⚖️ Rééquilibrage côté TRAIN UNIQUEMENT (job intact) :
    --balance-train {none,cap_docs,cap_tokens,alpha_total}
      * cap_docs:     --cap-per-label N [--oversample] [--offset K]
      * cap_tokens:   --cap-tokens-per-label N [--offset K]
      * alpha_total:  --alpha A --total N (proba ∝ count^A)
- Option: --dedup-text → dédupe exacte par MD5(text) avant split
- Écrit train.tsv / job.tsv + sous-TEI (streaming) si demandé

Exemples (ESSAI) :
  python3 scripts/tei_to_train_job.py \
    --corpus data/raw/corpus/corpus.xml \
    --outdir data/interim/splits_try \
    --train-prop 0.8 --label-field crawl \
    --min-chars 200 --max-tokens 600 --limit 25000 \
    --procs $(nproc) --seed 42 \
    --balance-train cap_docs --cap-per-label 5000 --oversample --offset 0

  python3 scripts/tei_to_train_job.py \
    --corpus data/raw/corpus/corpus.xml \
    --outdir data/interim/splits \
    --train-prop 0.8 --label-field crawl \
    --min-chars 200 --max-tokens 1200 \
    --procs $(nproc) --seed 42 \
    --balance-train alpha_total --alpha 0.5 --total 300000
"""
from __future__ import annotations
import argparse, csv, hashlib, os, random, sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import sys
import re
import unicodedata
from collections import Counter, defaultdict
from multiprocessing import get_context

from lxml import etree as ET  # lxml (plus robuste, huge_tree)

try:
    import yaml
    HAVE_YAML = True
except Exception:
    HAVE_YAML = False

TEI_NS = "http://www.tei-c.org/ns/1.0"

# ----------------------- utils -----------------------

def _flatten_ws(s: str) -> str:
    return " ".join((s or "").replace("\t", " ").split())

def _trim_tokens(s: str, max_tokens: int) -> str:
    if max_tokens and max_tokens > 0:
        t = s.split()
        if len(t) > max_tokens:
            return " ".join(t[:max_tokens])
    return s

def _token_count(s: str) -> int:
    return len(s.split()) if s else 0

def _md5_text(s: str) -> str:
    h = hashlib.md5(); h.update(s.encode("utf-8", errors="ignore")); return h.hexdigest()

# -------------------- TEI parsing helpers --------------------

def get_text_from_root(root: ET._Element, max_chars: int = 0, max_tokens: int = 0) -> str:
    parts: List[str] = []
    head = root.find(".//{*}text/{*}body/{*}div/{*}head")
    if head is not None and (head.text or "").strip():
        parts.append(head.text.strip())
    for p in root.findall(".//{*}text/{*}body//{*}p"):
        if p.text:
            parts.append(p.text.strip())
    txt = "\n".join([x for x in parts if x])
    if max_chars and len(txt) > max_chars:
        txt = txt[:max_chars]
    if max_tokens:
        txt = _trim_tokens(txt, max_tokens)
    return txt

def get_label_from_root(root: ET._Element) -> str:
    # 1) crawl
    for term in root.findall(".//{*}keywords/{*}term"):
        if term.get("type", "").lower() == "crawl" and (term.text or "").strip():
            return term.text.strip()
    # 2) folder/folder_path
    for term in root.findall(".//{*}keywords/{*}term"):
        if term.get("type", "").lower() in {"folder", "folder_path"} and (term.text or "").strip():
            return term.text.strip()
    # 3) xml:id
    return root.get("{http://www.w3.org/XML/1998/namespace}id", "unknown")

def _norm_key(s: str) -> str:
    s = (s or "").lower().strip()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"[^a-z0-9]+", "_", s)
    return s.strip("_")

def apply_ideology(crawl: str, ideomap: Optional[Dict[str, str]]) -> str:
    if not ideomap:
        return crawl
    raw_key  = (crawl or "").lower().strip()
    norm_key = _norm_key(crawl)
    val = ideomap.get(raw_key) or ideomap.get(norm_key)
    return val if (val and val.strip()) else crawl

# ------------------ worker (process) ------------------

def _process_tei_bytes(payload) -> Optional[Dict[str, str]]:
    """
    payload = (tei_bytes, min_chars, max_chars, max_tokens, use_ideology, ideomap_dict)
    Renvoie dict {id,label,crawl,text,tokens,md5_text} OU None (si filtré).
    """
    tei_bytes, min_chars, max_chars, max_tokens, use_ideo, ideomap = payload
    try:
        root = ET.fromstring(tei_bytes)
    except Exception:
        return None

    doc_id = root.get("{http://www.w3.org/XML/1998/namespace}id", "unknown")
    txt = get_text_from_root(root, max_chars=max_chars, max_tokens=max_tokens)
    if not txt or len(txt) < min_chars:
        return None
    crawl = get_label_from_root(root)
    label = apply_ideology(crawl, ideomap) if use_ideo else crawl
    return {
        "id": doc_id,
        "label": label or "unknown",
        "crawl": crawl or "unknown",
        "text": txt,
        "tokens": _token_count(txt),
        "md5": _md5_text(txt),
    }

# --------------------- split & rebalance ---------------------

def stratified_split(docs: List[Dict[str, str]], train_prop: float, seed: int) -> Tuple[List[Dict], List[Dict]]:
    random.seed(seed)
    by = defaultdict(list)
    for d in docs: by[d["label"]].append(d)
    train, job = [], []
    for items in by.values():
        random.shuffle(items)
        n = len(items)
        if n <= 1:
            train.extend(items); continue
        n_tr = max(1, min(n - 1, int(round(train_prop * n))))
        train.extend(items[:n_tr]); job.extend(items[n_tr:])
    return train, job

def dedup_exact_by_text(docs: List[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set(); out = []
    for d in docs:
        h = d["md5"]
        if h in seen:
            continue
        seen.add(h); out.append(d)
    return out

def rebalance_cap_docs(train: List[Dict], cap: int, oversample: bool, offset: int) -> List[Dict]:
    by = defaultdict(list)
    for d in train: by[d["label"]].append(d)
    rng = random.Random(offset)
    out = []
    for lab, L in by.items():
        n = len(L)
        if n == 0: continue
        start = (hash(lab) + offset) % n
        rot = L[start:] + L[:start]
        take = min(cap, n)
        out.extend(rot[:take])
        if oversample and n < cap:
            need = cap - n
            for i in range(need):
                dup = dict(rng.choice(L))
                dup["id"] = f'{dup["id"]}#dup{i+1}'
                out.append(dup)
    rng.shuffle(out)
    return out

def rebalance_cap_tokens(train: List[Dict], cap_tokens: int, offset: int) -> List[Dict]:
    by = defaultdict(list)
    for d in train: by[d["label"]].append(d)
    out = []
    for lab, L in by.items():
        n = len(L)
        if n == 0: continue
        start = (hash(lab) + offset) % n
        rot = L[start:] + L[:start]
        tot = 0; buf = []
        for d in rot:
            if tot >= cap_tokens: break
            buf.append(d); tot += d.get("tokens", 0)
        # si cap non atteint (docs trop courts), on boucle
        i = 0
        while tot < cap_tokens and i < n:
            dd = rot[i % n]
            dup = dict(dd); dup["id"] = f'{dd["id"]}#dup{i+1}'; buf.append(dup)
            tot += dd.get("tokens", 0); i += 1
        out.extend(buf)
    random.Random(offset).shuffle(out)
    return out

def rebalance_alpha_total(train: List[Dict], alpha: float, total: int, seed: int) -> List[Dict]:
    by = defaultdict(list)
    for d in train: by[d["label"]].append(d)
    cnt = {lab: len(L) for lab, L in by.items()}
    w = {lab: (c ** alpha) for lab, c in cnt.items() if c > 0}
    z = sum(w.values()) or 1.0
    probs = {lab: wv / z for lab, wv in w.items()}
    quotas = {lab: max(1, int(round(total * p))) for lab, p in probs.items()}
    diff = total - sum(quotas.values())
    labs = list(quotas.keys()); i = 0
    while diff != 0 and labs:
        quotas[labs[i % len(labs)]] += 1 if diff > 0 else -1
        i += 1; diff = total - sum(quotas.values())
    rng = random.Random(seed)
    out = []
    for lab, L in by.items():
        k = quotas.get(lab, 0)
        if k <= 0 or not L:
            continue
        if k <= len(L):
            out.extend(rng.sample(L, k))
        else:
            out.extend(L)
            for j in range(k - len(L)):
                dup = dict(rng.choice(L)); dup["id"] = f'{dup["id"]}#dup{j+1}'; out.append(dup)
    rng.shuffle(out)
    return out

# --------------------- I/O writers ---------------------

def write_tsv(path: Path, rows: List[Dict[str, str]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["id", "label", "crawl", "text"])
        for r in rows:
            w.writerow([r["id"], _flatten_ws(r["label"]), _flatten_ws(r["crawl"]), _flatten_ws(r["text"])])

def write_subset_streaming(corpus_path: Path, id_list: List[str], out_path: Path, title: str):
    ids = set(id_list)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("wb") as f:
        # header minimal
        f.write(b'<?xml version="1.0" encoding="UTF-8"?>\n')
        f.write(f'<teiCorpus xmlns="{TEI_NS}">'.encode("utf-8"))
        f.write(f'<teiHeader><fileDesc><titleStmt><title>{title}</title></titleStmt></fileDesc></teiHeader>'.encode("utf-8"))
        # stream inclusions
        ctx = ET.iterparse(
            str(corpus_path), events=("end",), tag=f"{{{TEI_NS}}}TEI",
            huge_tree=True, remove_comments=True, remove_pis=True, resolve_entities=False
        )
        for _, el in ctx:
            doc_id = el.get("{http://www.w3.org/XML/1998/namespace}id", "")
            if doc_id in ids:
                f.write(ET.tostring(el, encoding="utf-8"))
            # free mem
            el.clear()
            while el.getprevious() is not None:
                del el.getparent()[0]
        del ctx
        f.write(b"</teiCorpus>")

# -------------------------- main ----------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus",   type=Path, required=True)
    ap.add_argument("--outdir",   type=Path, required=True)
    ap.add_argument("--train-prop", type=float, default=0.8)
    ap.add_argument("--label-field", choices=["crawl", "ideology"], default="crawl")
    ap.add_argument("--ideology-map", type=Path, default=None)
    ap.add_argument("--min-chars",  type=int, default=200)
    ap.add_argument("--max-chars",  type=int, default=0)
    ap.add_argument("--max-tokens", type=int, default=0)
    ap.add_argument("--limit", type=int, default=0, help="garde au plus N docs (après filtrage)")
    ap.add_argument("--procs", type=int, default=max(1, os.cpu_count() or 2))
    ap.add_argument("--chunksize", type=int, default=128)
    ap.add_argument("--no-xml", action="store_true")
    ap.add_argument("--no-tsv", action="store_true")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--dedup-text", action="store_true", help="déduplication exacte par hash du texte, avant split")

    # ⚖️ Rééquilibrage côté TRAIN uniquement
    ap.add_argument("--balance-train", choices=["none","cap_docs","cap_tokens","alpha_total"], default="none")
    ap.add_argument("--cap-per-label", type=int, default=0, help="cap docs/label si balance=cap_docs")
    ap.add_argument("--cap-tokens-per-label", type=int, default=0, help="cap tokens/label si balance=cap_tokens")
    ap.add_argument("--oversample", action="store_true", help="complète au cap quand label trop petit (cap_docs)")
    ap.add_argument("--offset", type=int, default=0, help="rotation par label pour couvrir des blocs différents")
    ap.add_argument("--alpha", type=float, default=0.0, help="alpha (0<α<=1) pour balance=alpha_total")
    ap.add_argument("--total", type=int, default=0, help="taille totale (docs) pour balance=alpha_total")

    args = ap.parse_args()

    # ideomap si demandé
    use_ideo = (args.label_field == "ideology")
    ideomap = None
    if use_ideo:
        if not args.ideology_map:
            print("[ERR] --ideology-map requis", file=sys.stderr); sys.exit(1)
        if not HAVE_YAML:
            print("[ERR] pyyaml requis (pip install pyyaml)", file=sys.stderr); sys.exit(1)
        ideomap_raw = yaml.safe_load(args.ideology_map.read_text(encoding="utf-8")) or {}
        ideomap = {str(k).lower().strip(): str(v).strip() for k, v in ideomap_raw.items()}

    if not args.corpus.exists():
        print(f"[ERR] corpus introuvable: {args.corpus}", file=sys.stderr); sys.exit(1)

    # 1) Streaming iterparse + multiprocessing pour collecter les docs
    jobs = []
    ctx = ET.iterparse(
        str(args.corpus), events=("end",), tag=f"{{{TEI_NS}}}TEI",
        huge_tree=True, remove_comments=True, remove_pis=True, resolve_entities=False
    )
    for _, el in ctx:
        jobs.append((
            ET.tostring(el, encoding="utf-8"),
            args.min_chars, args.max_chars, args.max_tokens,
            use_ideo, ideomap
        ))
        el.clear()
        while el.getprevious() is not None:
            del el.getparent()[0]
    del ctx

    total = len(jobs)
    print(f"[INFO] Collectés: {total} TEI docs → multiprocessing {args.procs} procs (chunksize={args.chunksize})")

    docs: List[Dict[str, str]] = []
    with get_context("fork").Pool(processes=args.procs) as pool:
        for res in pool.imap_unordered(_process_tei_bytes, jobs, chunksize=max(1, args.chunksize)):
            if res:
                docs.append(res)

    if not docs:
        print("[ERR] Aucun document retenu (filtres trop stricts ?).", file=sys.stderr); sys.exit(1)

    if args.limit and len(docs) > args.limit:
        docs = docs[:args.limit]
        print(f"[INFO] Limité à {len(docs)} docs (mode essai).")

    # Dédup éventuelle (avant split)
    if args.dedup_text:
        n0 = len(docs)
        docs = dedup_exact_by_text(docs)
        print(f"[INFO] Dédup texte: {n0} → {len(docs)} docs (par MD5).")

    # Stats globales
    cnt_all = Counter(d["label"] for d in docs)
    print(f"[INFO] Docs: {len(docs)} | Labels: {len(cnt_all)} | Top:")
    for lab, n in cnt_all.most_common(12):
        print(f"  - {lab}: {n}")
    if use_ideo:
        mapped = sum(1 for d in docs if d["label"] != d["crawl"])
        print(f"[INFO] Ideology map hit-rate: {mapped}/{len(docs)}"
              f"({100.0*mapped/max(1,len(docs)):.1f}%)")

    # 2) split stratifié
    train, job = stratified_split(docs, args.train_prop, args.seed)
    print(f"[INFO] Split → Train={len(train)} | Job={len(job)}")
    if (args.label_field in {"ideology"} and
        len({d["label"] for d in train}) < 2):
        print("[ERR] TRAIN n'a qu'un seul label après mapping idéologique. "
              "Vérifie ideology.yml / équilibrage / limit.", file=sys.stderr)
        sys.exit(1)

    # 3) rééquilibrage TRAIN
    if args.balance_train != "none":
        n_before = len(train)
        if args.balance_train == "cap_docs":
            if args.cap_per_label <= 0:
                print("[ERR] --cap-per-label > 0 requis avec balance=cap_docs", file=sys.stderr); sys.exit(1)
            train = rebalance_cap_docs(train, cap=args.cap_per_label, oversample=args.oversample, offset=args.offset)
            mode_desc = f"cap_docs(cap={args.cap_per_label}, oversample={args.oversample}, offset={args.offset})"
        elif args.balance_train == "cap_tokens":
            if args.cap_tokens_per_label <= 0:
                print("[ERR] --cap-tokens-per-label > 0 requis avec balance=cap_tokens", file=sys.stderr); sys.exit(1)
            train = rebalance_cap_tokens(train, cap_tokens=args.cap_tokens_per_label, offset=args.offset)
            mode_desc = f"cap_tokens(cap_tokens={args.cap_tokens_per_label}, offset={args.offset})"
        elif args.balance_train == "alpha_total":
            if args.alpha <= 0 or args.total <= 0:
                print("[ERR] --alpha>0 et --total>0 requis avec balance=alpha_total", file=sys.stderr); sys.exit(1)
            train = rebalance_alpha_total(train, alpha=args.alpha, total=args.total, seed=args.seed)
            mode_desc = f"alpha_total(alpha={args.alpha}, total={args.total})"
        print(f"[INFO] Balance TRAIN={mode_desc}: {n_before} → {len(train)} docs")
    else:
        mode_desc = "none"

    # Stats train/job
    def print_stats(name, L):
        c = Counter(d["label"] for d in L)
        print(f"[STATS] {name}: {len(L)} docs")
        for lab, n in c.most_common(12):
            print(f"  - {lab}: {n} ({100*n/max(1,len(L)):.1f}%)")
    print_stats("TRAIN", train)
    print_stats("JOB", job)

    # 4) écritures
    args.outdir.mkdir(parents=True, exist_ok=True)
    if not args.no_tsv:
        write_tsv(args.outdir / "train.tsv", train)
        write_tsv(args.outdir / "job.tsv",   job)
        print(f"[OK] TSV → {args.outdir/'train.tsv'} ; {args.outdir/'job.tsv'}  (balance={mode_desc})")

    if not args.no_xml:
        write_subset_streaming(args.corpus, [d["id"] for d in train], args.outdir / "corpus_train.xml", "teiCorpus — TRAIN subset")
        write_subset_streaming(args.corpus, [d["id"] for d in job],   args.outdir / "corpus_job.xml",   "teiCorpus — JOB subset")
        print(f"[OK] XML → {args.outdir/'corpus_train.xml'} ; {args.outdir/'corpus_job.xml'}")

if __name__ == "__main__":
    main()
