### Pipeline Web-only

```mermaid
flowchart TD
  A[HTML crawls] --> B[Extraction TEI et dedup MD5 produire corpus.xml]
  B --> C{Labeling source}
  C -->|crawl multiclasse| D[Split 80 20 train.tsv et job.tsv]
  C -->|ideology binaire| D

  D --> E{Equilibrer TRAIN}
  E -->|aucun| F[TRAIN prepare inchange]
  E -->|cap docs oversample| F
  E -->|cap tokens| F
  E -->|alpha total| F

  F --> G[DocBin train spacy et labels json]
  D --> H[DocBin job spacy et labels json]

  subgraph Models
    direction TB
    G --> I[Train spacy arch cnn ou bow]
    G --> J[Train CPU TFIDF SVM RF HGB]
    G --> K[Train HF gele camembert ou flaubert plus logreg]
  end

  subgraph Eval
    direction TB
    I --> L1[Spacy evaluate metrics json]
    I --> L2[Eval streaming classification report]
    J --> L3[Eval CPU models metrics et confusion]
    K --> L3
  end

  L1 --> M[Aggregation rapports accuracy macro F1 weighted F1 AUC]
  L2 --> M
  L3 --> M

  M --> N{Ameliorer}
  N -->|calibrer seuil F1 ou Youden| P[Recalibrer seuils]
  P --> L1
  N -->|ajuster tokens epochs batch class weight| Q[Reconfig preparation]
  Q --> D

  D --> R[Note job non equilibre]
```

### Pipeline Avec videos + verification + comparaisons

```mermaid
flowchart TD
  A0[Corpus TEI avec urls video] --> B1[Index media]
  B1 --> B2[Download audio via ytdlp]
  B2 --> C{Sous titres disponibles}
  C -->|oui| D1[Texte sous titres]
  C -->|non| D2[ASR CPU whisper ou wav2vec2]
  D1 --> E1[Texte audio normalise]
  D2 --> E1

  A0 --> F1{Fusion multimodale}
  E1 --> F1
  F1 -->|text only| G1[Preparer TSV text only]
  F1 -->|audio only| G2[Preparer TSV audio only]
  F1 -->|concat ou text puis audio| G3[Preparer TSV multimodal]

  G1 --> H1[DocBin text only spacy]
  G2 --> H2[DocBin audio only spacy]
  G3 --> H3[DocBin multimodal spacy]

  subgraph Train
    direction TB
    H1 --> T1[Models spacy et CPU pour text only]
    H2 --> T2[Models spacy et CPU pour audio only]
    H3 --> T3[Models spacy et CPU pour multimodal]
  end

  T1 --> EVAL1[Metrics text only]
  T2 --> EVAL2[Metrics audio only]
  T3 --> EVAL3[Metrics multimodal]

  EVAL1 --> V0{Echantillonner erreurs FP FN}
  EVAL2 --> V0
  EVAL3 --> V0
  V0 --> V1[Revue humaine sur segments video]
  V1 --> V2[Annotations tsx ou tsv]

  EVAL1 --> C1
  EVAL2 --> C1
  EVAL3 --> C1
  V2 --> C1
  C1[Comparer avec et sans video et comparer les modeles] --> C2{Changements}

  C2 -->|recalibrer seuils| R1[Recalibrer]
  R1 --> EVAL1
  C2 -->|changer fusion ou vue| R2[Modifier fusion ou vues]
  R2 --> F1
  C2 -->|ameliorer qualite audio| R3[Relancer asr ou preferer sous titres]
  R3 --> B2

```

### Comparateur d’expériences

```mermaid
flowchart TD
  A[Definir config run] --> B[Fixer seeds versions sysinfo]
  B --> C[Lancer pipeline cible]
  C --> D[Produire models et reports]
  D --> E[Extraire metriques]
  E --> F[Agréger tableau comparatif]
  F --> G{Choisir variantes}
  G --> H[Text only]
  G --> I[Audio only]
  G --> J[Multimodal]
  G --> K[SpaCy cnn]
  G --> L[SpaCy bow]
  G --> M[CPU TFIDF SVM RF HGB]
  G --> N[HF CPU camembert flaubert]
  F --> O[Generer rapport global]
  O --> P[Journal des experiences]
  P --> Q{Ameliorer}
  Q --> R[Recalibrer seuils]
  R --> E
  Q --> S[Changer hyperparametres]
  S --> C
  Q --> T[Changer variante ou fusion]
  T --> C

```

### Comparaison globale supervisé vs non supervisé

```mermaid
flowchart TD
  A[TEI corpus xml] --> B[Preparer vues et features]
  B --> C{Branche}
  C -->|Supervise| D1[DocBin ou TFIDF]
  C -->|Non supervise| U1[Embeddings sbert camembert]
  
  D1 --> D2[Entrainer spacy cnn bow et CPU models]
  D2 --> D3[Evaluer accuracy macro F1 weighted F1 AUC confusion]
  D3 --> D4[Rapport supervise]

  U1 --> U2[Kmeans ou HDBSCAN]
  U2 --> U3[Topics bertopic ou lda]
  U3 --> U4[Rapport non supervise]

  D4 --> X[Comparateur global]
  U4 --> X
  X --> Y{Actions}
  Y --> Z1[Calibration seuils ou seuil par label]
  Y --> Z2[Ajuster tokens epochs batch]
  Y --> Z3[Nettoyage et diagnostics corpus]

```

### Acquisition du corpus et scrapper automatique

```mermaid
flowchart TD
  A[Seeds et regles url] --> B[minet focus crawl]
  B --> C[Exports csv et html]
  C --> D[Stockage data raw crawls]
  D --> E[Extraction TEI en streaming]
  E --> F[Normaliser champs crawl focus acteurs]
  F --> G[Dedup md5 et nettoyage]
  G --> H[TEI consolide corpus xml]
  H --> I[Index media video depuis TEI]
  I --> J[Download audio et sous titres via ytdlp]
  J --> K{Sous titres presents}
  K -->|oui| L[Texte sous titres]
  K -->|non| M[ASR cpu whisper ou wav2vec2]
  L --> N[Canal text audio]
  M --> N
  N --> O[Assemble multimodal]
  O --> P[Preparer TSV et DocBin]
  P --> Q[Entrainer et Evaluer]
  Q --> R[Rapports et logs]

```
