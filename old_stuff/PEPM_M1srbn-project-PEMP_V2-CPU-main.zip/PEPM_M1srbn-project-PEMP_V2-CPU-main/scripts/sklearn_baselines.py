#Projet PEPM By Yi Fan && Adrien
#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, sys, time, hashlib, inspect, random
from pathlib import Path
from typing import List, Tuple, Dict, Iterable
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC, SVC
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.pipeline import Pipeline
from sklearn.metrics import (classification_report, confusion_matrix,
                             adjusted_rand_score, normalized_mutual_info_score,
                             silhouette_score)
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import StratifiedKFold
import joblib

def set_seeds(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except Exception:
        pass

def dump_json(obj, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def read_tsv_robust(p: Path) -> Tuple[List[str], List[str]]:
    """Lecture robuste: gère TSV avec header ('text','label') OU sans header."""
    if not p.exists():
        print(f"[ERR] TSV introuvable: {p}", file=sys.stderr)
        return [], []
    try:
        df = pd.read_csv(p, sep="\t", dtype=str)
        if {"text", "label"}.issubset(df.columns):
            df = df[["text", "label"]]
        else:
            # pas de header standard -> relire en positionnel
            df = pd.read_csv(p, sep="\t", header=None, names=["text", "label"], usecols=[0, 1], dtype=str)
    except Exception:
        # dernier fallback
        df = pd.read_csv(p, sep="\t", header=None, names=["text", "label"], usecols=[0, 1], dtype=str)
    df = df.dropna(subset=["text", "label"])
    return df["text"].tolist(), df["label"].tolist()

def labels_map(y: List[str]) -> Tuple[np.ndarray, Dict[str, int], Dict[int, str]]:
    labs = sorted(set(y))
    m = {l: i for i, l in enumerate(labs)}
    r = {i: l for l, i in m.items()}
    return np.array([m[v] for v in y], dtype=int), m, r

def _maybe_class_weight_kwargs(cls, cw: str | None) -> Dict:
    """Ajoute class_weight si supporté par le modèle (sinon fallback silencieux)."""
    if cw is None:
        return {}
    try:
        sig = inspect.signature(cls)
        if "class_weight" in sig.parameters:
            return {"class_weight": cw}
    except Exception:
        pass
    return {}

def supervised_models(names: Iterable[str], balanced: bool, c_grid: List[float]) -> Dict[str, Tuple[Pipeline, Dict]]:
    cw = "balanced" if balanced else None
    models: Dict[str, Tuple[Pipeline, Dict]] = {}
    for n in [s.strip() for s in names if s.strip()]:
        if n == "linear_svm":
            pipe = Pipeline([
                ("tfidf", TfidfVectorizer(max_features=200000, ngram_range=(1, 2))),
                ("clf", LinearSVC(**_maybe_class_weight_kwargs(LinearSVC, cw)))
            ])
            grid = {"clf__C": c_grid}
            models[n] = (pipe, grid)

        elif n == "svm_rbf":
            pipe = Pipeline([
                ("tfidf", TfidfVectorizer(max_features=200000, ngram_range=(1, 2))),
                ("clf", SVC(kernel="rbf", probability=False, **_maybe_class_weight_kwargs(SVC, cw)))
            ])
            grid = {"clf__C": c_grid, "clf__gamma": ["scale"]}
            models[n] = (pipe, grid)

        elif n == "logreg":
            # n_jobs=1 pour éviter d'exploser le CPU/BLAS
            pipe = Pipeline([
                ("tfidf", TfidfVectorizer(max_features=200000, ngram_range=(1, 2))),
                ("clf", LogisticRegression(max_iter=500, n_jobs=1, **_maybe_class_weight_kwargs(LogisticRegression, cw)))
            ])
            grid = {"clf__C": c_grid}
            models[n] = (pipe, grid)

        elif n == "sgd":
            pipe = Pipeline([
                ("tfidf", TfidfVectorizer(max_features=200000, ngram_range=(1, 2))),
                ("clf", SGDClassifier(loss="log_loss", **_maybe_class_weight_kwargs(SGDClassifier, cw), max_iter=10))
            ])
            grid = {"clf__alpha": [1e-4, 1e-5]}
            models[n] = (pipe, grid)

        elif n == "random_forest":
            pipe = Pipeline([
                ("tfidf", TfidfVectorizer(max_features=200000, ngram_range=(1, 2))),
                ("clf", RandomForestClassifier(n_estimators=400, n_jobs=1, **_maybe_class_weight_kwargs(RandomForestClassifier, cw)))
            ])
            grid = {"clf__max_depth": [None, 20, 40]}
            models[n] = (pipe, grid)

        elif n == "extra_trees":
            # ExtraTrees peut ne pas supporter class_weight selon la version : on tente puis fallback
            kwargs = {"n_estimators": 600, "n_jobs": 1}
            try:
                if cw is not None:
                    kwargs["class_weight"] = cw
                clf = ExtraTreesClassifier(**kwargs)
            except TypeError:
                kwargs.pop("class_weight", None)
                clf = ExtraTreesClassifier(**kwargs)
            pipe = Pipeline([
                ("tfidf", TfidfVectorizer(max_features=200000, ngram_range=(1, 2))),
                ("clf", clf)
            ])
            grid = {"clf__max_depth": [None, 20]}
            models[n] = (pipe, grid)

    return models

def eval_sup(model_name: str, pipe_and_grid: Tuple[Pipeline, Dict], Xtr, ytr, Xdv, ydv, Xte, yte,
             outdir: Path, reports: Path) -> None:
    pipe, params = pipe_and_grid
    # GridSearch sur DEV uniquement
    le = LabelEncoder()
    yy = le.fit_transform(ytr)
    counts = np.bincount(yy)
    min_count = int(counts.min()) if counts.size else 0
    cv = max(2, min(3, min_count))  # 2 si c'est très faible, sinon 3
    skf = StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)

    gs = GridSearchCV(pipe, param_grid=grid, cv=skf, n_jobs=-1, scoring="f1_macro")
    gs.fit(Xtr, ytr)
    best = gs.best_estimator_

    # DEV
    yhat_dv = best.predict(Xdv)
    cr_dv = classification_report(ydv, yhat_dv, output_dict=True, zero_division=0)
    labs_dv = sorted(set(ydv))
    cm_dv = confusion_matrix(ydv, yhat_dv, labels=labs_dv)
    dump_json({"model": model_name, "split": "dev", "report": cr_dv, "best_params": gs.best_params_},
              reports / f"sklearn_{model_name}_dev.json")
    pd = __import__("pandas")
    pd.DataFrame(cm_dv, index=labs_dv, columns=labs_dv).to_csv(reports / f"sklearn_{model_name}_confusion_dev.csv")

    # JOB
    yhat_te = best.predict(Xte)
    cr_te = classification_report(yte, yhat_te, output_dict=True, zero_division=0)
    labs_te = sorted(set(yte))
    cm_te = confusion_matrix(yte, yhat_te, labels=labs_te)
    dump_json({"model": model_name, "split": "job", "report": cr_te, "best_params": gs.best_params_},
              reports / f"sklearn_{model_name}_job.json")
    pd.DataFrame(cm_te, index=labs_te, columns=labs_te).to_csv(reports / f"sklearn_{model_name}_confusion_job.csv")

    # persist
    outdir.mkdir(parents=True, exist_ok=True)
    joblib.dump(best, outdir / f"{model_name}.joblib")

def eval_unsup(name: str, X, y, reports: Path) -> None:
    y_enc, m, _ = labels_map(y)
    k = len(m)
    if k <= 1:
        dump_json({"model": name, "error": "single_label"}, reports / f"sklearn_unsup_{name}.json")
        return
    if name == "kmeans":
        km = KMeans(n_clusters=k, n_init="auto", random_state=42)
        yhat = km.fit_predict(X)
        sil = silhouette_score(X, yhat) if k > 1 else 0.0
    elif name == "agglo":
        ag = AgglomerativeClustering(n_clusters=k)
        # ATTENTION: toarray() peut être coûteux -> réservé à des matrices modérées
        yhat = ag.fit_predict(X.toarray())
        sil = 0.0
    else:
        return
    ari = adjusted_rand_score(y_enc, yhat)
    nmi = normalized_mutual_info_score(y_enc, yhat)
    dump_json({"model": name, "split": "train+dev", "k": k, "ARI": ari, "NMI": nmi, "silhouette": sil},
              reports / f"sklearn_unsup_{name}.json")

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--dev",   type=Path, required=True)
    ap.add_argument("--job",   type=Path, required=True)
    ap.add_argument("--models", type=str, default="linear_svm,logreg")
    ap.add_argument("--unsup",  type=str, default="")
    ap.add_argument("--reports", type=Path, required=True)
    ap.add_argument("--outdir",  type=Path, required=True)
    ap.add_argument("--max-features", type=int, default=200000)
    ap.add_argument("--c-grid", type=str, default="0.5,1,2")
    ap.add_argument("--balanced", action="store_true")
    ap.add_argument("--seed", type=int, default=42)

    # Aliases rétro-compat (Makefile anciens)
    ap.add_argument("--class-weight", type=str, choices=["balanced"], help="Alias: équivaut à --balanced", default=None)
    ap.add_argument("--C", type=float, help="Alias: force une seule valeur de C pour SVM/LogReg", default=None)

    args = ap.parse_args()
    set_seeds(args.seed)

    # Args/compat
    if args.class_weight == "balanced":
        balanced = True
    else:
        balanced = bool(args.balanced)

    if args.C is not None:
        c_grid = [float(args.C)]
    else:
        c_grid = [float(x) for x in args.c_grid.split(",") if x.strip()]

    # Chargement données
    Xtr, ytr = read_tsv_robust(args.train)
    Xdv, ydv = read_tsv_robust(args.dev)
    Xte, yte = read_tsv_robust(args.job)

    # Garde-fou: au moins 2 labels
    if len(set(ytr + ydv)) < 2:
        print("[ERR] Train/Dev ne contiennent qu'un seul label — impossible d'entraîner un classifieur.", file=sys.stderr)
        sys.exit(2)

    # Construire modèles
    sup = supervised_models(args.models.split(","), balanced, c_grid)

    # Mettre à jour max_features dans tous les pipelines (si présent)
    def bump_maxfeat(pipe: Pipeline) -> Pipeline:
        vec = pipe.named_steps.get("tfidf")
        if vec is not None:
            vec.set_params(max_features=args.max_features)
        return pipe

    for name, (pipe, grid) in sup.items():
        pipe = bump_maxfeat(pipe)
        eval_sup(name, (pipe, grid), Xtr, ytr, Xdv, ydv, Xte, yte, args.outdir, args.reports)

    # Non supervisé (optionnel)
    if args.unsup:
        vec = TfidfVectorizer(max_features=args.max_features, ngram_range=(1, 2))
        X_un = vec.fit_transform(Xtr + Xdv)
        y_un = ytr + ydv
        for n in [s.strip() for s in args.unsup.split(",") if s.strip()]:
            eval_unsup(n, X_un, y_un, args.reports)

if __name__ == "__main__":
    main()
