#Projet PEPM By Yi Fan && Adrien
#!/usr/bin/env python3
import argparse, json, os, sys, time, random
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from sklearn.metrics import classification_report, confusion_matrix

from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    Trainer,
    TrainingArguments,
    DataCollatorWithPadding,
    set_seed,
)
from datasets import Dataset

def read_tsv(p: Path) -> pd.DataFrame:
    df = pd.read_csv(
        p, sep="\t", header=0, names=["text", "label"], usecols=[0, 1], dtype=str
    )
    df = df.dropna(subset=["text", "label"])
    return df


def dump_json(obj, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def dump_df(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)

def has_rocm() -> bool:
    # ROCm builds expose torch.version.hip
    try:
        import torch.version as _tv  # noqa: F401
        return getattr(torch.version, "hip", None) is not None
    except Exception:
        return False


def choose_device(use_gpu: str) -> torch.device:
    # "0" -> CPU ; "1" -> force GPU if available ; "auto" -> prefer GPU
    if use_gpu == "0":
        return torch.device("cpu")
    if use_gpu == "1":
        return torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    # auto
    return torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")


def allow_fp16(device: torch.device) -> bool:
    # fp16 OK sur CUDA classique ; sur ROCm on reste en fp32 (fp16/bf16 partiels/fragiles)
    return (device.type == "cuda") and (not has_rocm())

def compute_metrics_from_predictions(pred, id2label: dict) -> dict:
    """pred: transformers.EvalPrediction"""
    logits = pred.predictions
    y_pred = np.argmax(logits, axis=1)
    y_true = pred.label_ids

    inv = {v: k for k, v in id2label.items()}  # id -> label str
    y_true_lab = [inv[i] for i in y_true]
    y_pred_lab = [inv[i] for i in y_pred]

    rep = classification_report(
        y_true_lab, y_pred_lab, output_dict=True, zero_division=0
    )
    return {
        "macro_f1": rep["macro avg"]["f1-score"],
        "weighted_f1": rep["weighted avg"]["f1-score"],
        "accuracy": rep["accuracy"],
    }


def confusion_to_df(y_true_ids, y_pred_ids, id2label: dict) -> pd.DataFrame:
    inv = {v: k for k, v in id2label.items()}
    y_true_lab = [inv[i] for i in y_true_ids]
    y_pred_lab = [inv[i] for i in y_pred_ids]
    labs = sorted(list(set(y_true_lab) | set(y_pred_lab)))
    cm = confusion_matrix(y_true_lab, y_pred_lab, labels=labs)
    return pd.DataFrame(cm, index=[f"gold={l}" for l in labs], columns=[f"pred={l}" for l in labs])

def run_one(
    model_name: str,
    train_df: pd.DataFrame,
    dev_df: pd.DataFrame,
    job_df: pd.DataFrame,
    outdir: Path,
    reports: Path,
    epochs: int,
    bs: int,
    grad_accum: int,
    max_len: int,
    lr: float,
    device: torch.device,
    seed: int,
) -> None:

    labels_sorted = sorted(set(train_df["label"]) | set(dev_df["label"]) | set(job_df["label"]))
    if len(labels_sorted) < 2:
        raise SystemExit("⛔ Au moins 2 labels distincts sont requis pour un entraînement supervisé.")

    label2id = {l: i for i, l in enumerate(labels_sorted)}
    id2label = {i: l for l, i in label2id.items()}

    tok = AutoTokenizer.from_pretrained(model_name)

    def enc(batch):
        return tok(batch["text"], truncation=True, max_length=max_len)

    # ----- HuggingFace Dataset + 'labels' entiers (PAS 'label') -----
    def to_hfds(df: pd.DataFrame) -> Dataset:
        ds = Dataset.from_pandas(df[["text", "label"]].copy(), preserve_index=False)
        ds = ds.map(lambda ex: {"labels": label2id[ex["label"]]})
        ds = ds.remove_columns(["label"])
        ds = ds.map(enc, batched=True)
        return ds

    train_ds = to_hfds(train_df)
    dev_ds = to_hfds(dev_df)
    job_ds = to_hfds(job_df)

    dc = DataCollatorWithPadding(tokenizer=tok)

    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        num_labels=len(labels_sorted),
        id2label=id2label,
        label2id=label2id,
    ).to(device)

    save_dir = outdir / f"{model_name.replace('/', '_')}"
    save_dir.mkdir(parents=True, exist_ok=True)

    fp16_ok = allow_fp16(device)

    args = TrainingArguments(
        output_dir=str(save_dir),
        num_train_epochs=epochs,
        per_device_train_batch_size=bs,
        per_device_eval_batch_size=max(1, bs),
        gradient_accumulation_steps=grad_accum,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        learning_rate=lr,
        logging_steps=50,
        report_to="none",
        load_best_model_at_end=True,
        metric_for_best_model="eval_macro_f1",
        greater_is_better=True,
        fp16=fp16_ok,
        bf16=False,
        remove_unused_columns=True,
        dataloader_num_workers=2,
        seed=seed,
        data_seed=seed,
    )

    def metrics_fn(eval_pred):
        m = compute_metrics_from_predictions(eval_pred, id2label)
        # Trainer préfixera en "eval_" lors de evaluate()
        return {"macro_f1": m["macro_f1"], "weighted_f1": m["weighted_f1"], "accuracy": m["accuracy"]}

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=dev_ds,
        tokenizer=tok,
        data_collator=dc,
        compute_metrics=metrics_fn,
    )

    trainer.train()

    eval_dev = trainer.evaluate(dev_ds)
    dump_json(
        {"family": "hf", "model": model_name, "split": "dev", "metrics": eval_dev},
        reports / f"hf_{model_name.replace('/', '_')}_dev.json",
    )

    dev_pred = trainer.predict(dev_ds)
    dev_cm_df = confusion_to_df(dev_pred.label_ids, np.argmax(dev_pred.predictions, axis=1), id2label)
    dump_df(dev_cm_df, reports / f"hf_{model_name.replace('/', '_')}_dev_confusion.csv")

    job_pred = trainer.predict(job_ds)  # EvalPrediction
    job_metrics = compute_metrics_from_predictions(job_pred, id2label)
    dump_json(
        {"family": "hf", "model": model_name, "split": "job", "metrics": job_metrics},
        reports / f"hf_{model_name.replace('/', '_')}_job.json",
    )

    job_cm_df = confusion_to_df(job_pred.label_ids, np.argmax(job_pred.predictions, axis=1), id2label)
    dump_df(job_cm_df, reports / f"hf_{model_name.replace('/', '_')}_job_confusion.csv")

    probs = F.softmax(torch.tensor(job_pred.predictions), dim=1).cpu().numpy()
    y_true = job_pred.label_ids
    y_hat = probs.argmax(axis=1)

    job_texts = job_df["text"].tolist()
    inv = {v: k for k, v in id2label.items()}

    cols = ["text", "gold", "pred"] + [f"prob_{inv[i]}" for i in range(len(inv))]
    rows = []
    for i in range(len(job_texts)):
        row = [job_texts[i], inv[y_true[i]], inv[y_hat[i]]] + list(probs[i])
        rows.append(row)
    pred_df = pd.DataFrame(rows, columns=cols)
    dump_df(pred_df, reports / f"hf_{model_name.replace('/', '_')}_job_preds.csv")

def main():
    ap = argparse.ArgumentParser(description="HF baselines (CPU/GPU/ROCm-safe).")
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--dev", type=Path, required=True)
    ap.add_argument("--job", type=Path, required=True)
    ap.add_argument("--models", type=str, required=True, help="Liste CSV de modèles HF")
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--grad-accum", type=int, default=1)
    ap.add_argument("--max-len", type=int, default=256)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--use-gpu", type=str, default="auto", help="auto|0|1")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--reports", type=Path, required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    args = ap.parse_args()

    set_seed(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)
    os.environ["PYTHONHASHSEED"] = str(args.seed)

    device = choose_device(args.use_gpu)
    print(f"[HF] device={device}, rocm={has_rocm()}, fp16_ok={allow_fp16(device)}", file=sys.stderr)

    tr = read_tsv(args.train)
    dv = read_tsv(args.dev)
    te = read_tsv(args.job)

    for m in args.models.split(","):
        m = m.strip()
        if not m:
            continue
        print(f"[HF] training {m}", file=sys.stderr)
        run_one(
            model_name=m,
            train_df=tr,
            dev_df=dv,
            job_df=te,
            outdir=args.outdir,
            reports=args.reports,
            epochs=args.epochs,
            bs=args.batch_size,
            grad_accum=args.grad_accum,
            max_len=args.max_len,
            lr=args.lr,
            device=device,
            seed=args.seed,
        )


if __name__ == "__main__":
    main()
