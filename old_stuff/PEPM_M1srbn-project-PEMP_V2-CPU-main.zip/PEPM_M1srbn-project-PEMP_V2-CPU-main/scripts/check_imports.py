#Projet PEPM By Yi Fan && Adrien
# scripts/check_imports.py
from __future__ import annotations
import importlib

PACKAGES = [
    "lxml",
    "pandas",
    "psutil",
    "yaml",
    "spacy",
]

print("[CHECK] Vérification des dépendances essentielles:")
for module_name in PACKAGES:
    try:
        module = importlib.import_module(module_name)
        version = getattr(module, "__version__", "?")
        print(f"  - {module_name}: OK ({version})")
    except Exception as exc:
        print(f"  - {module_name}: ABSENT ({exc})")

try:
    import spacy

    spacy.blank("fr")
    print("  - spacy.fr: OK (blank)")
except Exception as exc:
    print("  - spacy.fr: ERREUR", exc)
