#Projet PEPM By Yi Fan && Adrien
#!/usr/bin/env python3
import argparse
from pathlib import Path
from lxml import etree as ET

TEI_NS = "http://www.tei-c.org/ns/1.0"
NS = f"{{{TEI_NS}}}"
NSMAP = {"tei": TEI_NS}

def ensure_modality_term(tei_header, value: str):
    profile = tei_header.find(f"{NS}profileDesc")
    if profile is None:
        profile = ET.SubElement(tei_header, f"{NS}profileDesc")

    textClass = profile.find(f"{NS}textClass")
    if textClass is None:
        textClass = ET.SubElement(profile, f"{NS}textClass")

    keywords = textClass.find(f"{NS}keywords")
    if keywords is None:
        keywords = ET.SubElement(textClass, f"{NS}keywords", attrib={"scheme": "custom"})

    # cherche un term modality existant
    term = None
    for t in keywords.findall(f"{NS}term"):
        if t.get("type") == "modality":
            term = t
            break

    if term is None:
        term = ET.SubElement(keywords, f"{NS}term", attrib={"type": "modality"})

    term.text = (value or "web").strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    ap.add_argument("--value", choices=["web", "asr", "gold"], required=True)
    args = ap.parse_args()

    inp = Path(args.inp)
    out = Path(args.out)

    parser = ET.XMLParser(huge_tree=True, recover=True, remove_blank_text=True)
    tree = ET.parse(str(inp), parser=parser)
    root = tree.getroot()

    # Cas 1: corpus = <teiCorpus> contenant plusieurs <TEI>
    tei_docs = root.findall(".//tei:TEI", namespaces=NSMAP)

    if tei_docs:
        for tei in tei_docs:
            header = tei.find("./tei:teiHeader", namespaces=NSMAP)
            if header is None:
                # insère le teiHeader en tête du TEI
                header = ET.Element(f"{NS}teiHeader")
                tei.insert(0, header)
            ensure_modality_term(header, args.value)
    else:
        # Cas 2: document unique = <TEI> (ou structure atypique)
        if root.tag == f"{NS}TEI":
            header = root.find("./tei:teiHeader", namespaces=NSMAP)
            if header is None:
                header = ET.Element(f"{NS}teiHeader")
                root.insert(0, header)
            ensure_modality_term(header, args.value)
        else:
            # Dernier recours: tenter tous les teiHeader rencontrés
            for header in root.findall(".//tei:teiHeader", namespaces=NSMAP):
                ensure_modality_term(header, args.value)

    tree.write(str(out), encoding="utf-8", xml_declaration=True, pretty_print=True)


if __name__ == "__main__":
    main()
