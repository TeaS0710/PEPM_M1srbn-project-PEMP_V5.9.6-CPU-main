# Guide Windows • `pepm.ps1`

## 1) Pré-requis rapides (côté user Windows)

* **Windows 10/11 64-bit**
* **Python 3.10–3.12 64-bit** installé et accessible dans le PATH
  (si doute : `python --version` dans PowerShell)
* Pas besoin d’installer `make`, ni WSL, ni Git Bash.
  Le script crée tout seul un **venv** et installe les dépendances.

> Astuce : si tu as **Anaconda/Miniconda**, ça marche aussi, mais on recommande le **venv** embarqué pour l’isolation.

---

## 2) Premier lancement

Ouvre **PowerShell** dans le dossier du projet (clic droit > “Ouvrir dans Terminal” ou `Shift+clic droit > Ouvrir PowerShell ici`), puis :

```powershell
# Autorise l’exécution du script pour *cette* session :
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

# Optionnel : affiche l’aide intégrée (si dispo)
.\pepm.ps1 -Task help
# ou
Get-Help .\pepm.ps1 -Detailed
```

---

## 3) “Setup” (une fois par machine)

Installe le venv, les libs Python, et le petit modèle spaCy :

```powershell
.\pepm.ps1 -Task setup
```

Ce que ça fait :

* crée `.venv\` si absent ;
* installe `requirements.txt` (spaCy, scikit-learn, etc.) ;
* télécharge `xx_sent_ud_sm` pour la tokenisation.

---

## 4) Préparer les données TEI (marquage web)

Si ton TEI source (`data\raw\corpus\corpus.xml`) n’a pas encore la **modalité** :

```powershell
.\pepm.ps1 -Task add_modality_web
```

Sortie : `data\raw\corpus\corpus.modality.xml` avec `<term type="modality">web</term>` ajouté si besoin.

---

## 5) Commandes “classiques” (copier/coller)

### 5.1 Pipeline complet **quick / idéologie / web** (tout-en-un)

Enchaîne prepare → stats → split DEV → entraînements (spaCy bow+cnn + sklearn + HF) → éval → agrégation → meta :

```powershell
.\pepm.ps1 -Task pipeline -Profile quick -Label ideology -Mod web -Suite all
```

### 5.2 Préparer uniquement (split/train/job + DocBin)

```powershell
.\pepm.ps1 -Task prepare -Profile quick -Label ideology -Mod web
```

### 5.3 Entraîner spaCy **BOW**

```powershell
.\pepm.ps1 -Task train -Profile quick -Label ideology -Arch bow
```

### 5.4 Entraîner spaCy **CNN**

```powershell
.\pepm.ps1 -Task train -Profile quick -Label ideology -Arch cnn
```

### 5.5 Évaluer le modèle spaCy courant (model-best ou model-last)

```powershell
.\pepm.ps1 -Task eval -Profile quick -Label ideology
```

### 5.6 Baselines **sklearn** seules (sur quick)

```powershell
.\pepm.ps1 -Task pipeline -Profile quick -Label crawl -Suite sklearn
```

### 5.7 Baselines **Transformers HF** seules (CPU par défaut)

```powershell
.\pepm.ps1 -Task pipeline -Profile quick -Label ideology -Suite hf -UseGPU 0
```

> Pour tenter l’auto-détection GPU : `-UseGPU auto` (CUDA requis côté Windows).

### 5.8 Profil **full** (plus long, volumineux)

```powershell
.\pepm.ps1 -Task prepare -Profile full -Label ideology
.\pepm.ps1 -Task train   -Profile full -Label ideology -Arch bow
.\pepm.ps1 -Task eval    -Profile full -Label ideology
```

### 5.9 Mode **debug** (smoke-test ultra-rapide)

```powershell
.\pepm.ps1 -Task pipeline -Profile quick -Label ideology -Config debug
```

---

## 6) Menu interactif (interface textuelle)

Pour un mini “UI” menu (choix 1/2/3…) :

```powershell
.\pepm.ps1 -Task menu
```

Tu y trouveras les actions les plus courantes (setup, pipeline quick, train bow/cnn, eval, etc.).
Pratique pour ta partenaire : **zéro argument à retenir**.

---

## 7) Paramètres disponibles (les plus utiles)

> Les noms reflètent les variables du Makefile. Tu peux **mixer** à volonté.

| Paramètre         | Rôle                      | Valeurs                                                                                                                                                         | Défaut     |
| ----------------- | ------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------- |
| `-Task`           | Action à exécuter         | `setup`, `add_modality_web`, `prepare`, `train`, `eval`, `pipeline`, `stats_quick`, `split_quick_dev`, `aggregate`, `run_meta`, `sanity_labels`, `menu`, `help` | —          |
| `-Profile`        | Profil de volumétrie      | `quick` / `full`                                                                                                                                                | `quick`    |
| `-Label`          | Espace de labels          | `ideology` (binaire) / `crawl` (multiclasse)                                                                                                                    | `ideology` |
| `-Mod`            | Modalité d’entrée         | `web` / `asr` / `gold` / `any`                                                                                                                                  | `web`      |
| `-Suite`          | Famille de modèles        | `all` / `spacy` / `sklearn` / `hf`                                                                                                                              | `all`      |
| `-Arch`           | Arch spaCy                | `bow` / `cnn`                                                                                                                                                   | `bow`      |
| `-Config`         | Preset ressources         | `default` / `debug` / `small_cpu` / `large_cpu`                                                                                                                 | `default`  |
| `-Balance`        | Équilibrage TRAIN         | `none` / `cap_docs` / `cap_tokens` / `alpha_total`                                                                                                              | `none`     |
| `-CapPerLabel`    | K pour `cap_docs`         | entier                                                                                                                                                          | —          |
| `-CapTokens`      | T pour `cap_tokens`       | entier                                                                                                                                                          | —          |
| `-Alpha` `-Total` | α et N pour `alpha_total` | float / entier (>0)                                                                                                                                             | 0.5 / 0    |
| `-UseGPU`         | HF device                 | `0` / `auto`                                                                                                                                                    | `0`        |

> Garde-fou : si `-Balance alpha_total` et `-Total 0`, le script **refuse** et affiche un message clair.

---

## 8) Où apparaissent les résultats (Windows)

* **Intermédiaires** : `data\interim\...`
* **DocBin & labels** : `data\processed\spacy\...`
* **Modèles** : `models\...` (`model-best\` & `model-last\`)
* **Logs** : `.\logs\...log`
* **Rapports** : `.\reports\`
  – ex. `quick_web_corpus.stats.json`, `*_metrics_*.json`, `summary.csv`, `run_meta_*.json`

---

## 9) Exemples “prêts à l’emploi”

### Idéologie, quick, **cap_docs** à 800 + oversample

```powershell
.\pepm.ps1 -Task pipeline `
  -Profile quick -Label ideology -Mod web `
  -Suite spacy `
  -Balance cap_docs -CapPerLabel 800 -Oversample
```

### Crawl, quick, **spaCy matrix** (bow + cnn)

```powershell
.\pepm.ps1 -Task pipeline -Profile quick -Label crawl -Suite spacy
```

### HF seul (CamemBERT) en CPU, 1 époque

```powershell
.\pepm.ps1 -Task pipeline `
  -Profile quick -Label ideology -Suite hf `
  -UseGPU 0 -HFModels "camembert-base" -HFEpochs 1
```

*(Selon ton implémentation, les options HF peuvent se nommer `-HFModels`, `-HFEpochs`, etc. — voir `-Task help`.)*

---

## 10) Dépannage Windows

* **“Running scripts is disabled on this system”**
  Lance d’abord :

  ```powershell
  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
  ```
* **Python introuvable / mauvaise version**
  `python --version` doit renvoyer 3.10–3.12 64-bit.
  Si plusieurs Pythons cohabitent : `py -3.12 -m venv .venv` puis relance `-Task setup`.
* **Erreurs de build de paquets**
  D’abord :

  ```powershell
  python -m pip install -U pip wheel setuptools
  ```

  (Les roues pré-compilées existent pour les libs du projet ; rarement besoin des “Build Tools”.)
* **Longs chemins Windows**
  Évite des chemins très profonds. Si besoin, active “LongPathsEnabled” dans la stratégie système (admin).
* **Encodage**
  Si tu vois des caractères bizarres, tu peux forcer l’UTF-8 dans la session :

  ```powershell
  $env:PYTHONUTF8=1
  ```
* **GPU/CUDA**
  `-UseGPU auto` tentera l’usage d’un GPU si CUDA/cuDNN + drivers sont prêts. Sinon reste en CPU.

---

## 11) Cartographie Makefile ↔ PowerShell (mémo)

| Make                      | PowerShell                                                                                       |
| ------------------------- | ------------------------------------------------------------------------------------------------ |
| `make setup`              | `.\pepm.ps1 -Task setup`                                                                         |
| `make add_modality_web`   | `.\pepm.ps1 -Task add_modality_web`                                                              |
| `make prepare`            | `.\pepm.ps1 -Task prepare -Profile <quick/full> -Label <ideology/crawl> -Mod <web/asr/gold/any>` |
| `make train ARCH=bow`     | `.\pepm.ps1 -Task train -Arch bow -Profile ... -Label ...`                                       |
| `make eval`               | `.\pepm.ps1 -Task eval -Profile ... -Label ...`                                                  |
| `make pipeline SUITE=all` | `.\pepm.ps1 -Task pipeline -Suite all -Profile ... -Label ... -Mod ...`                          |
| `make stats_quick`        | `.\pepm.ps1 -Task stats_quick`                                                                   |
| `make split_quick_dev`    | `.\pepm.ps1 -Task split_quick_dev`                                                               |
| `make aggregate_reports`  | `.\pepm.ps1 -Task aggregate`                                                                     |
| `make run_meta`           | `.\pepm.ps1 -Task run_meta`                                                                      |
| `make sanity_labels`      | `.\pepm.ps1 -Task sanity_labels`                                                                 |

---
