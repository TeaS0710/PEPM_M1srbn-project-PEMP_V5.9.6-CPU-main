# Démarrage & contrôles

```bash
# Installer les deps et modèles
make setup

# Injecter la modalité "web" dans le TEI (si besoin)
make add_modality_web RAW_CORPUS=data/raw/corpus/corpus.xml MODALITY=web

# Vérifications pipeline + échantillonnage rapide
make check MODALITY=web TSV_LIMIT_QUICK=5000

# Générer le squelette idéologie (actor map + YAML)
make ideology MODALITY=web MIN_CHARS=200
```

---

# Pipelines génériques (routing par profil/label)

> Forme canonique – **utilise le routeur** du Makefile
> `make pipeline PROFILE=<quick|full> LABEL_FIELD=<ideology|crawl> MODALITY=<any|web|asr|gold> SUITE=<all|spacy|sklearn|hf> [overrides…]`

### Exemples usuels

```bash
# Quick + ideology, tout (spaCy + sklearn + HF) en CPU
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web SUITE=all USE_GPU=0

# Quick + crawl, uniquement spaCy (bow+cnn)
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=spacy SPACY_ARCHS="bow cnn"

# Quick + crawl, uniquement sklearn
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=sklearn \
  SKLEARN_MODELS="linear_svm,logreg,sgd" UNSUP_MODELS="kmeans,agglo"

# Quick + crawl, uniquement HF (Transformers) en GPU auto
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=hf \
  HF_MODELS="camembert-base,flaubert/flaubert_base_cased" HF_EPOCHS=2 HF_BS=8 USE_GPU=auto

# Full + crawl, spaCy uniquement
make pipeline PROFILE=full LABEL_FIELD=crawl MODALITY=web SUITE=spacy ARCH=bow

# Full + ideology, spaCy uniquement (jeu complet)
make pipeline PROFILE=full LABEL_FIELD=ideology MODALITY=web SUITE=spacy ARCH=cnn
```

---

# Étapes unitaires (préparer/entraîner/évaluer)

```bash
# Alias génériques (route selon PROFILE & LABEL_FIELD)
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web
make train   PROFILE=quick LABEL_FIELD=ideology MODALITY=web ARCH=bow
make eval    PROFILE=quick LABEL_FIELD=ideology MODALITY=web

# Meta run (git + fichiers) pour le couple actif
make run_meta PROFILE=quick LABEL_FIELD=crawl MODALITY=web
```

---

# spaCy – entraînements

```bash
# Matrice bow+cnn sur quick/crawl
make train_spacy_matrix MODALITY=web PROFILE=quick LABEL_FIELD=crawl SPACY_ARCHS="bow cnn"

# Bow uniquement (raccourcis historiques)
make train_spacy_bow  MODALITY=web
make train_spacy_cnn  MODALITY=web

# Évaluation du modèle quick courant
make eval_quick MODALITY=web
# Évaluation du modèle full courant
make eval_full MODALITY=web
```

---

# sklearn – baselines (sup/unsup)

```bash
# Matrice par défaut
make baselines_sklearn_matrix MODALITY=web \
  SKLEARN_MODELS="linear_svm,logreg,sgd,svm_rbf,random_forest,extra_trees" \
  UNSUP_MODELS="kmeans,agglo" \
  # Overrides utiles :
  C_GRID="0.25,0.5,1,2" MAX_FEATURES=200000
```

---

# Hugging Face – baselines

```bash
# CPU (recommandé si pas de GPU)
make hf_quick MODALITY=web USE_GPU=0 \
  HF_MODELS="camembert-base,bert-base-multilingual-cased" HF_EPOCHS=2 HF_BS=8 HF_ACCUM=2 HF_MAXLEN=256 HF_LR=2e-5

# GPU auto (CUDA/ROCm si dispo)
make hf_quick MODALITY=web USE_GPU=auto HF_MODELS="camembert-base" HF_EPOCHS=3 HF_BS=16 HF_ACCUM=2
```

---

# Profils de config (raccourcis)

```bash
# Débogage rapide (petits budgets/époques/limites)
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web CONFIG=debug

# Petites machines CPU
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web CONFIG=small_cpu SUITE=all

# Grosse machine CPU
make pipeline PROFILE=full LABEL_FIELD=crawl MODALITY=web CONFIG=large_cpu SUITE=spacy
```

---

# Modalités & langues

```bash
# Basculer la modalité (filtre TEI)
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=asr
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=gold
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=any   # pas de filtre

# Langue spaCy (tokenizer/sentencizer multi-langue, si dispo)
make train PROFILE=quick LABEL_FIELD=ideology MODALITY=web LANG=xx ARCH=bow
```

---

# Équilibrage / sampling (BALANCE)

```bash
# Sans équilibrage (défaut)
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web BALANCE=none

# Cap documents par label (avec sur-échantillonnage)
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web \
  BALANCE=cap_docs CAP_PER_LABEL=3000 OVERSAMPLE=--oversample

# Cap tokens par label
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web \
  BALANCE=cap_tokens CAP_TOKENS=500000

# Alpha / Total (mix global contrôlé) – nécessite TOTAL>0
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web \
  BALANCE=alpha_total ALPHA=0.5 TOTAL=20000
```

---

# Limites & split DEV

```bash
# Limiter le TSV (ingestion) en quick
make prepare PROFILE=quick LABEL_FIELD=crawl MODALITY=web TSV_LIMIT_QUICK=20000

# Limiter la taille job (éval)
make eval PROFILE=quick LABEL_FIELD=ideology MODALITY=web JOB_LIMIT=1500

# Split train/dev (répéter si tu régénères train.tsv)
make split_quick_dev DEV_PROP=0.2 SEED=123
```

---

# Ressources CPU/RAM (cgroup user)

```bash
# Activer le plafond (systemd-run) et pin CPU cores 0..13
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web CEILING=1 CEIL_CPU=85% CEIL_MEM=35G CEIL_CORES=14
```

---

# Données d’entrée alternatives

```bash
# Utiliser un autre corpus TEI déjà "modality-tagged"
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web CORPUS=data/raw/corpus/mon_corpus_modality.xml

# (si besoin) injecter d’abord la modalité dans un autre XML brut
make add_modality_web RAW_CORPUS=data/raw/corpus/mon_corpus.xml CORPUS=data/raw/corpus/mon_corpus_modality.xml MODALITY=web
```

---

# Exemples « recettes » complètes

```bash
# 1) Idéologie quick, tout CPU, preset débogage, HF camembert
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web SUITE=all CONFIG=debug \
  HF_MODELS=camembert-base USE_GPU=0

# 2) Crawl quick, spaCy only, matrice bow+cnn, labels équilibrés cap_docs
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=spacy \
  SPACY_ARCHS="bow cnn" BALANCE=cap_docs CAP_PER_LABEL=5000

# 3) Idéologie full, spaCy cnn, limite batch large
make pipeline PROFILE=full LABEL_FIELD=ideology MODALITY=web SUITE=spacy \
  ARCH=cnn FULL_BATCH=256

# 4) Crawl quick, sklearn + HF (sans spaCy), GPU auto, HF multi-modèles
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=sklearn HF_MODELS="camembert-base,bert-base-multilingual-cased" \
  && make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=hf USE_GPU=auto HF_EPOCHS=2

# 5) Quick + asr, HF seul, long séquence
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=asr SUITE=hf HF_MAXLEN=512 HF_BS=4 HF_ACCUM=4 USE_GPU=auto
```

---

# Nettoyage

```bash
# Purge des artefacts (splits, .spacy, modèles)
make clean
```
