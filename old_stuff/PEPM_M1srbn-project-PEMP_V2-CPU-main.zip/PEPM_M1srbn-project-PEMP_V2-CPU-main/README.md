# PEPM — Pipeline d’entraînement texte
**Chaîne : web → TEI → TSV → DocBin → modèles (spaCy / Sklearn / HF)**  
**Projet PEPM — Yi Fan & Adrien**

> Classifieur FR (et multilingue via `xx`) conçu pour tourner **entièrement sur CPU** avec une **hygiène de données** et une **hygiène de structure** stricte, une **reproductibilité** forte, et une **scalabilité** raisonnable. Le pipeline est **web‑ready** et **extensible** vers **ASR/GOLD**.

---

## Table des matières
1. [Objectifs & périmètre](#objectifs--périmètre)
2. [Anatomie du dépôt](#anatomie-du-dépôt)
3. [Installation & prérequis](#installation--prérequis)
4. [Données TEI, modalités & sanitation](#données-tei-modalités--sanitation)
5. [Paramétrage global (Makefile)](#paramétrage-global-makefile)
6. [Recettes de commandes **classiques**](#recettes-de-commandes-classiques)
7. [Scripts & CLI (référence rapide)](#scripts--cli-référence-rapide)
8. [Pipeline (schéma Mermaid)](#pipeline-schéma-mermaid)
9. [🚦 Smoke test **copier‑coller**](#-smoke-test-copier-coller)
10. [Métriques, rapports & agrégation](#métriques-rapports--agrégation)
11. [Reproductibilité & journaux](#reproductibilité--journaux)
12. [Performance & volumétrie](#performance--volumétrie)
13. [Dépannage (FAQ)](#dépannage-faq)
14. [Extensibilité ASR/GOLD](#extensibilité-asrgold)
15. [Conventions & style](#conventions--style)
16. [Annexes](#annexes)

---

## 1) Objectifs & périmètre
- **Données** : TEI consolidé → split **TRAIN/JOB** stratifié → TSV → **DocBin (.spacy)**.
- **Modèles** : spaCy (**BOW** ou **CNN**), baselines CPU (TF‑IDF + **SVM/LR/RF/ET**), Transformers **HF** (CamemBERT, Flaubert… en **CPU** par défaut).
- **Équilibrage (TRAIN)** : `none`, `cap_docs`, `cap_tokens`, `alpha_total` (+ `--oversample`).
- **Orchestration Makefile** : change **profil** (quick/full), **label_field** (ideology/crawl), **modality** (web/asr/gold/any), **suite** (spacy/sklearn/hf/all), **config** (debug/small_cpu/large_cpu).
- **Repro** : seeds figées, **sysinfo**, threads BLAS plafonnés, **run_meta** (hashs + git SHA), agrégation **summary.csv**.

---

## 2) Anatomie du dépôt
```
data/
  raw/corpus/corpus.xml           # TEI consolidé (toutes sources)
  raw/corpus/corpus.modality.xml  # TEI après marquage <term type="modality">web</term>
  interim/                        # TSV + dérivés intermédiaires
  processed/spacy/                # DocBin .spacy + labels.json
logs/                             # journaux d’entraînement
models/                           # model-best / model-last
reports/                          # métriques JSON, CSV, images
scripts/                          # outils TEI/TSV/DocBin/train/éval
Makefile                          # orchestration configurable
```

---

## 3) Installation & prérequis
- Linux (Kubuntu OK). **Python ≥ 3.12** recommandé.
- CPU suffit ; spaCy & HF configurés CPU par défaut.

```bash
# 1) Créer et activer l’environnement
python3 -m venv .venv
source .venv/bin/activate

# 2) Installer dépendances, ressources spaCy et utilitaires
make setup

# (optionnel) Informations système (CPU/RAM/threads BLAS)
make sysinfo
```
> Pour quitter : `deactivate`

---

## 4) Données TEI, modalités & sanitation
### 4.1 TEI minimal
- Chaque document est encapsulé en TEI, texte propre + métadonnées.
- **Labels** : `crawl` (multi‑classe) pour l’endo ; `ideology` (binaire) pour l’exo via un mapping YAML.

### 4.2 Marquage de **modalité**
Dans `teiHeader/profileDesc/textClass/keywords` :
`<term type="modality">web</term>`  
Commande utilitaire :
```bash
make add_modality_web RAW_CORPUS=data/raw/corpus/corpus.xml MODALITY=web
```

### 4.3 Segments (pré‑ASR, optionnel)
Prévoir : `<div type="segments"><p n="000-030">…</p></div>` (ne casse pas la chaîne actuelle).

### 4.4 Sanitation (extraction → TSV)
- trims, espaces multiples, normalisation `&nbsp;`, `&quot;`, etc.
- les scripts évitent d’introduire des séquences parasites (`_blank`, tabs…)

---

## 5) Paramétrage global (Makefile)
Vous pouvez **tout piloter** via **variables Make** (pas besoin de modifier les scripts).

### 5.1 Variables principales
| Variable      | Sens                 | Valeurs                                            | Défaut            |
| ------------- | -------------------- | -------------------------------------------------- | ----------------- |
| `PROFILE`     | volumétrie           | `quick` / `full`                                   | `quick`           |
| `LABEL_FIELD` | cible labels         | `ideology` / `crawl`                               | `ideology`        |
| `MODALITY`    | vue source           | `web` / `asr` / `gold` / `any`                     | `web`             |
| `CONFIG`      | preset ressources    | `default` / `debug` / `small_cpu` / `large_cpu`    | `default`         |
| `SUITE`       | familles modèles     | `all` / `spacy` / `sklearn` / `hf`                 | `all`             |
| `ARCH`        | arch spaCy           | `bow` / `cnn`                                      | `bow`             |
| `SPACY_ARCHS` | matrice spaCy        | ex. `bow cnn`                                      | `bow cnn`         |
| `HF_MODELS`   | modèles HF           | CSV (`camembert-base,flaubert/...`)                | `camembert-base`  |
| `BALANCE`     | équilibrage TRAIN    | `none` / `cap_docs` / `cap_tokens` / `alpha_total` | `none`            |
| `TOTAL`       | taille cible (alpha) | `>0` si `alpha_total`                              | `0`               |
| `DEV_PROP`    | split interne DEV    | `0–1`                                              | `0.15`            |
| `JOB_LIMIT`   | plafond éval         | int                                                | `5000`            |

**Garde‑fou** : si `BALANCE=alpha_total` **et** `TOTAL<=0` → erreur explicite (Makefile).

### 5.2 Presets `CONFIG`
- `debug` : époques courtes, limites réduites (**smoke test rapide**).
- `small_cpu` / `large_cpu` : batchs/époques adaptés à la machine.

### 5.3 Quotas (facultatif)
`CEILING=1` active `systemd-run --user` + `taskset` (quotas CPU/RAM/cores).

---

## 6) Recettes de commandes **classiques**
### 6.1 Activation venv & vérifs
```bash
source .venv/bin/activate
make setup
make check MODALITY=web
make sysinfo
```

### 6.2 **Idéologie – quick (BOW par défaut)**
```bash
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web
make train   PROFILE=quick LABEL_FIELD=ideology ARCH=bow
make eval    PROFILE=quick LABEL_FIELD=ideology
```

### 6.3 **Idéologie – full**
```bash
make prepare PROFILE=full LABEL_FIELD=ideology MODALITY=web
make train   PROFILE=full  LABEL_FIELD=ideology ARCH=bow
make eval    PROFILE=full  LABEL_FIELD=ideology
```

### 6.4 **Partis (crawl) – quick**
```bash
make prepare PROFILE=quick LABEL_FIELD=crawl MODALITY=web
make train   PROFILE=quick LABEL_FIELD=crawl ARCH=cnn
make eval    PROFILE=quick LABEL_FIELD=crawl
```

### 6.5 **Pipeline tout‑en‑un (quick)**
```bash
# spaCy + sklearn + HF
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web SUITE=all

# matrices spaCy seulement (bow+cnn)
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=spacy
```

### 6.6 **Baselines sklearn / HF (quick)**
```bash
# sklearn seul
make pipeline PROFILE=quick LABEL_FIELD=crawl SUITE=sklearn

# HF seul (CamemBERT), CPU
make pipeline PROFILE=quick LABEL_FIELD=ideology SUITE=hf HF_MODELS=camembert-base USE_GPU=0 HF_EPOCHS=1
```

---

## 7) Scripts & CLI (référence rapide)
- `scripts/tei_add_modality_stream.py` : ajoute `<term type="modality">VALUE</term>` (web/asr/gold).
  *Args* : `--in`, `--out`, `--value`

- `scripts/pipeline_check.py` : vérifs rapides / mini‑pipeline (entrée TEI).
  *Args* : `--corpus`, `--label-field`, `--limit`, `--modality`, `--auto-offset-scan`

- `scripts/tei_to_train_job.py` : TEI → TSV (TRAIN/JOB) + équilibrage optionnel.
  *Args* : `--corpus`, `--outdir`, `--train-prop`, `--label-field [ideology|crawl]`, `--ideology-map`, `--min-chars`, `--max-tokens`, `--procs`, `--seed`, `--balance-train`, `--limit`, `--modality`

- `scripts/build_spacy_corpus.py` : TSV → DocBin + `labels.json`.
  *Args* : `--tsv`, `--out`, `--labels-out`, `--lang`, `--workers`, `--shard-size`, `--batch-size`, `--limit`

- `scripts/train_core.py` : spaCy Textcat (BOW/CNN).
  *Args* : `--train`, `--dev`, `--out`, `--lang`, `--arch [bow|cnn]`, `--epochs`, `--dropout`, `--batch-start`, `--batch-stop`, `--eval-freq`, `--seed`, `--labels`

- `scripts/sklearn_baselines.py` : TF‑IDF + {LinearSVM, LogReg, SGD, SVM‑RBF, RF, ET} (+ unsup).
  *Args* : `--train`, `--dev`, `--job`, `--models`, `--unsup`, `--outdir`, `--reports`, `--max-features`, `--c-grid`, `--balanced`

- `scripts/hf_baselines.py` : Transformers (CamemBERT, Flaubert…) CPU par défaut.
  *Args* : `--train`, `--dev`, `--job`, `--models`, `--epochs`, `--batch-size`, `--grad-accum`, `--max-len`, `--lr`, `--use-gpu`, `--reports`, `--outdir`

- `scripts/split_train_dev.py` : Split DEV stratifié interne à TRAIN.
  *Args* : `--train-tsv`, `--dev-ratio`, `--seed`, `--out-train`, `--out-dev`

- `scripts/corpus_stats.py` : EDA (counts, longueurs, doublons).
  *Args* : `--tsv ... --out-prefix reports/<prefix>`

- `scripts/metrics_aggregate.py` : agrège toutes les métriques en `reports/summary.csv`.
  *Args* : `--reports-dir`, `--out-csv`

- `scripts/run_meta.py` : hash des TSV, git SHA, horodatage.
  *Args* : `--files ...`, `--out`

- `scripts/sanity_labels.py` : garde‑fou « ≥ 2 labels » + **auto‑patch** via Make.
  *Args* : `--tsv`, `--min-labels`, `--min-per-label`, `--label-col`

---

## 8) Pipeline (schéma Mermaid)
```mermaid
flowchart TD
  %% ===================== SOURCES =====================
  subgraph Sources
    W[Web HTML]
    A[Transcriptions ASR]
    G[Reference gold]
  end

  W --> T1[Unifier TEI]
  A --> T1
  G --> T1

  T1 --> T2[Ajouter terme de modalite]
  T2 --> T3[Nettoyer le texte]
  T3 --> T4[Deduplication MD5]
  T4 --> L{Choisir le champ de label}

  L -- crawl --> L1[Crawl multiclasse]
  L -- ideology --> L2[Ideologie binaire depuis YAML]

  L1 --> S1[Split TRAIN et JOB]
  L2 --> S1

  S1 --> S2[Split DEV depuis TRAIN]
  S1 --> O1[Ecrire TSV TRAIN et JOB]

  S2 --> B{Equilibrer TRAIN}
  B -- none --> B0[TRAIN inchange]
  B -- cap_docs --> B1[Cap par label]
  B -- cap_tokens --> B2[Cap tokens par label]
  B -- alpha_total --> B3[Alpha avec total cible]

  B0 --> C1[Construire DocBin TRAIN et labels json]
  B1 --> C1
  B2 --> C1
  B3 --> C1
  O1 --> C2[Construire DocBin JOB]

  %% ===================== MODELES =====================
  subgraph Modeles
    S[spaCy textcat BOW ou CNN]
    K[Sklearn TF IDF SVM LR SGD RF ExtraTrees]
    H[Transformers HF Camembert Flaubert mBERT]
  end

  C1 --> S
  C1 --> K
  C1 --> H

  %% ===================== SANITY ET PREPARATION =====================
  subgraph Sanity et Preparation
    Q1[Sysinfo]
    Q2[Pipeline check]
    Q3[Sanity labels au moins 2 classes]
  end

  Q1 --> S
  Q2 --> S
  Q2 --> K
  Q2 --> H
  Q3 --> S
  Q3 --> K
  Q3 --> H

  %% ===================== EVALUATION ET RAPPORTS =====================
  subgraph Evaluation et Rapports
    E1[spacy evaluate vers JSON]
    E2[Metriques et confusion pour sklearn et HF]
    A1[Aggregation summary csv]
    M1[Run meta et empreintes donnees]
  end

  S --> E1
  K --> E2
  H --> E2
  E1 --> A1
  E2 --> A1
  O1 --> M1
  C1 --> M1
  C2 --> M1

  %% ===================== ORCHESTRATION MAKEFILE =====================
  subgraph Orchestration Makefile
    P1[Profil quick ou full]
    P2[Champ de label ideology ou crawl]
    P3[Modalite web asr gold any]
    P4[Suite all spacy sklearn hf]
    P5[Config default debug small_cpu large_cpu]
    P6[Arch bow ou cnn]
    P7[Balance none cap_docs cap_tokens alpha_total]
    P8[Ceiling quotas et taskset optionnels]
  end

  P1 --> S1
  P2 --> L
  P3 --> T2
  P4 --> S
  P4 --> K
  P4 --> H
  P5 --> S
  P5 --> K
  P5 --> H
  P6 --> S
  P7 --> B
  P8 --> S
  P8 --> K
  P8 --> H
```

---

## 9) 🚦 Smoke test **copier‑coller**
> Objectif : valider la chaîne E2E **rapidement** en CPU avec garde‑fous mono‑classe.

```bash
# (0) Environnement
python3 -m venv .venv && source .venv/bin/activate
make setup

# (1) Vérif d’entrée + échantillon rapide
make check MODALITY=web TSV_LIMIT_QUICK=2000

# (2) Garde‑fou labels (routeur actif ideology/crawl)
make sanity_labels_active MODALITY=web PROFILE=quick LABEL_FIELD=ideology

# (3) Pipeline minimal spaCy (CPU, époques courtes)
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web CONFIG=debug SUITE=spacy

# (4) Rapports & empreintes (optionnel)
make aggregate_reports && make run_meta
```

**Variantes utiles**  
- Forcer l’acceptation **mono‑classe** (diagnostic) :
```bash
make sanity_labels_active REQUIRE_MULTICLASS=0
```
- Cible **crawl** (multiclasse) :
```bash
make sanity_labels_active LABEL_FIELD=crawl
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web CONFIG=debug SUITE=spacy
```

---

## 10) Métriques, rapports & agrégation
- **spaCy** : `spacy evaluate` → JSON (TOK, TEXTCAT macro‑F, ROC‑AUC binaire).
- **Sklearn/HF** : F1 macro/weighted, Accuracy, AUC (binaire), **confusion** (CSV/PNG).
- **Agrégation** : `reports/summary.csv` centralise les résultats (colonnes clés : `family, arch, balance, seed, train_docs, job_docs, macro_f1, acc, auc, time, ...`).

---

## 11) Reproductibilité & journaux
- Threads plafonnés via env (`OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, etc.).
- **Sysinfo** par run : `make sysinfo`.
- **Run meta** : `scripts/run_meta.py` serialize hashs TSV, git SHA, timestamp.
- Nommage standard des dossiers : `family=…_arch=…_balance=…_seed=…_YYYYMMDD-HHMM` (recommandé).

---

## 12) Performance & volumétrie
- **Caps TRAIN** : `cap_docs` (avec `--oversample`) ou `cap_tokens`.
- **DocBin sharding** : `--shard-size` (10–25k conseillé en full).
- **Batch spaCy** : `--batch-start/--batch-stop` (compounding) + `--eval-freq`.
- **JOB_LIMIT** : limiter l’éval si le JOB est volumineux.
- **HF CPU** : réduire `HF_EPOCHS` et limiter le nombre de modèles (`HF_MODELS`).

---

## 13) Dépannage (FAQ)
- **« Need ≥ 2 distinct labels »** : TRAIN mono‑classe (vérifier `train.tsv`, mapping YAML, filtrage modalité).  
  → `make sanity_labels_active` tente **auto‑patch** (élargit fenêtre : min chars, tokens, limites) jusqu’à `PATCH_TRIES`.
- **Sklearn `n_splits>members`** : augmenter `cap_docs`/`oversample` ou réduire la CV interne.
- **spaCy model introuvable à l’éval** : échec train ; inspecter `logs/run-*.log` et `model-best/`.
- **OOM / lenteur** : baisser `--max-tokens`, réduire `--workers`, augmenter sharding, `CONFIG=debug`.
- **HF trop lent sur CPU** : `HF_EPOCHS=1`, un seul modèle (`HF_MODELS=camembert-base`).

---

## 14) Extensibilité ASR/GOLD
- **Modalité** : `MODALITY=asr|gold` (parsing prêt côté scripts).
- **Segments** : exploiter `div[type=segments]` pour aligner texte/audio.
- **Comparaisons** : text‑only vs audio‑only vs multimodal (mêmes métriques, même agrégateur).

---

## 15) Conventions & style
- **Scripts** : shebang `#!/usr/bin/env python3`, logs `[INFO]/[OK]/[WARN]/[ERR]`.
- **Data** : arborescence `raw/interim/processed/models/reports`.

---

- © Yi Fan & Adrien — 2025.

---

## 16) Annexes

### A — Variables Make (table complète)
| Catégorie   | Variable           | Description       | Valeurs                      | Défaut               |
| ----------- | ------------------ | ----------------- | ---------------------------- | -------------------- |
| Profil      | `PROFILE`          | volumétrie        | `quick`/`full`               | `quick`              |
| Labels      | `LABEL_FIELD`      | cible labels      | `ideology`/`crawl`           | `ideology`           |
| Modalité    | `MODALITY`         | vue source        | `web`/`asr`/`gold`/`any`     | `web`                |
| Suite       | `SUITE`            | familles à lancer | `all`/`spacy`/`sklearn`/`hf` | `all`                |
| HF          | `HF_MODELS`        | liste modèles     | CSV                          | `camembert-base`     |
| HF          | `HF_EPOCHS`        | époques           | int                          | `2`                  |
| HF          | `HF_BS`            | batch size        | int                          | `8`                  |
| HF          | `HF_ACCUM`         | grad accumulation | int                          | `2`                  |
| HF          | `HF_MAXLEN`        | longueur max      | int                          | `256`                |
| HF          | `HF_LR`            | learning rate     | float                        | `2e-5`               |
| HF          | `USE_GPU`          | device            | `0`/`auto`                   | `0`                  |
| spaCy       | `ARCH`             | arch              | `bow`/`cnn`                  | `bow`                |
| spaCy       | `SPACY_ARCHS`      | matrice           | liste                        | `bow cnn`            |
| spaCy       | `EPOCHS_QUICK`     | époques quick     | int                          | `40`                 |
| spaCy       | `EPOCHS_FULL`      | époques full      | int                          | `6`                  |
| Split       | `TRAIN_PROP`       | part TRAIN        | float                        | `0.8`                |
| Split       | `DEV_PROP`         | part DEV          | float                        | `0.15`               |
| Tokens      | `MIN_CHARS`        | filtre            | int                          | `200`                |
| Tokens      | `QUICK_MAX_TOKENS` | quick             | int                          | `600`                |
| Tokens      | `FULL_MAX_TOKENS`  | full              | int                          | `1500`               |
| Limites     | `TSV_LIMIT_QUICK`  | TSV quick         | int                          | `100000`             |
| Limites     | `TSV_LIMIT_IDEO`   | TSV ideo          | int                          | `100000`             |
| Équilibrage | `BALANCE`          | stratégie         | voir §7.3                    | `none`               |
| Équilibrage | `CAP_PER_LABEL`    | cap docs          | int                          | `0`                  |
| Équilibrage | `CAP_TOKENS`       | cap tokens        | int                          | `0`                  |
| Équilibrage | `OVERSAMPLE`       | rééchantillonnage | flag                         | vide                 |
| Alpha       | `ALPHA`            | expo              | float                        | `0.5`                |
| Alpha       | `TOTAL`            | taille cible      | int                          | `0`                  |
| CPU         | `WORKERS`          | processus         | int                          | `14`                 |
| CPU         | `BATCH_START`      | compounding       | int                          | `16`                 |
| CPU         | `BATCH_STOP`       | compounding       | int                          | `64`                 |
| CPU         | `EVAL_FREQ`        | fréquence éval    | iters                        | `50`                 |
| Éval        | `JOB_LIMIT`        | plafond job       | int                          | `5000`               |
| Système     | `CEILING`          | quotas systemd    | 0/1                          | `0`                  |
| Système     | `CEIL_CPU`         | quota CPU         | %                            | `85%`                |
| Système     | `CEIL_MEM`         | quota RAM         | e.g. `35G`                   | `35G`                |
| Système     | `CEIL_CORES`       | CPU set           | int                          | `14`                 |

### B — Jeu de commandes étendu (prêt à copier)
```bash
# Modalité alternative
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=asr
make prepare PROFILE=quick LABEL_FIELD=crawl    MODALITY=gold

# Matrices spaCy (BOW+CNN) d’un coup
make train_spacy_matrix PROFILE=quick LABEL_FIELD=crawl MODALITY=web

# Baselines sklearn (sup. + non‑sup.)
make baselines_sklearn_matrix PROFILE=quick LABEL_FIELD=crawl

# Transformers (CPU)
make hf_quick PROFILE=quick LABEL_FIELD=ideology HF_MODELS=camembert-base USE_GPU=0 HF_EPOCHS=1

# Évaluations
make eval PROFILE=quick LABEL_FIELD=crawl
make eval PROFILE=full  LABEL_FIELD=ideology

# Rapports
make aggregate_reports && make run_meta
```
