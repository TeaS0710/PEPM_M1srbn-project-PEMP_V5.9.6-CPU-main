<#  pepm.ps1 — Windows PowerShell helper for the PEPM_M1srbn-project-PEMP_V2-CPU pipeline
    Usage examples:
      powershell -ExecutionPolicy Bypass -File .\pepm.ps1 -Task menu
      .\pepm.ps1 -Task pipeline -Profile quick -Label ideology -Mod web -Suite all
      .\pepm.ps1 -Task check -Profile quick -Label ideology -Mod web -Limit 2000

    Notes:
      • This script mirrors the Makefile targets with Windows-safe calls.
      • It handles venv detection, paths, multi-class sanity checks, and a simple auto-patch loop.
#>

[CmdletBinding()]
param(
  [ValidateSet("menu","setup","add_modality_web","check",
               "prepare","train","eval","pipeline",
               "stats_quick","split_quick_dev",
               "baselines_sklearn_quick","baselines_sklearn_active",
               "hf_quick","hf_active",
               "aggregate","run_meta","ideology")]
  [string]$Task = "menu",

  # Core switches (mirroring Makefile vars)
  [ValidateSet("quick","full")]
  [string]$Profile = "quick",

  [ValidateSet("ideology","crawl")]
  [string]$Label = "ideology",

  [ValidateSet("any","web","asr","gold")]
  [string]$Mod = "web",

  [ValidateSet("default","debug","small_cpu","large_cpu")]
  [string]$Config = "default",

  [int]$Workers = 14,
  [int]$Seed = 42,
  [string]$Lang = "xx",

  # Limits / sizes
  [double]$TrainProp = 0.8,
  [int]$MinChars = 200,
  [int]$QuickMaxTokens = 600,
  [int]$FullMaxTokens = 1500,
  [int]$QuickLimit = 500,
  [int]$JobLimit = 5000,

  # Ideology-specific
  [string]$IdeologyMap = "data/configs/ideology.yml",
  [int]$IdeoQuickMaxTokens = 350,
  [int]$IdeoQuickTSVLimit = 20000,
  [int]$IdeoQuickShard = 1000,
  [int]$IdeoQuickBatch = 32,
  [int]$JobLimitIdeoQuick = 1000,

  [int]$IdeoFullMaxTokens = $FullMaxTokens,
  [int]$IdeoFullTSVLimit = 0,
  [int]$IdeoFullShard = 25000,
  [int]$IdeoFullBatch = 128,
  [int]$JobLimitIdeoFull = 10000,

  # Training
  [ValidateSet("bow","cnn")]
  [string]$Arch = "bow",
  [int]$EpochsQuick = 40,
  [int]$EpochsFull = 6,
  [int]$EpochsIdeoQuick = 50,
  [int]$EpochsIdeoFull = 6,
  [int]$BatchStart = 16,
  [int]$BatchStop = 64,
  [int]$EvalFreq = 50,

  # Sanity / auto-patch
  [int]$RequireMulticlass = 1,
  [int]$PatchTries = 2,
  [int]$PatchTSVLimit = 20000,
  [int]$PatchMinChars = 150,
  [int]$PatchMaxTokens = 600,

  # Suite selector for pipeline
  [ValidateSet("all","spacy","sklearn","hf")]
  [string]$Suite = "all"
)

# ---------- Helpers ----------
function Get-Python {
  $venvPy = Join-Path ".venv" "Scripts\python.exe"
  if (Test-Path $venvPy) { return $venvPy }
  return "python"
}

$PY = Get-Python

# Create required folders
$null = New-Item -ItemType Directory -Force -Path "reports","logs","data\processed\spacy","data\interim","models" | Out-Null

# Environment (threads)
$env:OMP_NUM_THREADS = $Workers
$env:OPENBLAS_NUM_THREADS = $Workers
$env:MKL_NUM_THREADS = $Workers
$env:NUMEXPR_NUM_THREADS = $Workers
$env:MALLOC_ARENA_MAX = 2
$env:TOKENIZERS_PARALLELISM = "false"

# Derived paths
$RAW_CORPUS = "data/raw/corpus/corpus.xml"
$CORPUS = "data/raw/corpus/corpus.modality.xml"

$INTERIM = "data/interim"
$QUICK_SPLITS = Join-Path $INTERIM ("quick_{0}" -f $Mod)
$FULL_SPLITS  = Join-Path $INTERIM ("full_{0}" -f $Mod)
$IDEO_SPLITS  = Join-Path $INTERIM ("ideo_{0}" -f $Mod)

$SPACY = "data/processed/spacy"
$QUICK_TRAIN_DIR = Join-Path $SPACY ("quick_{0}_train" -f $Mod)
$QUICK_JOB_DIR   = Join-Path $SPACY ("quick_{0}_job" -f $Mod)
$QUICK_LABELS    = Join-Path $SPACY ("quick_{0}_labels.json" -f $Mod)

$FULL_TRAIN_DIR = Join-Path $SPACY ("full_{0}_train" -f $Mod)
$FULL_JOB_DIR   = Join-Path $SPACY ("full_{0}_job" -f $Mod)
$FULL_LABELS    = Join-Path $SPACY ("full_{0}_labels.json" -f $Mod)

$IDEO_QUICK_TRAIN_DIR = Join-Path $SPACY ("ideo_{0}_train" -f $Mod)
$IDEO_QUICK_JOB_DIR   = Join-Path $SPACY ("ideo_{0}_job" -f $Mod)
$IDEO_QUICK_LABELS    = Join-Path $SPACY ("ideo_{0}_labels.json" -f $Mod)

$IDEO_FULL_TRAIN_DIR = Join-Path $SPACY ("ideo_{0}_train_full" -f $Mod)
$IDEO_FULL_JOB_DIR   = Join-Path $SPACY ("ideo_{0}_job_full" -f $Mod)
$IDEO_FULL_LABELS    = Join-Path $SPACY ("ideo_{0}_labels_full.json" -f $Mod)

$MODELS = "models"
$SPACY_QUICK_MODEL = Join-Path $MODELS ("spacy_quick_{0}" -f $Mod)
$SPACY_FULL_MODEL  = Join-Path $MODELS ("spacy_full_{0}" -f $Mod)
$IDEO_QUICK_MODEL_DIR = Join-Path $MODELS ("spacy_ideo_quick_{0}" -f $Mod)
$IDEO_FULL_MODEL_DIR  = Join-Path $MODELS ("spacy_ideo_full_{0}" -f $Mod)

# Active (like Makefile's ACTIVE_*)
if ($Label -eq "ideology") {
  $ACTIVE_SPLITS = $IDEO_SPLITS
  if ($Profile -eq "quick") {
    $ACTIVE_TRAIN_DIR = $IDEO_QUICK_TRAIN_DIR
    $ACTIVE_JOB_DIR   = $IDEO_QUICK_JOB_DIR
    $ACTIVE_LABELS    = $IDEO_QUICK_LABELS
    $ACTIVE_MODEL_DIR = $IDEO_QUICK_MODEL_DIR
    $ACTIVE_BATCH     = $IdeoQuickBatch
    $ACTIVE_JOB_LIMIT = $JobLimitIdeoQuick
  } else {
    $ACTIVE_TRAIN_DIR = $IDEO_FULL_TRAIN_DIR
    $ACTIVE_JOB_DIR   = $IDEO_FULL_JOB_DIR
    $ACTIVE_LABELS    = $IDEO_FULL_LABELS
    $ACTIVE_MODEL_DIR = $IDEO_FULL_MODEL_DIR
    $ACTIVE_BATCH     = $IdeoFullBatch
    $ACTIVE_JOB_LIMIT = $JobLimitIdeoFull
  }
} else {
  if ($Profile -eq "quick") {
    $ACTIVE_SPLITS = $QUICK_SPLITS
    $ACTIVE_TRAIN_DIR = $QUICK_TRAIN_DIR
    $ACTIVE_JOB_DIR   = $QUICK_JOB_DIR
    $ACTIVE_LABELS    = $QUICK_LABELS
    $ACTIVE_MODEL_DIR = $SPACY_QUICK_MODEL
    $ACTIVE_BATCH     = 64
    $ACTIVE_JOB_LIMIT = $JobLimit
  } else {
    $ACTIVE_SPLITS = $FULL_SPLITS
    $ACTIVE_TRAIN_DIR = $FULL_TRAIN_DIR
    $ACTIVE_JOB_DIR   = $FULL_JOB_DIR
    $ACTIVE_LABELS    = $FULL_LABELS
    $ACTIVE_MODEL_DIR = $SPACY_FULL_MODEL
    $ACTIVE_BATCH     = 128
    $ACTIVE_JOB_LIMIT = $JobLimit
  }
}

function Invoke-Run([string]$Exe, [string[]]$Args) {
  Write-Host "[RUN]" $Exe $Args
  & $Exe @Args
  if ($LASTEXITCODE -ne 0) {
    throw "Command failed: $Exe $($Args -join ' ')"
  }
}

function Do-Setup {
  Invoke-Run $PY @("-m","pip","install","--upgrade","pip")
  Invoke-Run $PY @("-m","pip","install","-r","requirements.txt")
  Invoke-Run $PY @("-m","spacy","download","xx_sent_ud_sm")
  Invoke-Run $PY @("-m","pip","install","pyyaml")
}

function Do-AddModalityWeb {
  if (-not (Test-Path $RAW_CORPUS)) { throw "Missing $RAW_CORPUS" }
  Invoke-Run $PY @("scripts/tei_add_modality_stream.py","--in",$RAW_CORPUS,"--out",$CORPUS,"--value",$Mod)
}

function Do-IdeologySkeleton {
  Invoke-Run $PY @("scripts/make_ideology_skeleton.py",
    "--corpus",$CORPUS,"--out-yaml","data/configs/ideology.yml",
    "--out-report","data/configs/actors_counts.tsv",
    "--min-chars",$MinChars.ToString(),"--top-variants","3")
}

function Do-Check {
  if (-not (Test-Path $CORPUS)) { Write-Host "Missing $CORPUS → running add_modality_web"; Do-AddModalityWeb }
  # pipeline_check.py expects label-field in {crawl, ideology_map}
  $checkLabel = if ($Label -eq "ideology") { "ideology_map" } else { "crawl" }
  $args = @("scripts/pipeline_check.py",
            "--corpus",$CORPUS,
            "--label-field",$checkLabel,
            "--limit","2000",
            "--modality",$Mod,
            "--auto-offset-scan")
  if ($checkLabel -eq "ideology_map") { $args += @("--ideology-map",$IdeologyMap) }
  Invoke-Run $PY $args
}

# ---------- Prepare ----------
function Prepare-Ideology([string]$mode) {
  $isQuick = ($mode -eq "quick")
  $outdir = $IDEO_SPLITS
  $maxTokens = if ($isQuick) { $IdeoQuickMaxTokens } else { $IdeoFullMaxTokens }
  $workers = if ($isQuick) { $IdeoQuickBatch } else { $Workers }
  $limit = if ($isQuick) { $IdeoQuickTSVLimit } else { $IdeoFullTSVLimit }

  $args = @("scripts/tei_to_train_job.py",
    "--corpus",$CORPUS,"--outdir",$outdir,
    "--train-prop",$TrainProp.ToString(),"--label-field","ideology",
    "--ideology-map",$IdeologyMap,
    "--min-chars",$MinChars.ToString(),"--max-tokens",$maxTokens.ToString(),
    "--procs",$Workers.ToString(),"--seed",$Seed.ToString(),
    "--balance-train","none","--limit",$limit.ToString(),
    "--modality",$Mod
  )
  Invoke-Run $PY $args

  if ($isQuick) {
    Invoke-Run $PY @("scripts/build_spacy_corpus.py",
      "--tsv", (Join-Path $outdir "train.tsv"),
      "--out", $IDEO_QUICK_TRAIN_DIR,
      "--labels-out", $IDEO_QUICK_LABELS,
      "--lang", $Lang, "--workers", "6",
      "--shard-size", $IdeoQuickShard.ToString(),
      "--batch-size", $IdeoQuickBatch.ToString()
    )
    Invoke-Run $PY @("scripts/build_spacy_corpus.py",
      "--tsv", (Join-Path $outdir "job.tsv"),
      "--out", $IDEO_QUICK_JOB_DIR,
      "--labels-out", $IDEO_QUICK_LABELS,
      "--lang", $Lang, "--workers", "6",
      "--shard-size", $IdeoQuickShard.ToString(),
      "--batch-size", $IdeoQuickBatch.ToString(),
      "--limit", $JobLimitIdeoQuick.ToString()
    )
  } else {
    Invoke-Run $PY @("scripts/build_spacy_corpus.py",
      "--tsv", (Join-Path $outdir "train.tsv"),
      "--out", $IDEO_FULL_TRAIN_DIR,
      "--labels-out", $IDEO_FULL_LABELS,
      "--lang", $Lang, "--workers", $Workers.ToString(),
      "--shard-size", $IdeoFullShard.ToString(),
      "--batch-size", $IdeoFullBatch.ToString()
    )
    Invoke-Run $PY @("scripts/build_spacy_corpus.py",
      "--tsv", (Join-Path $outdir "job.tsv"),
      "--out", $IDEO_FULL_JOB_DIR,
      "--labels-out", $IDEO_FULL_LABELS,
      "--lang", $Lang, "--workers", $Workers.ToString(),
      "--shard-size", $IdeoFullShard.ToString(),
      "--batch-size", $IdeoFullBatch.ToString()
    )
  }
}

function Prepare-Crawl([string]$mode) {
  $isQuick = ($mode -eq "quick")
  $outdir = if ($isQuick) { $QUICK_SPLITS } else { $FULL_SPLITS }
  $maxTokens = if ($isQuick) { $QuickMaxTokens } else { $FullMaxTokens }
  $tsvLimit = if ($isQuick) { 100000 } else { 0 }

  $args = @("scripts/tei_to_train_job.py",
    "--corpus",$CORPUS,"--outdir",$outdir,
    "--train-prop",$TrainProp.ToString(),"--label-field","crawl",
    "--min-chars",$MinChars.ToString(),"--max-tokens",$maxTokens.ToString(),
    "--procs",$Workers.ToString(),"--seed",$Seed.ToString(),
    "--balance-train","none","--limit",$tsvLimit.ToString(),
    "--modality",$Mod
  )
  Invoke-Run $PY $args

  $trainDir = if ($isQuick) { $QUICK_TRAIN_DIR } else { $FULL_TRAIN_DIR }
  $jobDir   = if ($isQuick) { $QUICK_JOB_DIR } else { $FULL_JOB_DIR }
  $labels   = if ($isQuick) { $QUICK_LABELS } else { $FULL_LABELS }
  $shard    = if ($isQuick) { 8000 } else { 25000 }
  $batch    = if ($isQuick) { 64 } else { 128 }
  $limitJob = if ($isQuick) { $JobLimit } else { $JobLimit }

  Invoke-Run $PY @("scripts/build_spacy_corpus.py",
      "--tsv", (Join-Path $outdir "train.tsv"),
      "--out", $trainDir,
      "--labels-out", $labels,
      "--lang", $Lang, "--workers", $Workers.ToString(),
      "--shard-size", $shard.ToString(),
      "--batch-size", $batch.ToString(),
      "--limit", (if ($isQuick) { $QuickLimit } else { 0 }).ToString()
  )
  Invoke-Run $PY @("scripts/build_spacy_corpus.py",
      "--tsv", (Join-Path $outdir "job.tsv"),
      "--out", $jobDir,
      "--labels-out", $labels,
      "--lang", $Lang, "--workers", $Workers.ToString(),
      "--shard-size", $shard.ToString(),
      "--batch-size", $batch.ToString(),
      "--limit", $limitJob.ToString()
  )
}

function Do-Prepare {
  if ($Label -eq "ideology") { Prepare-Ideology $Profile } else { Prepare-Crawl $Profile }
}

# ---------- Stats / split ----------
function Do-StatsQuick {
  if (-not (Test-Path (Join-Path $QUICK_SPLITS "train.tsv"))) { Do-Prepare }
  Invoke-Run $PY @("scripts/corpus_stats.py",
    "--tsv", (Join-Path $QUICK_SPLITS "train.tsv"), (Join-Path $QUICK_SPLITS "job.tsv"),
    "--out-prefix", ("reports/quick_{0}_corpus" -f $Mod))
}

function Do-SplitQuickDev {
  Do-StatsQuick
  Invoke-Run $PY @("scripts/split_train_dev.py",
    "--train-tsv",(Join-Path $QUICK_SPLITS "train.tsv"),
    "--dev-ratio",$([string]([math]::Round($args=null; $DEV_PROP=0.15; $DEV_PROP,2))).Replace(",","."),
    "--seed",$Seed.ToString(),
    "--out-train",(Join-Path $QUICK_SPLITS "train_train.tsv"),
    "--out-dev",(Join-Path $QUICK_SPLITS "train_dev.tsv"))
}

function Do-StatsActive {
  if (-not (Test-Path (Join-Path $ACTIVE_SPLITS "train.tsv"))) { Do-Prepare }
  Invoke-Run $PY @("scripts/corpus_stats.py",
    "--tsv", (Join-Path $ACTIVE_SPLITS "train.tsv"), (Join-Path $ACTIVE_SPLITS "job.tsv"),
    "--out-prefix", ("reports/{0}_{1}_{2}_corpus" -f $Label,$Profile,$Mod))
}

function Do-SplitActiveDev {
  Do-StatsActive
  Invoke-Run $PY @("scripts/split_train_dev.py",
    "--train-tsv",(Join-Path $ACTIVE_SPLITS "train.tsv"),
    "--dev-ratio","0.15","--seed",$Seed.ToString(),
    "--out-train",(Join-Path $ACTIVE_SPLITS "train_train.tsv"),
    "--out-dev",(Join-Path $ACTIVE_SPLITS "train_dev.tsv"))
}

# ---------- Sanity w/ auto-patch ----------
function Do-SanityActive {
  Do-Prepare
  $trainTsv = Join-Path $ACTIVE_SPLITS "train.tsv"
  $try = 0
  while ($true) {
    Invoke-Run $PY @("scripts/sanity_labels.py","--tsv",$trainTsv,"--min-labels","2") 2>$null
    if ($LASTEXITCODE -eq 0) { Write-Host "[SANITY] OK: >=2 classes."; break }
    if ($RequireMulticlass -ne 1) { Write-Host "[SANITY] 1 classe acceptée (REQUIRE_MULTICLASS=0)."; break }
    $try++
    if ($try -ge $PatchTries) { throw "[AUTO-PATCH][FAIL] Toujours 1 classe après $try tentative(s)." }
    Write-Host "[AUTO-PATCH] 1 classe détectée → rebuild splits (try $try)"
    # Re-run prepare with widened window
    if ($Label -eq "ideology") {
      $oldMin = $MinChars; $oldTokQ = $IdeoQuickMaxTokens; $oldTok = $QuickMaxTokens
      $MinChars = $PatchMinChars; $IdeoQuickTSVLimit = $PatchTSVLimit; $IdeoQuickMaxTokens = $PatchMaxTokens
      $QuickMaxTokens = $PatchMaxTokens
      Prepare-Ideology $Profile
      # restore (optional)
      $MinChars = $oldMin; $IdeoQuickMaxTokens = $oldTokQ; $QuickMaxTokens = $oldTok
    } else {
      $oldMin = $MinChars; $oldTok = $QuickMaxTokens
      $MinChars = $PatchMinChars; $QuickMaxTokens = $PatchMaxTokens
      Prepare-Crawl $Profile
      $MinChars = $oldMin; $QuickMaxTokens = $oldTok
    }
  }
}

# ---------- Train / Eval ----------
function Do-Train {
  Do-SanityActive
  $trainDir = $ACTIVE_TRAIN_DIR
  $devDir   = $ACTIVE_JOB_DIR
  $outDir   = $ACTIVE_MODEL_DIR
  $epochs   = if ($Label -eq "ideology") { if ($Profile -eq "quick") { $EpochsIdeoQuick } else { $EpochsIdeoFull } } else { if ($Profile -eq "quick") { $EpochsQuick } else { $EpochsFull } }

  Invoke-Run $PY @("scripts/train_core.py",
    "--train",$trainDir,"--dev",$devDir,"--out",$outDir,
    "--lang",$Lang,"--arch",$Arch,
    "--epochs",$epochs.ToString(),"--dropout","0.2",
    "--batch-start",$BatchStart.ToString(),"--batch-stop",$BatchStop.ToString(),"--eval-freq",$EvalFreq.ToString(),
    "--seed",$Seed.ToString(),"--labels",$ACTIVE_LABELS)
}

function Do-Eval {
  $modelPath = if (Test-Path (Join-Path $ACTIVE_MODEL_DIR "model-best")) { Join-Path $ACTIVE_MODEL_DIR "model-best" } else { Join-Path $ACTIVE_MODEL_DIR "model-last" }
  $tmp = Join-Path ([System.IO.Path]::GetTempPath()) ("job_{0}.spacy" -f ([System.Guid]::NewGuid().ToString("N")))
  Invoke-Run $PY @("scripts/build_spacy_corpus.py",
    "--tsv",(Join-Path $ACTIVE_SPLITS "job.tsv"),
    "--out",$tmp,"--labels-out",$ACTIVE_LABELS,
    "--lang",$Lang,"--workers","1",
    "--shard-size","0","--batch-size",$ACTIVE_BATCH.ToString(),
    "--limit",$ACTIVE_JOB_LIMIT.ToString())
  $outJson = if ($Label -eq "ideology") { "reports/ideo_{0}_metrics_{1}.json" -f $Profile,$Mod } else { "reports/{0}_metrics_{1}_{2}.json" -f $Profile,$Mod,$Label }
  Invoke-Run $PY @("-m","spacy","evaluate",$modelPath,$tmp,"--output",$outJson)
  Remove-Item -Force $tmp
}

# ---------- Baselines / HF ----------
function Do-BaselinesSklearnQuick {
  Do-SplitQuickDev
  Invoke-Run $PY @("scripts/sklearn_baselines.py",
    "--train",(Join-Path $QUICK_SPLITS "train_train.tsv"),
    "--dev",(Join-Path $QUICK_SPLITS "train_dev.tsv"),
    "--job",(Join-Path $QUICK_SPLITS "job.tsv"),
    "--models","linear_svm,logreg,sgd,svm_rbf,random_forest,extra_trees",
    "--unsup","kmeans,agglo",
    "--outdir",(Join-Path "models" ("sklearn_quick_{0}" -f $Mod)),
    "--reports","reports","--max-features","200000","--c-grid","0.25,0.5,1,2","--balanced")
}

function Do-BaselinesSklearnActive {
  Do-SplitActiveDev
  Invoke-Run $PY @("scripts/sklearn_baselines.py",
    "--train",(Join-Path $ACTIVE_SPLITS "train_train.tsv"),
    "--dev",(Join-Path $ACTIVE_SPLITS "train_dev.tsv"),
    "--job",(Join-Path $ACTIVE_SPLITS "job.tsv"),
    "--models","linear_svm,logreg,sgd,svm_rbf,random_forest,extra_trees",
    "--unsup","kmeans,agglo",
    "--outdir",(Join-Path "models" ("sklearn_{0}_{1}" -f $Profile,$Mod)),
    "--reports","reports","--max-features","200000","--c-grid","0.25,0.5,1,2","--balanced")
}

function Do-HFQuick {
  Do-SplitQuickDev
  Invoke-Run $PY @("scripts/hf_baselines.py",
    "--train",(Join-Path $QUICK_SPLITS "train_train.tsv"),
    "--dev",(Join-Path $QUICK_SPLITS "train_dev.tsv"),
    "--job",(Join-Path $QUICK_SPLITS "job.tsv"),
    "--models","camembert-base,flaubert/flaubert_base_cased,bert-base-multilingual-cased",
    "--epochs","2","--batch-size","8","--grad-accum","2","--max-len","256","--lr","2e-5",
    "--use-gpu","0",
    "--reports","reports",
    "--outdir",(Join-Path "models" ("hf_quick_{0}" -f $Mod))
  )
}

function Do-HFActive {
  Do-SplitActiveDev
  Invoke-Run $PY @("scripts/hf_baselines.py",
    "--train",(Join-Path $ACTIVE_SPLITS "train_train.tsv"),
    "--dev",(Join-Path $ACTIVE_SPLITS "train_dev.tsv"),
    "--job",(Join-Path $ACTIVE_SPLITS "job.tsv"),
    "--models","camembert-base,flaubert/flaubert_base_cased,bert-base-multilingual-cased",
    "--epochs","2","--batch-size","8","--grad-accum","2","--max-len","256","--lr","2e-5",
    "--use-gpu","0",
    "--reports","reports",
    "--outdir",(Join-Path "models" ("hf_{0}_{1}" -f $Profile,$Mod))
  )
}

function Do-Aggregate {
  Invoke-Run $PY @("scripts/metrics_aggregate.py","--reports-dir","reports","--out-csv","reports/summary.csv")
}

function Do-RunMeta {
  Invoke-Run $PY @("scripts/run_meta.py","--files",(Join-Path $ACTIVE_SPLITS "train.tsv"),(Join-Path $ACTIVE_SPLITS "job.tsv"),
    "--out",("reports/run_meta_{0}_{1}_{2}.json" -f $Mod,$Label,$Profile))
}

# ---------- Pipeline ----------
function Do-Pipeline {
  Do-Prepare
  if ($Profile -eq "quick") {
    Do-StatsActive
    Do-SplitActiveDev
  }
  switch ($Suite) {
    "all" {
      Do-Train
      Do-Eval
      if ($Profile -eq "quick") {
        Do-BaselinesSklearnActive
        Do-HFActive
      }
    }
    "spacy" { Do-Train; Do-Eval }
    "sklearn" { if ($Profile -eq "quick") { Do-BaselinesSklearnActive } else { Write-Host "[INFO] sklearn suite mostly targets quick profile." } }
    "hf" { if ($Profile -eq "quick") { Do-HFActive } else { Write-Host "[INFO] hf suite mostly targets quick profile." } }
  }
  Do-Aggregate
  Do-RunMeta
}

function Show-Menu {
  @"
pepm.ps1 quick menu
  setup                       → Install deps and models
  add_modality_web            → Create modality-filtered corpus
  check                       → Quick end-to-end smoke scan (auto-offset)
  prepare                     → Build splits + spaCy corpora (according to -Label / -Profile)
  stats_quick | split_quick_dev
  train / eval                → Train spacy model and evaluate
  baselines_sklearn_quick     → Quick sklearn baselines (uses quick splits)
  baselines_sklearn_active    → Baselines on ACTIVE splits (Label/Profile aware)
  hf_quick | hf_active        → HF baselines (quick/active)
  pipeline                    → Full pipeline
Examples:
  .\pepm.ps1 -Task setup
  .\pepm.ps1 -Task check -Profile quick -Label ideology -Mod web
  .\pepm.ps1 -Task pipeline -Profile quick -Label ideology -Mod web -Suite all
"@ | Write-Host
}

# ---------- Dispatch ----------
switch ($Task) {
  "menu"                     { Show-Menu }
  "setup"                    { Do-Setup }
  "add_modality_web"         { Do-AddModalityWeb }
  "check"                    { Do-Check }
  "prepare"                  { Do-Prepare }
  "train"                    { Do-Train }
  "eval"                     { Do-Eval }
  "pipeline"                 { Do-Pipeline }
  "stats_quick"              { Do-StatsQuick }
  "split_quick_dev"          { Do-SplitQuickDev }
  "baselines_sklearn_quick"  { Do-BaselinesSklearnQuick }
  "baselines_sklearn_active" { Do-BaselinesSklearnActive }
  "hf_quick"                 { Do-HFQuick }
  "hf_active"                { Do-HFActive }
  "aggregate"                { Do-Aggregate }
  "run_meta"                 { Do-RunMeta }
  "ideology"                 { Do-IdeologySkeleton }
}
