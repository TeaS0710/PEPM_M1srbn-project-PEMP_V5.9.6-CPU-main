Oui. Ton script **intègre déjà un rééquilibrage optionnel** côté *TRAIN uniquement* via `--balance-train {cap_docs, cap_tokens, alpha_total}` (le *JOB* reste intact).

* **`cap_docs`** : limite le **nombre de docs par label** (avec option `--oversample` pour **dupliquer** les minoritaires).
* **`cap_tokens`** : limite le **nombre total de tokens par label** (peut dupliquer pour atteindre le cap).
* **`alpha_total`** : tire un échantillon de taille `--total` avec quotas ∝ `count^alpha` (peut **downsampler** des majoritaires).

### “Équilibrage qui ne coupe pas les données”

Oui, tu peux l’obtenir avec **oversampling sans downsampling** en utilisant `cap_docs` **et** en réglant `--cap-per-label` sur la **taille de la classe majoritaire** (ou plus grand).

* Commande-type :

  ```
  --balance-train cap_docs --oversample --cap-per-label Nmax
  ```

  → les **majoritaires sont tous conservés**, les **minoritaires sont dupliqués** (suffixes `#dup1`, etc.), donc **aucune coupure**.

> ⚠️ Si `--cap-per-label` est **plus petit** que la taille de la classe majoritaire, alors il y aura **downsampling** des majoritaires (ce que tu ne veux pas). Idem, `alpha_total` peut couper si `--total` est trop petit.

### Astuce pratique

* Fais d’abord un split sans rééquilibrage (`--balance-train none`) pour lire les **comptes par label** dans les logs, prends le **Nmax** du *TRAIN*, puis relance avec `cap_docs --oversample --cap-per-label Nmax`.

Si tu veux, je peux te proposer un mini patch pour un mode “auto” qui calcule `Nmax` tout seul et évite toute coupure par défaut.



Bonne question 👇

## Est-ce que l’absence de `model-best/` altère l’analyse ?

* **Techniquement, non** : grâce à ton fallback, l’éval **tourne** (sur `model-last/`) et le JSON est bien produit.
* **Scientifiquement, potentiellement oui (un peu)** :

  * `model-best/` = **meilleure** checkpoint sur le **DEV** (au moment des évaluations).
  * `model-last/` = **dernier** état après la dernière itération.
  * Si l’entraînement **sur-apprend** en fin de run, `model-last` peut être **moins bon** que le meilleur point intermédiaire → tes métriques peuvent être légèrement **pessimistes**.
  * Inversement, s’il **progressait encore**, `model-last` peut être **aussi bon** ou meilleur.

## Recommandé pour éviter toute ambiguïté

1. **Forcer la création du `model-best/`** :

   * lance le train avec des évaluations fréquentes : `EVAL_FREQ=1` (ou 50) et des `epochs` un poil plus haut.
   * ex.

     ```bash
     make train_ideo EVAL_FREQ=1
     make train_quick EVAL_FREQ=1
     ```
2. **Transparence** : garde ton fallback mais **évalue aussi les deux** quand c’est possible et compare :

   ```bash
   # Idéologie
   python -m spacy evaluate models/spacy_ideo/model-last data/processed/spacy/ideo_job.spacy --output reports/ideo_metrics_last.json
   [ -d models/spacy_ideo/model-best ] && \
   python -m spacy evaluate models/spacy_ideo/model-best data/processed/spacy/ideo_job.spacy --output reports/ideo_metrics_best.json || true

   # Partis
   python -m spacy evaluate models/spacy_quick/model-last data/processed/spacy/quick_job.spacy --output reports/parties_metrics_last.json
   [ -d models/spacy_quick/model-best ] && \
   python -m spacy evaluate models/spacy_quick/model-best data/processed/spacy/quick_job.spacy --output reports/parties_metrics_best.json || true
   ```

   → Si les scores sont proches : OK. Si `best` > `last`, garde `best` comme métrique “officielle”.

## Séquence prudente (RAM friendly) à lancer maintenant

```bash
# 1) Idéologie
make WORKERS=4 BALANCE=none prepare_ideo
make WORKERS=4 EVAL_FREQ=1 train_ideo
make JOB_LIMIT=20000 eval_ideo               # JSON garanti (fallback last), échantillon léger
# (option) comparer best vs last comme ci-dessus

# 2) Partis
make WORKERS=4 BALANCE=none QUICK_LIMIT=1000 prepare_quick
make WORKERS=4 EVAL_FREQ=1 train_quick
make JOB_LIMIT=20000 eval_parties
# (option) comparer best vs last
```

### TL;DR

* Ton patch **évite le crash** et **produit** bien le JSON.
* L’analyse reste valable, mais peut être **légèrement sous-optimale** si `model-last` < `model-best`.
* Mets `EVAL_FREQ=1` (ou faible) et, si besoin, **évalue les deux** pour être sûr.

# 0) Reset propre + install
make clean
make setup
make sysinfo

# 1) Idéologie (baseline sans équilibrage)
make WORKERS=4 BALANCE=none prepare_ideo
# (check rapide : ≥2 labels)
awk -F'\t' 'NR>1{c[$2]++} END{for(k in c) printf "%7d %s\n", c[k], k}' data/interim/ideo/train.tsv
# train + eval "light"
make WORKERS=4 train_ideo
make JOB_LIMIT=20000 eval_ideo
jq . reports/ideo_metrics.json | head -60

# 2) Partis (baseline)
make WORKERS=4 BALANCE=none QUICK_LIMIT=1000 prepare_quick
awk -F'\t' 'NR>1{c[$2]++} END{for(k in c) printf "%7d %s\n", c[k], k}' data/interim/quick/train.tsv | sort -nr | head
make WORKERS=4 train_quick
make JOB_LIMIT=20000 eval_parties
jq . reports/parties_metrics.json | head -80

# 3) (optionnel) Équilibrage sans coupe si besoin
#   Idéologie :
NMAX=$(awk -F'\t' 'NR>1{c[$2]++} END{for(k in c){if(c[k]>m)m=c[k]} print m}' data/interim/ideo/train.tsv); echo Nmax=$NMAX
make WORKERS=4 BALANCE=cap_docs CAP_PER_LABEL=$NMAX OVERSAMPLE=--oversample prepare_ideo
make WORKERS=4 train_ideo
make JOB_LIMIT=0 eval_ideo

#   Partis :
NMAX=$(awk -F'\t' 'NR>1{c[$2]++} END{for(k in c){if(c[k]>m)m=c[k]} print m}' data/interim/quick/train.tsv); echo Nmax=$NMAX
make WORKERS=4 BALANCE=cap_docs CAP_PER_LABEL=$NMAX OVERSAMPLE=--oversample prepare_quick
make WORKERS=4 train_quick
make JOB_LIMIT=0 eval_parties

# 0) Environnement OK
make sysinfo

# 1) Idéologie – entraînement avec checkpoints fréquents (pour susciter un model-best/)
make WORKERS=4 BALANCE=none prepare_ideo
make WORKERS=4 EVAL_FREQ=1 train_ideo

# 2) Évaluation “safe” par paliers (baisse des threads BLAS + JOB_LIMIT progressif)
make JOB_LIMIT=2000  OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 eval_ideo
make JOB_LIMIT=5000  OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 eval_ideo
# si la RAM tient :
make JOB_LIMIT=10000 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 eval_ideo
# et ainsi de suite…

# 3) Partis – pipeline rapide et éval prudente
make WORKERS=4 BALANCE=none QUICK_LIMIT=1000 prepare_quick
make WORKERS=4 EVAL_FREQ=1 train_quick
make JOB_LIMIT=2000  OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 eval_parties
make JOB_LIMIT=5000  OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 eval_parties


Je vois ce qui t’arrive : tu lances `eval_ideo` avec `JOB_LIMIT=2000`, **mais le `job.spacy` n’est pas reconstruit** à la volée. Du coup spaCy évalue toujours **l’ancien** `data/processed/spacy/ideo_job.spacy` (ici 1 937 docs), et tu ne vois aucun effet de `JOB_LIMIT`. Résultat : charge mémoire inchangée → RAM saturée → tu interromps (Error 130).

## Pourquoi

* `JOB_LIMIT` agit **uniquement** lors de la **construction** du `job.spacy` (dans `prepare_ideo` via `build_spacy_corpus.py --limit $(JOB_LIMIT)`).
* Lancer `make JOB_LIMIT=2000 eval_ideo` **n’oblige pas** Make à reconstruire `ideo_job.spacy`. Il réutilise le fichier existant.

## Deux solutions fiables (sans toucher aux scripts)

### Option A — Forcer la reconstruction du JOB avant l’éval

```bash
# 1) Supprimer l'ancien job.spacy (pour que Make le rebâtisse)
rm -f data/processed/spacy/ideo_job.spacy

# 2) Reconstruire le JOB avec un plafond stratifié (ex. 500 docs)
make WORKERS=4 BALANCE=none JOB_LIMIT=500 prepare_ideo

# 3) Évaluer en mode RAM light (threads BLAS=1)
make JOB_LIMIT=500 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 eval_ideo
```

Si OK, augmente progressivement `JOB_LIMIT` (1000 → 1500 → 2000).

### Option B — Ajoute une petite cible “rebuild” pratique (Makefile)

Tu restes “tout bash” et tu ne touches pas à Python :

```makefile
rebuild_ideo_job:
	$(PY) scripts/build_spacy_corpus.py \
	  --tsv $(INTERIM)/ideo/job.tsv \
	  --out $(SPACY_DATA)/ideo_job.spacy \
	  --labels-out $(SPACY_DATA)/ideo_labels.json \
	  --lang $(LANG) --workers $(WORKERS) --limit $(JOB_LIMIT)
```

Puis :

```bash
make JOB_LIMIT=500 rebuild_ideo_job
make JOB_LIMIT=500 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 eval_ideo
```

> Bonus “force rebuild” sans nouvelle cible :
> `make -B JOB_LIMIT=500 prepare_ideo`  (le `-B` dit à Make de **reconstruire** même si les timestamps n’ont pas changé).

---

## Séquence prudente (copie/colle)

```bash
# Reset visuel & infos
make sysinfo

# (A) Rebuild JOB en petit échantillon stratifié
rm -f data/processed/spacy/ideo_job.spacy
make WORKERS=4 BALANCE=none JOB_LIMIT=500 prepare_ideo

# (B) Évaluation limitée, threads BLAS à 1
make JOB_LIMIT=500 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 eval_ideo
jq . reports/ideo_metrics.json | head -40

# (C) Si OK, augmenter par paliers
rm -f data/processed/spacy/ideo_job.spacy
make JOB_LIMIT=1000 prepare_ideo
make JOB_LIMIT=1000 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 eval_ideo
```

---

## Autres leviers sans compromettre la fiabilité

* **Réduire la taille par doc** le temps des tests :
  `make QUICK_MAX_TOKENS=400 prepare_ideo`
  (appliqué au **TSV** → `job.spacy` plus léger, métriques proches si l’info est dans le début du texte).
* **Baisser temporairement l’archi** pour l’idéologie (2 classes) :
  `make ARCH=bow train_ideo`
  (n’influe pas beaucoup sur la RAM d’éval, mais allège un peu le modèle).
* **Garder JOB réaliste pour la “vraie” éval** : une fois le plafond mémoire maîtrisé, remets `JOB_LIMIT=0` et **fais l’éval finale** de nuit si nécessaire.

---

### TL;DR

Le souci n’est pas spaCy en soi mais le fait que `JOB_LIMIT` n’a pas reconstruit le `job.spacy`. **Rebuild d’abord** (`prepare_ideo` avec `JOB_LIMIT` ou `rebuild_ideo_job`), **puis** évalue. Ça fera chuter la RAM immédiatement sans dégrader la rigueur (échantillon stratifié), et tu pourras remonter jusqu’à la taille complète quand tu voudras l’éval “officielle”.

eval_ideo_stream:
	@MODEL=$$( [ -d $(MODELS_DIR)/spacy_ideo/model-best ] && echo $(MODELS_DIR)/spacy_ideo/model-best || echo $(MODELS_DIR)/spacy_ideo/model-last ); \
	echo "Evaluating (stream) $$MODEL (limit=$(JOB_LIMIT))"; \
	OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
	$(PY) scripts/eval_textcat_stream.py \
	  --model $$MODEL \
	  --tsv $(INTERIM)/ideo/job.tsv \
	  --labels $(SPACY_DATA)/ideo_labels.json \
	  --out $(REPORTS_DIR)/ideo_metrics.json \
	  --limit $(JOB_LIMIT) --batch-size 32


Bonne question 🙂
En bref, tes trois “familles” servent à **deux tâches différentes** et à **deux tailles** de jeu :

| Famille   | But / type de labels                                                                                     | Taille & vitesse                                                                             | Où c’est défini                                        | Artefacts écrits                                                                             |
| --------- | -------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | ------------------------------------------------------ | -------------------------------------------------------------------------------------------- |
| **ideo**  | **Exogène binaire** : `gauche` vs `droite` via `--label-field ideology` + `--ideology-map`               | Taille moyenne (tes réglages actuels), pensée pour l’analyse idéologique                     | Cibles `prepare_ideo / train_ideo / eval_ideo`         | `data/processed/spacy/ideo_*.spacy`, `models/spacy_ideo/*`, `reports/ideo_metrics*.json`     |
| **quick** | **Endogène multiclasse** : un label **par source/crawl** (`--label-field crawl`) → ex: partis / journaux | **Petit / rapide** (limité par `QUICK_LIMIT` et `QUICK_MAX_TOKENS`) pour prototypage         | Cibles `prepare_quick / train_quick / eval_parties`    | `data/processed/spacy/quick_*.spacy`, `models/spacy_quick/*`, `reports/parties_metrics.json` |
| **full**  | **Endogène multiclasse** (comme quick) mais **corpus complet**                                           | **Gros / lent** (pas de `QUICK_LIMIT`, `FULL_MAX_TOKENS` plus grand) pour les runs “finales” | Cibles `prepare_full / train_full` (+ `pipeline_full`) | `data/processed/spacy/full_*.spacy`, `models/spacy_full/*`                                   |

### Détails qui comptent

* **ideo** utilise ton `ideology.yml` pour mapper chaque source vers `gauche`/`droite`.
  ⚠️ Si le YAML **n’a pas** une entrée pour une source, le label **retombe** sur le nom du crawl (ex. `crawl-ps-full…`). Tu te retrouves alors avec un mélange `gauche/droite` **+** `crawl-*`. Pour rester en **binaire**, complète le YAML ou filtre les TSV pour ne garder que `gauche`/`droite`.

* **quick** et **full** : labels = **noms de crawl** (partis / sites), donc **multiclasse** (ex. ~20 classes).
  La différence est surtout **la taille** : *quick* limite au moment DocBin (`QUICK_LIMIT`, `QUICK_MAX_TOKENS`) pour aller vite ; *full* prend **tout** (plus coûteux, pour l’éval finale).

* **Équilibrage** : dans tes règles `prepare_*`, le paramètre `BALANCE` (cap_docs / cap_tokens / alpha_total) s’applique au **TRAIN uniquement** (jamais au JOB). Tu l’as câblé pour ideo, quick, full.

* **Modèles & rapports** :

  * ideo → `models/spacy_ideo/…` + `reports/ideo_metrics*.json`
  * quick → `models/spacy_quick/…` + `reports/parties_metrics.json`
  * full → `models/spacy_full/…` (souvent évalué à part si besoin)

### Quand utiliser quoi ?

* **Démarrer / valider le câblage** : `ideo` (binaire) + `quick` (multi) → rapides, RAM maîtrisée.
* **Itérer sur les hyperparams / équilibrage** : rester sur `quick` (et `ideo`) avec `JOB_LIMIT` / `QUICK_LIMIT`.
* **Mesure finale “réaliste”** : `full` (multiclasse complet) et/ou `ideo` avec `JOB_LIMIT=0` (éval complète).

Si tu veux, je peux te donner un mini check-list YAML pour t’assurer que **toutes** les sources sont mappées en gauche/droite (pour éviter les `crawl-*` dans ideo).
