# PEPM — Pipeline d’entraînement texte

**Chaîne : web → TEI → TSV → DocBin → modèles (spaCy / Sklearn / HF)**
**Projet PEPM — Yi Fan & Adrien**

> Classifieur FR (et multilingue via `xx`) conçu pour tourner **entièrement sur CPU** avec une **hygiène de données** et une **hygiène de structure** strictes, une **reproductibilité** forte, et une **scalabilité** raisonnable. Le pipeline est **web-ready** et **extensible** vers **ASR/GOLD** (et d’autres variantes type web2, web3…).

---

## Table des matières

1. [Objectifs & périmètre](#objectifs--périmètre)
2. [Anatomie du dépôt](#anatomie-du-dépôt)
3. [Installation & prérequis](#installation--prérequis)
4. [Données TEI, modalités & sanitation](#données-tei-modalités--sanitation)
5. [Paramétrage global (Makefile)](#paramétrage-global-makefile)
6. [Recettes de commandes **classiques**](#recettes-de-commandes-classiques)
7. [Scripts & CLI (référence rapide)](#scripts--cli-référence-rapide)
8. [Pipeline (schéma Mermaid)](#pipeline-schéma-mermaid)
9. [🚦 Smoke test **copier-coller**](#-smoke-test-copier-coller)
10. [Métriques, rapports & agrégation](#métriques-rapports--agrégation)
11. [Reproductibilité & journaux](#reproductibilité--journaux)
12. [Performance & volumétrie](#performance--volumétrie)
13. [Dépannage (FAQ)](#dépannage-faq)
14. [Extensibilité ASR/GOLD](#extensibilité-asrgold)
15. [Conventions & style](#conventions--style)
16. [Annexes](#annexes)

---

## 1) Objectifs & périmètre

* **Données** : TEI consolidé → split **TRAIN/JOB** → TSV canonique → **DocBin (.spacy)** shardé.
* **Modèles** : spaCy (**BOW** ou **CNN**), baselines CPU (TF-IDF + **SVM/LR/RF/ET**), Transformers **HF** (CamemBERT, Flaubert, mBERT… **CPU par défaut**).
* **Équilibrage TRAIN** : `none`, `cap_docs`, `cap_tokens`, `alpha_total` (+ `--oversample`).
* **Orchestration Makefile** : change **profil** (quick/full), **label_field** (ideology/crawl), **modality** (web/asr/gold/any), **suite** (spacy/sklearn/hf/all), **config** (debug/small_cpu/large_cpu).
* **Repro** : seeds figées, **sysinfo**, plafonds BLAS, **run_meta** (hashs + git SHA), agrégation **summary.csv**.

---

## 2) Anatomie du dépôt

```
data/
  raw/corpus/corpus.xml           # TEI consolidé (toutes sources)
  raw/corpus/corpus.modality.xml  # TEI après marquage <term type="modality">web</term> (option)
  interim/                        # TSV + dérivés intermédiaires
  processed/spacy/                # DocBin .spacy + labels.json
logs/                             # journaux d’entraînement
models/                           # model-best / model-last
reports/                          # métriques JSON/CSV, récapitulatif
scripts/                          # outils TEI/TSV/DocBin/train/éval
Makefile                          # orchestration configurable
requirements.txt
```

---

## 3) Installation & prérequis

* Linux (Kubuntu OK). **Python ≥ 3.10** (3.12 recommandé).
* CPU suffit ; spaCy & HF configurés CPU par défaut.

```bash
# 1) Créer/activer l’environnement
python3 -m venv .venv
source .venv/bin/activate

# 2) Installer dépendances et modèles
make setup

# (optionnel) Infos système (CPU/RAM/threads BLAS)
make sysinfo
```

> Pour quitter : `deactivate`

---

## 4) Données TEI, modalités & sanitation

### 4.1 TEI minimal

* Chaque document est encapsulé en TEI (`<TEI><teiHeader>…<text><body><p>…`).
* **Labels** :

  * `crawl` (multiclasse) pour les données “endo”.
  * `ideology` (typiquement binaire) via un mapping YAML `data/configs/ideology.yml`.

### 4.2 Marquage de **modalité** (V3)

**Source unique** :
`<teiHeader>/<profileDesc>/<textClass>/<keywords><term type="modality">web|asr|gold|…</term></keywords>`

> ⚠️ **Plus de `@ana`** : retiré pour éviter les doubles chemins. Toute lecture/écriture de modalité passe par ce `<term>`.

Commande utilitaire (web) :

```bash
make add_modality_web RAW_CORPUS=data/raw/corpus/corpus.xml MODALITY=web
```

### 4.3 Segments (pré-ASR, optionnel)

Possible d’encoder des segments : `<div type="segments"><p n="000-030">…</p></div>` — **non requis** par la chaîne actuelle.

### 4.4 Sanitation (extraction → TSV)

Trim, espaces multiples/insécables, entités HTML usuelles, contrôle de longueur min/max, dé-duplication simple (MD5 optionnelle en amont).

---

## 5) Paramétrage global (Makefile)

### 5.1 Variables principales

| Variable      | Sens                 | Valeurs                                            | Défaut           |
| ------------- | -------------------- | -------------------------------------------------- | ---------------- |
| `PROFILE`     | volumétrie           | `quick` / `full`                                   | `quick`          |
| `LABEL_FIELD` | champ de label       | `ideology` / `crawl`                               | `ideology`       |
| `MODALITY`    | vue source           | `web` / `asr` / `gold` / `any`                     | `web`            |
| `CONFIG`      | preset ressources    | `default` / `debug` / `small_cpu` / `large_cpu`    | `default`        |
| `SUITE`       | familles modèles     | `all` / `spacy` / `sklearn` / `hf`                 | `all`            |
| `ARCH`        | arch spaCy           | `bow` / `cnn`                                      | `bow`            |
| `HF_MODELS`   | modèles HF           | CSV (`camembert-base,flaubert/...`)                | `camembert-base` |
| `BALANCE`     | équilibrage TRAIN    | `none` / `cap_docs` / `cap_tokens` / `alpha_total` | `none`           |
| `TOTAL`       | taille cible (alpha) | `>0` si `alpha_total`                              | `0`              |
| `DEV_PROP`    | split interne DEV    | `0–1`                                              | `0.15`           |
| `JOB_LIMIT`   | plafond éval         | int                                                | `5000`           |

> **Garde-fou** Makefile : si `BALANCE=alpha_total` **et** `TOTAL<=0` → erreur claire.
> **Quotas** (option) : `CEILING=1` active `systemd-run --user` + `taskset` via `CEIL_CPU`, `CEIL_MEM`, `CEIL_CORES`.

---

## 6) Recettes de commandes **classiques**

### 6.1 Activation venv & vérifs

```bash
source .venv/bin/activate
make setup
make check MODALITY=web
make sysinfo
```

### 6.2 **Idéologie – quick (BOW par défaut)**

```bash
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web
make train   PROFILE=quick LABEL_FIELD=ideology ARCH=bow
make eval    PROFILE=quick LABEL_FIELD=ideology
```

### 6.3 **Idéologie – full**

```bash
make prepare PROFILE=full LABEL_FIELD=ideology MODALITY=web
make train   PROFILE=full  LABEL_FIELD=ideology ARCH=bow
make eval    PROFILE=full  LABEL_FIELD=ideology
```

### 6.4 **Partis (crawl) – quick**

```bash
make prepare PROFILE=quick LABEL_FIELD=crawl MODALITY=web
make train   PROFILE=quick LABEL_FIELD=crawl ARCH=cnn
make eval    PROFILE=quick LABEL_FIELD=crawl
```

### 6.5 **Pipeline tout-en-un (quick)**

```bash
# spaCy + sklearn + HF
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web SUITE=all

# matrices spaCy seulement (bow+cnn)
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=spacy
```

### 6.6 **Baselines sklearn / HF (quick)**

```bash
# sklearn seul
make pipeline PROFILE=quick LABEL_FIELD=crawl SUITE=sklearn

# HF seul (CamemBERT), CPU
make pipeline PROFILE=quick LABEL_FIELD=ideology SUITE=hf HF_MODELS=camembert-base USE_GPU=0 HF_EPOCHS=1
```

---

## 7) Scripts & CLI (référence rapide)

> **Note V3** : tous les scripts lisent/écrivent la modalité via `<keywords><term type="modality">…</term>` ; plus d’usage de `@ana`.

### Ingest

* `scripts/ingest/ingest_web.py` — ajoute/normalise **modality=web** dans un TEI existant.
  **Args** : `--in`, `--out`, `--value web`
* `scripts/ingest/ingest_asr.py` — génère des TEI depuis audio.
  **Args** : `--in-dir`, `--out-tei`, `--engine whisper|none`, `--model base|small|…`, `--lang fr`

  > **Stub policy** : `--engine none` permet de tester la chaîne **sans** dépendances ASR (paragraphe vide).
* `scripts/ingest/tei_merge.py` — fusionne plusieurs TEI/teiCorpus **sans toucher** à la modalité.
  **Args** : `--inputs <files…>`, `--out`
* `scripts/ingest/make_ideology_skeleton.py` — produit un YAML squelette `ideology.yml` + comptages acteurs.
  **Args** : `--corpus`, `--out-yaml`, `--out-report`, `--min-chars`, `--top-variants`

### Prepare

* `scripts/prepare/tei_to_train_job.py` — TEI → TSV : `train.tsv` + `job.tsv` (header **`id	label	text`**), filtrage modalité & label.
  **Args** : `--corpus`, `--outdir`, `--train-prop`, `--label-field ideology|crawl`, `--ideology-map`, `--min-chars`, `--max-tokens`, `--procs`, `--seed`, `--balance-train`, `--limit`, `--modality`
* `scripts/prepare/split_train_dev.py` — split interne DEV à partir de `train.tsv`, **conserve** le header.
  **Args** : `--train-tsv`, `--dev-ratio`, `--seed`, `--out-train`, `--out-dev`
* `scripts/prepare/build_spacy_corpus.py` — TSV → DocBin shardé (`part%04d.spacy`) + `labels.json`.
  **Args** : `--tsv`, `--out`, `--labels-out`, `--lang`, `--workers`, `--shard-size`, `--batch-size`, `--limit`

### Train

* `scripts/train/train_core.py` — spaCy TextCat (archi `bow` ou `cnn`), lit DocBin (train/dev) & `labels.json`, écrit `model-best`/`model-last`.
  **Args** : `--train`, `--dev`, `--out`, `--lang`, `--arch`, `--epochs`, `--dropout`, `--batch-start`, `--batch-stop`, `--eval-freq`, `--seed`, `--labels`
* `scripts/train/sklearn_baselines.py` — TF-IDF + {LinearSVM, LogReg, SGD, SVM-RBF, RF, ExtraTrees} (+ unsup si demandé).
  **Args** : `--train`, `--dev`, `--job`, `--models`, `--unsup`, `--outdir`, `--reports`
* `scripts/train/hf_baselines.py` — Transformers (CamemBERT, Flaubert, mBERT…) **CPU par défaut**.
  **Args** : `--train`, `--dev`, `--job`, `--models`, `--epochs`, `--batch-size`, `--grad-accum`, `--max-len`, `--lr`, `--use-gpu`, `--reports`, `--outdir`

  > Si la stack HF est absente → message clair puis **arrêt** (pas de fallback silencieux).

### Evaluate / Analysis / Check

* `scripts/evaluate/eval_textcat_stream.py` — évaluation spaCy sur DocBin (streaming), JSON de métriques.
* `scripts/evaluate/metrics_aggregate.py` — agrège toutes les métriques en `reports/summary.csv`.
* `scripts/evaluate/run_meta.py` — empreinte expérimentale (hash TSV, git SHA, timestamp).
* `scripts/evaluate/train_diagnostics.py` — diagnostics d’apprentissage (sous/sur-apprentissage, dérive).
* `scripts/analysis/input_stats.py` — stats d’entrée (TEI) : longueurs, tokens, distributions.
* `scripts/analysis/emotion_check.py` — score d’émotions (annexe) sur TEI.
* `scripts/check/preflight.py` — **pipeline check** : scan TEI (modalités, labels, stats), JSON de synthèse.
  **Args** : `--corpus`, `--label-field`, `--ideology-map (si nécessaire)`, `--limit`, `--modality`, `--auto-offset-scan`
* `scripts/check/sanity_labels.py` — garde-fou “≥ 2 labels” (exige **au moins** `--min-labels`), route Make d’**auto-patch** si mono-classe.
  **Args** : `--tsv`, `--min-labels`
* `scripts/check/corpus_stats.py` — stats TSV (distributions, tailles, doublons) ; lecture **par header**.
* `scripts/check/tsv_schema.py` — **valide le schéma TSV** (présence `id,label,text` + lignes min).

---

## 8) Pipeline (schéma Mermaid)

```mermaid
flowchart TD
  %% ===================== SOURCES =====================
  subgraph Sources
    W[Web HTML]
    A[Transcriptions ASR]
    G[Reference gold]
    X[Autres (web2, web3…)]
  end

  W --> T1[Unifier TEI]
  A --> T1
  G --> T1
  X --> T1

  T1 --> T2[Ajouter / normaliser <term type="modality">…</term>]
  T2 --> T3[Nettoyer le texte]
  T3 --> T4[Deduplication MD5]
  T4 --> L{Choisir le champ de label}

  L -- crawl --> L1[Crawl multiclasse]
  L -- ideology --> L2[Ideologie binaire depuis YAML]

  L1 --> S1[Split TRAIN et JOB]
  L2 --> S1

  S1 --> S2[Split DEV depuis TRAIN]
  S1 --> O1[Ecrire TSV TRAIN et JOB (id|label|text)]

  S2 --> B{Equilibrer TRAIN}
  B -- none --> B0[TRAIN inchange]
  B -- cap_docs --> B1[Cap par label]
  B -- cap_tokens --> B2[Cap tokens par label]
  B -- alpha_total --> B3[Alpha avec total cible]

  B0 --> C1[Construire DocBin TRAIN + labels.json]
  B1 --> C1
  B2 --> C1
  B3 --> C1
  O1 --> C2[Construire DocBin JOB]

  %% ===================== MODELES =====================
  subgraph Modeles
    S[spaCy textcat BOW ou CNN]
    K[Sklearn TF-IDF SVM LR SGD RF ExtraTrees]
    H[Transformers HF Camembert Flaubert mBERT]
  end

  C1 --> S
  C1 --> K
  C1 --> H

  %% ===================== SANITY ET PREPARATION =====================
  subgraph Sanity et Preparation
    Q1[Sysinfo]
    Q2[Preflight (pipeline check)]
    Q3[Sanity labels (>=2 classes)]
  end

  Q1 --> S
  Q2 --> S
  Q2 --> K
  Q2 --> H
  Q3 --> S
  Q3 --> K
  Q3 --> H

  %% ===================== EVALUATION ET RAPPORTS =====================
  subgraph Evaluation et Rapports
    E1[spacy evaluate vers JSON]
    E2[Metriques et confusion pour sklearn et HF]
    A1[Aggregation summary.csv]
    M1[Run meta et empreintes donnees]
  end

  S --> E1
  K --> E2
  H --> E2
  E1 --> A1
  E2 --> A1
  O1 --> M1
  C1 --> M1
  C2 --> M1

  %% ===================== ORCHESTRATION MAKEFILE =====================
  subgraph Orchestration Makefile
    P1[Profil quick|full]
    P2[Label ideology|crawl]
    P3[Modalite web|asr|gold|any]
    P4[Suite all|spacy|sklearn|hf]
    P5[Config default|debug|small_cpu|large_cpu]
    P6[Arch bow|cnn]
    P7[Balance none|cap_docs|cap_tokens|alpha_total]
    P8[Ceiling quotas et taskset optionnels]
  end

  P1 --> S1
  P2 --> L
  P3 --> T2
  P4 --> S
  P4 --> K
  P4 --> H
  P5 --> S
  P5 --> K
  P5 --> H
  P6 --> S
  P7 --> B
  P8 --> S
  P8 --> K
  P8 --> H
```

---

## 9) 🚦 Smoke test **copier-coller**

Objectif : valider la chaîne **E2E** rapidement en CPU, avec garde-fous mono-classe.

```bash
# (0) Environnement
python3 -m venv .venv && source .venv/bin/activate
make setup

# (1) Vérif d’entrée + échantillon rapide
make check MODALITY=web TSV_LIMIT_QUICK=2000

# (2) Garde-fou labels (routeur LABEL_FIELD actif)
make sanity_labels_active MODALITY=web PROFILE=quick LABEL_FIELD=ideology

# (3) Pipeline minimal spaCy (CPU, époques courtes)
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web CONFIG=debug SUITE=spacy

# (4) Rapports & empreintes (option)
make aggregate_reports && make run_meta
```

**Variantes utiles**

* Forcer l’acceptation **mono-classe** (diagnostic) :

```bash
make sanity_labels_active REQUIRE_MULTICLASS=0
```

* Cible **crawl** (multiclasse) :

```bash
make sanity_labels_active LABEL_FIELD=crawl
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web CONFIG=debug SUITE=spacy
```

---

## 10) Métriques, rapports & agrégation

* **spaCy** : `spacy evaluate` → JSON (TEXTCAT macro-F1, accuracy, etc.).
* **Sklearn/HF** : F1 macro/weighted, Accuracy, AUC (binaire), confusion (CSV/PNG).
* **Agrégation** : `reports/summary.csv` centralise les résultats (`family, arch, balance, seed, train_docs, job_docs, macro_f1, acc, auc, time, ...`).

---

## 11) Reproductibilité & journaux

* Threads plafonnés (env : `OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `MKL_NUM_THREADS`, `NUMEXPR_NUM_THREADS`).
* **Sysinfo** par run : `make sysinfo`.
* **Run meta** : `scripts/evaluate/run_meta.py` (hash TSV, git SHA, timestamp).
* Dossiers modèles standards : `model-best/` & `model-last/`.

---

## 12) Performance & volumétrie

* **Caps TRAIN** : `cap_docs` (avec `--oversample`) ou `cap_tokens`.
* **DocBin sharding** : `--shard-size` (10–25k conseillé en “full”).
* **Batch spaCy** : `--batch-start/--batch-stop` (compounding) + `--eval-freq`.
* **JOB_LIMIT** : limiter l’éval si le JOB est volumineux.
* **HF CPU** : réduire `HF_EPOCHS`, limiter `HF_MODELS`, `HF_MAXLEN`.

---

## 13) Dépannage (FAQ)

* **“Need ≥ 2 distinct labels”** : TRAIN mono-classe (vérifier `train.tsv`, mapping YAML, filtre modalité).
  → `make sanity_labels_active` tente **auto-patch** (fenêtre élargie via `PATCH_*`) jusqu’à `PATCH_TRIES`.
* **Sklearn `n_splits>members`** : augmenter `cap_docs`/`oversample` ou réduire la CV interne.
* **spaCy modèle introuvable à l’éval** : inspecter `logs/run-*.log` et `model-best/`.
* **OOM / lenteur** : baisser `--max-tokens`, réduire `--workers`, augmenter sharding, `CONFIG=debug`.
* **HF trop lent sur CPU** : `HF_EPOCHS=1`, un seul modèle (`HF_MODELS=camembert-base`).

---

## 14) Extensibilité ASR/GOLD

* **Modalité** : `MODALITY=asr|gold|web2|web3…` (scripts prêts côté parsing).
* **ASR** : `ingest_asr.py --engine whisper` (prod) ou `--engine none` (stub rapide).
* **Comparaisons** : text-only vs audio-only vs multimodal (mêmes métriques, même agrégateur).
* **TEI merge** : `tei_merge.py` unifie plusieurs sources **sans** écraser les modalités.

---

## 15) Conventions & style

* **Scripts** : un fichier = une responsabilité, **imports directs** (`from scripts.common...`) sans gros blocs conditionnels.
* **Données** : invariant **TSV = `id	label	text`** (ordre strict + header), modalité **uniquement** via `<term type="modality">`.
* **Makefile** : lieu unique de la complexité (matrices de modèles, variantes, quotas).

---

## 16) Annexes

### A — Variables Make (table complète)

| Catégorie   | Variable           | Description       | Valeurs                      | Défaut           |
| ----------- | ------------------ | ----------------- | ---------------------------- | ---------------- |
| Profil      | `PROFILE`          | volumétrie        | `quick`/`full`               | `quick`          |
| Labels      | `LABEL_FIELD`      | cible labels      | `ideology`/`crawl`           | `ideology`       |
| Modalité    | `MODALITY`         | vue source        | `web`/`asr`/`gold`/`any`     | `web`            |
| Suite       | `SUITE`            | familles à lancer | `all`/`spacy`/`sklearn`/`hf` | `all`            |
| HF          | `HF_MODELS`        | liste modèles     | CSV                          | `camembert-base` |
| HF          | `HF_EPOCHS`        | époques           | int                          | `2`              |
| HF          | `HF_BS`            | batch size        | int                          | `8`              |
| HF          | `HF_ACCUM`         | grad accumulation | int                          | `2`              |
| HF          | `HF_MAXLEN`        | longueur max      | int                          | `256`            |
| HF          | `HF_LR`            | learning rate     | float                        | `2e-5`           |
| HF          | `USE_GPU`          | device            | `0`/`auto`                   | `0`              |
| spaCy       | `ARCH`             | arch              | `bow`/`cnn`                  | `bow`            |
| spaCy       | `SPACY_ARCHS`      | matrice           | liste                        | `bow cnn`        |
| spaCy       | `EPOCHS_QUICK`     | époques quick     | int                          | `40`             |
| spaCy       | `EPOCHS_FULL`      | époques full      | int                          | `6`              |
| Split       | `TRAIN_PROP`       | part TRAIN        | float                        | `0.8`            |
| Split       | `DEV_PROP`         | part DEV          | float                        | `0.15`           |
| Tokens      | `MIN_CHARS`        | filtre            | int                          | `200`            |
| Tokens      | `QUICK_MAX_TOKENS` | quick             | int                          | `600`            |
| Tokens      | `FULL_MAX_TOKENS`  | full              | int                          | `1500`           |
| Limites     | `TSV_LIMIT_QUICK`  | TSV quick         | int                          | `100000`         |
| Limites     | `TSV_LIMIT_FULL`   | TSV full          | int                          | `0`              |
| Équilibrage | `BALANCE`          | stratégie         | voir §5.1                    | `none`           |
| Équilibrage | `CAP_PER_LABEL`    | cap docs          | int                          | `0`              |
| Équilibrage | `CAP_TOKENS`       | cap tokens        | int                          | `0`              |
| Équilibrage | `OVERSAMPLE`       | rééchantillonnage | flag                         | vide             |
| Alpha       | `ALPHA`            | expo              | float                        | `0.5`            |
| Alpha       | `TOTAL`            | taille cible      | int                          | `0`              |
| CPU         | `WORKERS`          | processus         | int                          | `14`             |
| CPU         | `BATCH_START`      | compounding       | int                          | `16`             |
| CPU         | `BATCH_STOP`       | compounding       | int                          | `64`             |
| CPU         | `EVAL_FREQ`        | fréquence éval    | iters                        | `50`             |
| Éval        | `JOB_LIMIT`        | plafond job       | int                          | `5000`           |
| Système     | `CEILING`          | quotas systemd    | 0/1                          | `0`              |
| Système     | `CEIL_CPU`         | quota CPU         | %                            | `85%`            |
| Système     | `CEIL_MEM`         | quota RAM         | e.g. `35G`                   | `35G`            |
| Système     | `CEIL_CORES`       | CPU set           | int                          | `14`             |

### B — Jeu de commandes étendu (prêt à copier)

```bash
# Modalité alternative
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=asr
make prepare PROFILE=quick LABEL_FIELD=crawl    MODALITY=gold

# Matrices spaCy (BOW+CNN) d’un coup
make train_spacy_matrix PROFILE=quick LABEL_FIELD=crawl MODALITY=web

# Baselines sklearn (sup. + non-sup.)
make baselines_sklearn_matrix PROFILE=quick LABEL_FIELD=crawl

# Transformers (CPU)
make hf_quick PROFILE=quick LABEL_FIELD=ideology HF_MODELS=camembert-base USE_GPU=0 HF_EPOCHS=1

# Évaluations
make eval PROFILE=quick LABEL_FIELD=crawl
make eval PROFILE=full  LABEL_FIELD=ideology

# Rapports
make aggregate_reports && make run_meta
```

---

**© Yi Fan & Adrien — 2025.**
