# Démarrage & contrôles (Linux)

```bash
# Installer les deps et modèles
make setup

# Injecter la modalité "web" dans le TEI (si besoin)
make add_modality_web RAW_CORPUS=data/raw/corpus/corpus.xml MODALITY=web

# Vérifications pipeline + échantillonnage rapide (lecture TEI → TSV)
make check MODALITY=web TSV_LIMIT_QUICK=5000
```

---

# 🚦 Smoke test (safe & rapide)

```bash
# 1) Environnement
python3 -m venv .venv && source .venv/bin/activate
make setup

# 2) Garde‑fou labels (routeur actif ideology/crawl)
make sanity_labels_active MODALITY=web PROFILE=quick LABEL_FIELD=ideology

# 3) Pipeline minimal spaCy (époques réduites)
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web CONFIG=debug SUITE=spacy

# 4) Rapports (optionnel)
make aggregate_reports && make run_meta
```

**Cas mono‑classe (diagnostic)**  
Accepter temporairement une seule classe :
```bash
make sanity_labels_active REQUIRE_MULTICLASS=0
```

**Variante crawl**  
```bash
make sanity_labels_active LABEL_FIELD=crawl
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web CONFIG=debug SUITE=spacy
```

---

# Pipelines génériques (routing par profil/label)

> Forme canonique – **utilise le routeur** du Makefile  
> `make pipeline PROFILE=<quick|full> LABEL_FIELD=<ideology|crawl> MODALITY=<any|web|asr|gold> SUITE=<all|spacy|sklearn|hf> [overrides…]`

### Exemples usuels

```bash
# Quick + ideology, tout (spaCy + sklearn + HF) en CPU
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web SUITE=all USE_GPU=0

# Quick + crawl, uniquement spaCy (bow+cnn)
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=spacy SPACY_ARCHS="bow cnn"

# Quick + crawl, uniquement sklearn (dépend de split_active_dev)
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=sklearn   SKLEARN_MODELS="linear_svm,logreg,sgd" UNSUP_MODELS="kmeans,agglo"

# Quick + crawl, uniquement HF (Transformers) en GPU auto
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web SUITE=hf   HF_MODELS="camembert-base,flaubert/flaubert_base_cased" HF_EPOCHS=2 HF_BS=8 USE_GPU=auto

# Full + crawl, spaCy uniquement
make pipeline PROFILE=full LABEL_FIELD=crawl MODALITY=web SUITE=spacy ARCH=bow

# Full + ideology, spaCy uniquement (jeu complet)
make pipeline PROFILE=full LABEL_FIELD=ideology MODALITY=web SUITE=spacy ARCH=cnn
```

---

# Étapes unitaires (préparer/entraîner/évaluer)

```bash
# Aliases génériques (routés par PROFILE & LABEL_FIELD)
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web
make train   PROFILE=quick LABEL_FIELD=ideology MODALITY=web ARCH=bow
make eval    PROFILE=quick LABEL_FIELD=ideology MODALITY=web

# Meta run (git + fichiers) pour le couple actif
make run_meta PROFILE=quick LABEL_FIELD=crawl MODALITY=web
```

---

# spaCy – entraînements

```bash
# Matrice bow+cnn sur quick/crawl
make train_spacy_matrix MODALITY=web PROFILE=quick LABEL_FIELD=crawl SPACY_ARCHS="bow cnn"

# Bow uniquement (raccourcis historiques)
make train_spacy_bow  MODALITY=web
make train_spacy_cnn  MODALITY=web
```

---

# sklearn – baselines (sup/unsup)

```bash
# Matrice par défaut (pense à split_active_dev via les cibles de pipeline/prepare)
make baselines_sklearn_matrix MODALITY=web   SKLEARN_MODELS="linear_svm,logreg,sgd,svm_rbf,random_forest,extra_trees"   UNSUP_MODELS="kmeans,agglo"   # Overrides utiles :
  C_GRID="0.25,0.5,1,2" MAX_FEATURES=200000
```

---

# Hugging Face – baselines

```bash
# CPU (recommandé si pas de GPU)
make hf_quick MODALITY=web USE_GPU=0   HF_MODELS="camembert-base,bert-base-multilingual-cased" HF_EPOCHS=2 HF_BS=8 HF_ACCUM=2 HF_MAXLEN=256 HF_LR=2e-5

# GPU auto (CUDA/ROCm si dispo)
make hf_quick MODALITY=web USE_GPU=auto HF_MODELS="camembert-base" HF_EPOCHS=3 HF_BS=16 HF_ACCUM=2

# Nouvelle cible synchronisée au routeur « actif » (split_active_dev)
make hf_active USE_GPU=0 HF_MODELS="camembert-base"
```

---

# Profils de config (raccourcis)

```bash
# Débogage rapide (petits budgets/époques/limites)
make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web CONFIG=debug

# Petites machines CPU
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web CONFIG=small_cpu SUITE=all

# Grosse machine CPU
make pipeline PROFILE=full LABEL_FIELD=crawl MODALITY=web CONFIG=large_cpu SUITE=spacy
```

---

# Modalités & langues

```bash
# Basculer la modalité (filtre TEI)
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=asr
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=gold
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=any   # pas de filtre

# Langue spaCy (tokenizer/sentencizer multi-langue, si dispo)
make train PROFILE=quick LABEL_FIELD=ideology MODALITY=web LANG=xx ARCH=bow
```

---

# Équilibrage / sampling (BALANCE)

```bash
# Sans équilibrage (défaut)
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web BALANCE=none

# Cap documents par label (avec sur-échantillonnage)
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web   BALANCE=cap_docs CAP_PER_LABEL=3000 OVERSAMPLE=--oversample

# Cap tokens par label
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web   BALANCE=cap_tokens CAP_TOKENS=500000

# Alpha / Total (mix global contrôlé) – nécessite TOTAL>0
make prepare PROFILE=quick LABEL_FIELD=ideology MODALITY=web   BALANCE=alpha_total ALPHA=0.5 TOTAL=20000
```

---

# Limites & split DEV

```bash
# Limiter le TSV (ingestion) en quick
make prepare PROFILE=quick LABEL_FIELD=crawl MODALITY=web TSV_LIMIT_QUICK=20000

# Limiter la taille job (éval)
make eval PROFILE=quick LABEL_FIELD=ideology MODALITY=web JOB_LIMIT=1500

# Split train/dev (répéter si tu régénères train.tsv)
make split_active_dev DEV_PROP=0.2 SEED=123
```

---

# Ressources CPU/RAM (cgroup user)

```bash
# Activer le plafond (systemd-run) et pin CPU cores 0..13
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web CEILING=1 CEIL_CPU=85% CEIL_MEM=35G CEIL_CORES=14
```

---

# Données d’entrée alternatives

```bash
# Utiliser un autre corpus TEI déjà "modality-tagged"
make pipeline PROFILE=quick LABEL_FIELD=crawl MODALITY=web CORPUS=data/raw/corpus/mon_corpus_modality.xml

# (si besoin) injecter d’abord la modalité dans un autre XML brut
make add_modality_web RAW_CORPUS=data/raw/corpus/mon_corpus.xml CORPUS=data/raw/corpus/mon_corpus_modality.xml MODALITY=web
```

---

# Nettoyage

```bash
# Purge des artefacts (splits, .spacy, modèles)
make clean
```
