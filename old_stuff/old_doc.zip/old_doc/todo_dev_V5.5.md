# Backlog V5 – Multi-corpus & orchestrateur `superior`

## 0. Scope & hypothèse de départ

* Core V4.x + extensions V4.2 multi-corpus :

  * `resolve_profile_base` gère déjà `dataset_id`, `data.corpus_ids`, `merge_mode`, `source_field`, `analysis.compare_by`.
  * `core_prepare` lit plusieurs TEI quand `params["corpora"]` a >1 élément et écrit dans `data/interim/<dataset_id>/<view>/`.
  * `core_evaluate` sait produire `metrics_by_<field>.json` quand `analysis.compare_by` est défini.

* Orchestrateur V5 :

  * Spécifié comme `exp_orchestrator` dans `dev_V5.md` (scripts/experiments/…)
  * Implémenté sous le nom **`superior`** (`scripts/superior/superior_orchestrator.py`, `run_single.py`, `configs/superior/*.yml`, sorties dans `superior/<exp_id>/...`).

* README V5 :

  * Doc utilisateur générale OK (core, Makefile, orchestrateur basique), mais **multi-corpus** et **RAM policy** sont très peu explicites.

---

## 1. Multi-corpus : pipeline web1 / asr1 / web2, etc.

### 1.1. Profils multi-corpus de référence

**TODO-1.1.a – Créer au moins un profil multi-corpus “officiel”**

* Fichier à créer : `configs/profiles/ideo_quick_web1_asr1.yml`.
* Objectif : illustrer explicitement l’usage de `dataset_id`, `data.corpus_ids`, `merge_mode`, `source_field`, `analysis.compare_by`.
* Contenu minimal :

  ```yaml
  profile: ideo_quick_web1_asr1
  description: >
    Fusion web1+asr1, vue ideology_global, analyse juxtaposée.

  dataset_id: web1_asr1

  data:
    corpus_ids: [web1, asr1]
    merge_mode: juxtaposed          # single | merged | juxtaposed | separate
    source_field: corpus_id

  view: ideology_global

  analysis:
    compare_by:
      - corpus_id

  families: [check, spacy, sklearn]
  models_spacy: [spacy_cnn_quick]
  models_sklearn: [tfidf_svm_quick]
  hardware_preset: small
  train_prop: 0.8
  balance_strategy: oversample
  balance_preset: parity
  ```

**TODO-1.1.b – Ajouter un profil “merged” et/ou “separate”**

* But : couvrir **tous** les modes prévus par `merge_mode` :

  * `merged` : dataset fusionné + métriques globales,
  * `juxtaposed` : fusion + `metrics_by_<field>.json`,
  * `separate` : un dataset par corpus (piloté ensuite par l’orchestrateur).

* Proposer par ex. `ideo_quick_web1_asr1_merged.yml` et surtout documenter dans `dev_V5` comment `merge_mode=separate` doit être exploité par `superior`.

---

### 1.2. Tests fonctionnels multi-corpus

**TODO-1.2.a – Tests intégration `core_prepare` multi-TEI**

* Écrire un script/tests qui vérifie explicitement :

  1. `PROFILE=ideo_quick_web1_asr1` :

     * crée `data/interim/web1_asr1/ideology_global/train.tsv` / `job.tsv`,
     * ajoute bien la colonne `corpus_id` avec valeurs `web1` et `asr1`.
  2. `meta_view.json` contient :

     * `dataset_id = "web1_asr1"`,
     * `source_field = "corpus_id"`,
     * `source_corpora = ["web1", "asr1"]`.

**TODO-1.2.b – Tests intégration `core_evaluate` + `metrics_by_<field>.json`**

* Vérifier que pour un profil avec :

  ```yaml
  analysis:
    compare_by: [corpus_id]
  ```

  `core_evaluate` produit bien :

  * `reports/web1_asr1/ideology_global/<family>/<model_id>/metrics_by_corpus_id.json`
    avec une structure `{ "web1": {…}, "asr1": {…} }`.

**TODO-1.2.c – Tests multi-corpus + orchestrateur**

* Étendre `configs/superior/exp_ideo_balancing_sweep.yml` pour inclure un axe `dataset` complet (comme dans la spec) :

  ```yaml
  axes:
    - name: dataset
      type: choice
      values:
        - label: web1_only
          overrides:
            dataset_id: web1
            data.corpus_ids: [web1]
            data.merge_mode: single

        - label: web1_asr1_juxt
          overrides:
            dataset_id: web1_asr1
            data.corpus_ids: [web1, asr1]
            data.merge_mode: juxtaposed
            analysis.compare_by: [corpus_id]
  ```

* Vérifier que `superior` :

  * génère les bons `RunSpec` multi-corpus,
  * produit des `metrics_global.tsv` et les `metrics_by_corpus_id.json` attendus côté core.

---

## 2. Gestion RAM : limite non-kill par défaut

Actuellement, la spec V5 prévoit :

* `hardware.yml` : limite *interne* par famille (`max_train_docs_spacy`, `max_train_docs_sklearn`, `max_train_docs_hf`…).
* `scheduler.max_ram_gb` : budget “global” pour l’orchestrateur.
* `run_single --max-ram-mb` : hard-kill du process sur dépassement.

Tu veux que le **comportement par défaut** soit :

* **RAM-safe** par design (hard/soft caps sur les docs + scheduling),
* **sans** kill brutal en cas de dépassement “un peu au-dessus”.

### 2.1. Découpler `max_ram_gb` (scheduler) de `--max-ram-mb` (kill)

**TODO-2.1.a – Ne plus passer `max_ram_gb` → `--max-ram-mb` automatiquement**

* Dans `superior_orchestrator._launch_run(...)` :

  * retirer la logique qui convertit `max_ram_gb` en `--max-ram-mb`.
* Laisser `--max-ram-mb` uniquement :

  * utilisable *manuellement* en CLI sur `run_single.py`,
  * ou via un champ explicite dans `exp_config` (`run.max_ram_mb`), mais **pas** lié à `scheduler.max_ram_gb` par défaut.

**TODO-2.1.b – Redéfinir la sémantique de `max_ram_gb`**

* Interprétation souhaitable :

  * `max_ram_gb` = **limite soft** de RAM globale pour autoriser N runs simultanés.
  * L’orchestrateur ne tue pas, il **refuse de lancer** un nouveau run si le “poids” cumulé dépasse `max_ram_gb`.

* Implémentation possible (simple, sans mesure en temps réel) :

  1. Ajouter dans `SchedulerConfig` :

     * `approx_ram_per_class` : mapping (`light`|`medium`|`heavy` → estimation Go).
  2. Dans `_current_weight` ou une nouvelle fonction `_current_ram_gb(...)` :

     * estimer la somme `Σ approx_ram_per_class[resource_class(run)]` pour les runs actifs.
  3. Tant que `current_ram_gb + approx_ram_per_class[next_run] > max_ram_gb` :

     * ne pas lancer de nouveau run (attendre qu’un run se termine).

→ On garde ainsi un **modèle RAM du scheduler** sans kill hard.

### 2.2. Encadrer l’utilisation de `--max-ram-mb`

**TODO-2.2.a – Mettre à jour `run_single.py` (help + doc)**

* Modifier le texte d’aide `--max-ram-mb` dans `run_single.py` :

  ```python
  parser.add_argument(
      "--max-ram-mb", type=int, default=None,
      help="Hard RAM limit per run (MB). If exceeded (and psutil is available), the run is killed and exit code 99 is returned."
  )
  ```

* Ajouter dans `dev_V5.md` (section RAM) un paragraphe “Hard limit (optionnel)” qui explique que :

  * ce mécanisme est surtout destiné à des **expériences massives**,
  * il n’est **pas recommandé** comme protection principale.

**TODO-2.2.b – Option globale d’activation**

* Ajouter dans `ExpConfig` un champ optionnel :

  ```yaml
  safety:
    enable_hard_ram_limit: false
    hard_limit_mb: null
  ```

* Dans `superior_orchestrator`, décider :

  * si `enable_hard_ram_limit` est false → **ne jamais** passer `--max-ram-mb`,
  * si true et `hard_limit_mb` défini → passer ce `hard_limit_mb` à `run_single`.

---

## 3. Orchestrateur `superior` : fonctionnalités avancées V5

### 3.1. OOM policy (`oom_policy`)

La spec V5 décrit :

```yaml
oom_policy:
  on_oom: "backoff"  # "skip" | "backoff" | "stop"
  backoff_factor: 0.5
```

**État actuel probable :**

* `run_single` renvoie un code spécifique (99) en cas de dépassement hard (`max-ram-mb`).
* L’orchestrateur enregistre `status="oom"` dans `runs.tsv`, mais **ne modifie pas la suite du plan**.

**TODO-3.1.a – Parsing & stockage de `oom_policy`**

* Étendre `SchedulerConfig` ou `ExpConfig` pour intégrer :

  ```python
  oom_policy: Optional[OomPolicy]
  ```

  avec :

  ```python
  @dataclass
  class OomPolicy:
      on_oom: Literal["skip", "backoff", "stop"] = "skip"
      backoff_factor: float = 0.5
  ```

* Parser ce bloc depuis `exp_config.yml`.

**TODO-3.1.b – Appliquer la politique dans la boucle d’orchestration**

* Cas `on_oom = "skip"` :

  * marquer tous les `RunSpec` futurs avec les **mêmes axes** ou le même `family`/`model_id` comme “skip”.
  * Concrètement :

    * ajouter un champ `skip_reason` dans `RunSpec` ou gérer une set de `run_id` à ignorer.
    * ne jamais lancer ces runs ; `runs.tsv` peut les marquer `status="skipped_oom"`.

* Cas `on_oom = "backoff"` (version **V5 minimale**) :

  * log only + skip pour le moment :

    * marquer les combinaisons identiques comme “skip pour OOM”,
    * TODO ultérieur : mutation dynamique des overrides (`hardware.max_train_docs_*`, etc.).

* Cas `on_oom = "stop"` :

  * dès qu’un run renvoie `status="oom"` :

    * marquer tous les `RunSpec` restants comme `status="aborted_oom_policy"`,
    * arrêter la boucle principale.

---

### 3.2. Early-stop sur critères de qualité (`early_stop`)

Spec V5 :

```yaml
early_stop:
  enabled: true
  min_accuracy: 0.30
  min_macro_f1: 0.25
  apply_to_families: [spacy, hf]
```

**TODO-3.2.a – Implémentation log-only (V5 minimal)**

* Parsing dans `ExpConfig`.
* Après chaque run `evaluate` réussi :

  1. Lire `metrics.json` via `metrics_path`.
  2. Si `family ∈ apply_to_families` et
     `accuracy < min_accuracy` et `macro_f1 < min_macro_f1` :

     * logguer un warning dans `superior/<exp_id>/logs/early_stop.log`,
     * écrire dans `runs.tsv` deux colonnes :

       * `quality_ok: bool`,
       * `quality_flags: str` (ex. `"low_accuracy,low_macro_f1"`).

**TODO-3.2.b – Stratégie d’arrêt (optionnelle, plus tard)**

* Version V2 (future) : utiliser ces flags pour :

  * réduire `run.repeats` pour certaines configs,
  * ou couper des branches d’axes (ex : ne plus tester un certain preset d’équilibrage).

---

### 3.3. Expériences cross-dataset (train A / eval B)

Spec V5 : axe `dataset_pair` + `cross_dataset.train_on` / `cross_dataset.eval_on` + `eval_dataset_id`.

**TODO-3.3.a – Extension core : `eval_dataset_id` dans `core_evaluate`**

* Dans `core_evaluate` :

  ```python
  dataset_id_for_models = params["dataset_id"]
  dataset_id_for_eval = params.get("eval_dataset_id", params["dataset_id"])
  ```

* Utilisation :

  * Modèles : `models/<dataset_id_for_models>/<view>/...`
  * job.tsv : `data/interim/<dataset_id_for_eval>/<view>/job.tsv`.

**TODO-3.3.b – Mapping côté orchestrateur**

* Pour chaque `RunSpec` avec overrides :

  ```yaml
  cross_dataset.train_on: web1
  cross_dataset.eval_on: asr1
  ```

  décider d’une convention :

  * Stage `train` : `dataset_id = train_on`, pas de `eval_dataset_id`.
  * Stage `evaluate` cross :

    * `dataset_id = train_on`,
    * `eval_dataset_id = eval_on`.

* Implémentation possible :

  1. Ajouter des “run types” internes (`normal`, `cross_train`, `cross_eval`).
  2. Lors de la génération du plan :

     * si un axe `dataset_pair` est détecté, générer **deux RunSpec** :

       * un pour `train` (`stage=train`, `dataset_id=train_on`),
       * un pour `evaluate` (`stage=evaluate`, `dataset_id=train_on`, override `eval_dataset_id=eval_on`).

**TODO-3.3.c – Tests d’intégration**

* Construire une mini config :

  ```yaml
  axes:
    - name: dataset_pair
      type: choice
      values:
        - label: train_web1_eval_asr1
          overrides:
            cross_dataset.train_on: web1
            cross_dataset.eval_on: asr1
  ```

* Vérifier :

  * que les modèles sont bien construits sur `web1`,
  * que l’évaluation cross lit `job.tsv` de `web1_asr1` ou `asr1` (selon design choisi).

---

## 4. Documentation & nomenclature

### 4.1. Alignement `experiments` ↔ `superior`

**TODO-4.1.a – Ajouter une NOTE de nommage en tête de `dev_V5.md`**

* Expliquer que :

  * `exp_orchestrator` dans le doc = `scripts/superior/superior_orchestrator.py` dans le code,
  * `scripts/experiments/...` et `experiments/<exp_id>/...` sont des noms historiques logiques,
  * les chemins réels sont `scripts/superior/...` et `superior/<exp_id>/...`.

### 4.2. README : multi-corpus + RAM

**TODO-4.2.a – Ajouter une section “Multi-corpus” dans README**

* Expliquer :

  * `dataset_id`, `data.corpus_ids`, `merge_mode`, `source_field`, `analysis.compare_by`.
  * Donner un exemple complet `web1_asr1` (profil + fichiers écrits dans `data/interim/web1_asr1/...`).
  * Lister les sorties `metrics_by_<field>.json`.

**TODO-4.2.b – Clarifier la gestion de la RAM (core + orchestrateur)**

* Dans la section “Orchestrateur V5 (`superior`)” du README :

  * Décrire la stratégie recommandée :

    * calibrage `hardware.yml` + `MAX_DOCS_*`,
    * `scheduler.parallel` + `max_ram_gb` comme **limites de pilotage**,
    * `--max-ram-mb` comme *option de secours*, désactivée par défaut.
  * Documenter les statuts `success` / `failed` / `oom` dans `runs.tsv` et leur signification.

---

## 5. Nettoyage & tests

### 5.1. Scripts legacy / non utilisés

**TODO-5.1.a – Marquer explicitement les scripts legacy**

* `scripts/experiments/run_grid.py` et assimilés :

  * soit les déplacer dans `scripts/_legacy/`,
  * soit ajouter un commentaire en en-tête :

    * “LEGACY – remplacé par `superior`”.

### 5.2. Tests unitaires / d’intégration

**TODO-5.2.a – Ajouter une batterie de tests pour le core multi-corpus**

* Tests unitaires sur :

  * `resolve_profile_base` avec profils multi-corpus : vérifier `params["corpora"]`, `dataset_id`, `merge_mode`, `source_field`, `analysis.compare_by`.
  * `core_prepare.build_view` avec 2 TEI minimalistes.
  * `core_evaluate` avec un `metrics_by_corpus_id.json` attendu (mock).

**TODO-5.2.b – Tests orchestrateur**

* Tests sur :

  * génération de plan (axes, repeats, seed_strategy),
  * respect de `scheduler.parallel` + `max_weight`,
  * comportement de base des hooks `curves` + `report_markdown` (fichiers générés),
  * parsing et effet de `oom_policy` et `early_stop` (une fois implémentés).

---

Ce backlog te donne la **liste des chantiers restants** pour amener la V5 à l’état “vision complète de `dev_V5.md` + RAM-safe multi-corpus + orchestrateur robuste”.
