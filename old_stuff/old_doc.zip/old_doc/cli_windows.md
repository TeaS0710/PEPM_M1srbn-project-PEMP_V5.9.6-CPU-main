# CLI Windows (PowerShell)

Ce document récapitule les commandes Windows équivalentes aux cibles Makefile et fournit un **smoke test**.

## Préparation
```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m spacy download xx_sent_ud_sm
```

## Préparer la modalité (si besoin)
```powershell
python scripts/tei_add_modality_stream.py --in data/raw/corpus/corpus.xml --out data/raw/corpus/corpus.modality.xml --value web
```

## Smoke test (diagnostic)
```powershell
python scripts/pipeline_check.py ^
  --corpus data/raw/corpus/corpus.modality.xml ^
  --label-field ideology_map ^
  --modality web ^
  --limit 2000 ^
  --min-chars 150 ^
  --max-tokens 400 ^
  --auto-offset-scan
```

## Tâches avec `pepm.ps1`
- Setup :
```powershell
.\pepm.ps1 -Task setup
```
- Pipeline « idéologie / quick » :
```powershell
.\pepm.ps1 -Task pipeline -Profile quick -Label ideology -Mod web -Suite all
```
- Baselines sklearn (active) :
```powershell
.\pepm.ps1 -Task baselines_sklearn_active -Profile quick -Label ideology -Mod web
```
- HF (active) :
```powershell
.\pepm.ps1 -Task hf_active -Profile quick -Label ideology -Mod web
```

## Équivalents manuels (sans pepm.ps1)
(voir README « Windows : CLI & Smoke test » pour les commandes complètes)
