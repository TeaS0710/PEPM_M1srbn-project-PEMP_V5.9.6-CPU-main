# Documentation interne — Projet PEPM (Yi Fan & Adrien)

> **But** : document de référence interne couvrant l’architecture, le fonctionnement détaillé du pipeline, les raisons des choix, les problèmes rencontrés, les check‑lists d’exploitation, et la feuille de route (web prêt, extensible ASR/GOLD).

---

## 1) Vue d’ensemble

Le pipeline transforme des **sources textuelles** (web, transcriptions ASR, jeux gold) en **formats d’entraînement** (TSV → DocBin spaCy) puis entraîne et évalue plusieurs **familles de modèles** : spaCy (BOW/CNN), baselines scikit‑learn (TF‑IDF + SVM/LR/…), et Transformers HF (CamemBERT/Flaubert/…)

**Principes** :

* **CPU‑first** : tout doit tourner sur CPU (GPU optionnel pour HF).
* **Hygiène des données** : sanitation centralisée, déduplication MD5, splits propres.
* **Reproductibilité** : seeds figées, sysinfo, plafonds BLAS, métadonnées de run.
* **Comparabilité** : mêmes métriques/rapports, agrégation dans `reports/summary.csv`.
* **Orchestration** par **Makefile**, scripts paramétrables via CLI, pas de branches de code pour chaque configuration.

---

## 2) Architecture logique (du brut au modèle)

```mermaid
flowchart TD
  %% ===================== SOURCES =====================
  subgraph Sources
    W[Web HTML]
    A[Transcriptions ASR]
    G[Reference gold]
  end

  W --> T1[Unifier TEI]
  A --> T1
  G --> T1

  T1 --> T2[Ajouter terme de modalite]
  T2 --> T3[Nettoyer le texte]
  T3 --> T4[Deduplication MD5]
  T4 --> L{Choisir le champ de label}

  L -- crawl --> L1[Crawl multiclasse]
  L -- ideology --> L2[Ideologie binaire depuis YAML]

  L1 --> S1[Split TRAIN et JOB]
  L2 --> S1

  S1 --> S2[Split DEV depuis TRAIN]
  S1 --> O1[Ecrire TSV TRAIN et JOB]

  S2 --> B{Equilibrer TRAIN}
  B -- none --> B0[TRAIN inchange]
  B -- cap_docs --> B1[Cap par label]
  B -- cap_tokens --> B2[Cap tokens par label]
  B -- alpha_total --> B3[Alpha avec total cible]

  B0 --> C1[Construire DocBin TRAIN et labels json]
  B1 --> C1
  B2 --> C1
  B3 --> C1
  O1 --> C2[Construire DocBin JOB]

  %% ===================== MODELES =====================
  subgraph Modeles
    S[spaCy textcat BOW ou CNN]
    K[Sklearn TF IDF SVM LR SGD RF ExtraTrees]
    H[Transformers HF Camembert Flaubert mBERT]
  end

  C1 --> S
  C1 --> K
  C1 --> H

  %% ===================== SANITY ET PREPARATION =====================
  subgraph Sanity et Preparation
    Q1[Sysinfo]
    Q2[Pipeline check]
    Q3[Sanity labels au moins 2 classes]
  end

  Q1 --> S
  Q2 --> S
  Q2 --> K
  Q2 --> H
  Q3 --> S
  Q3 --> K
  Q3 --> H

  %% ===================== EVALUATION ET RAPPORTS =====================
  subgraph Evaluation et Rapports
    E1[spacy evaluate vers JSON]
    E2[Metriques et confusion pour sklearn et HF]
    A1[Aggregation summary csv]
    M1[Run meta et empreintes donnees]
  end

  S --> E1
  K --> E2
  H --> E2
  E1 --> A1
  E2 --> A1
  O1 --> M1
  C1 --> M1
  C2 --> M1

  %% ===================== ORCHESTRATION MAKEFILE =====================
  subgraph Orchestration Makefile
    P1[Profil quick ou full]
    P2[Champ de label ideology ou crawl]
    P3[Modalite web asr gold any]
    P4[Suite all spacy sklearn hf]
    P5[Config default debug small_cpu large_cpu]
    P6[Arch bow ou cnn]
    P7[Balance none cap_docs cap_tokens alpha_total]
    P8[Ceiling quotas et taskset optionnels]
  end

  P1 --> S1
  P2 --> L
  P3 --> T2
  P4 --> S
  P4 --> K
  P4 --> H
  P5 --> S
  P5 --> K
  P5 --> H
  P6 --> S
  P7 --> B
  P8 --> S
  P8 --> K
  P8 --> H

```

---

## 3) Rôles des répertoires

* `data/raw/` : sources brutes (TEI consolidé, crawls, gold).
* `data/raw/corpus/corpus.xml` : TEI unifié d’entrée.
* `data/raw/corpus/corpus.modality.xml` : TEI après injection `<term type="modality">`.
* `data/interim/` : sorties intermédiaires (TSV `train.tsv`/`job.tsv`, variantes par profil/modality/label_field).
* `data/processed/spacy/` : **DocBin** `.spacy` shardés + `labels.json`.
* `models/` : artefacts d’entraînement (`model-best/`, `model-last/`).
* `reports/` : métriques `*.json`, tables CSV, `summary.csv`, sysinfo, run_meta.
* `logs/` : journaux d’entraînement/éval (timestampés).

**Convention** : la plupart des chemins dérivent automatiquement de `(PROFILE, LABEL_FIELD, MODALITY)` pour éviter la confusion.

---

## 4) Makefile : pourquoi cette orchestration ?

* **Lisibilité** : une ligne pour établir une configuration complète (profil + label + modality + suite).
* **Flexibilité sans toucher au code** : toutes les options clés mappées en variables Make → arguments CLI.
* **Isolation** : variations (debug/small_cpu/large_cpu) prises en charge par des presets.
* **Ressources** : option `CEILING=1` pour exécuter sous `systemd-run` avec quotas CPU/RAM et `taskset`.

**Variables clés** : `PROFILE`, `LABEL_FIELD`, `MODALITY`, `SUITE`, `CONFIG`, `ARCH`, `BALANCE`, `TOTAL`, `JOB_LIMIT`, etc. Voir README pour le tableau complet.

---

## 5) Scripts & responsabilités

* **`tei_add_modality_stream.py`** : ajoute `<term type="modality">VALUE</term>` si absent.
* **`pipeline_check.py`** : mini pipeline pour valider structure du TEI, présence de champs, options (détecte les erreurs courantes).
* **`tei_to_train_job.py`** : TEI → TSV `train.tsv`/`job.tsv` (+ split stratifié, équilibrage TRAIN, sanitation, dédup avant split).
* **`build_spacy_corpus.py`** : TSV → DocBin `.spacy` shardé + `labels.json` (lang, workers, shard size paramétrables).
* **`train_core.py`** : spaCy textcat (BOW/CNN), exclusive classes, Batcher compounding, sauvegarde model‑best/last.
* **`sklearn_baselines.py`** : TF‑IDF + (LinearSVM, LR, SGD, SVM‑RBF, RF, ExtraTrees) + unsup (KMeans, Agglo), CV interne.
* **`hf_baselines.py`** : Transformers HF (CamemBERT/Flaubert/mBERT), CPU par défaut, device auto optionnel.
* **`split_train_dev.py`** : split DEV (stratifié) à l’intérieur de TRAIN.
* **`corpus_stats.py`** : stats EDA (distribution labels, longueurs, doublons) → JSON/CSV (+ visuels optionnels).
* **`metrics_aggregate.py`** : agrège les métriques en `reports/summary.csv`.
* **`run_meta.py`** : hash des fichiers d’entrée, git SHA, timestamp, environnements.
* **`sanity_labels.py`** : échec explicite si TRAIN n’a qu’une seule classe.

---

## 6) Pourquoi ces choix techniques ?

* **TEI + DocBin** : TEI homogénéise les sources (web/ASR/gold), DocBin optimise le chargement spaCy (I/O rapides, mémoire maîtrisée).
* **Équilibrage sur TRAIN uniquement** : préserver **JOB** comme échantillon d’évaluation représentatif.
* **Textcat exclusive (spaCy)** : cohérent avec crawl (multiclasse exclusive) et idéologie (binaire). Open à multilabel si besoin.
* **TF‑IDF + linéaires** : baselines robustes, CPU‑friendly, comparables, utiles pour calibration de seuils.
* **HF CPU** : preuve de concept et baseline ; GPU **optionnel** pour accélérer.
* **Makefile > scripts monolithiques** : composition claire, responsabilités nettes, variation de configuration sans duplication de code.

---

## 7) Flux d’exécution typiques

### 7.1 Quick, idéologie binaire (web)

1. `add_modality_web` (si nécessaire) ; vérifie que le TEI porte la modalité.
2. `prepare` : TEI → TSV (split 80/20, sanitation, dédup, filtre modalité, mapping YAML → labels binaires).
3. `split_quick_dev` : DEV interne dans TRAIN (15 %).
4. `build_spacy_corpus` : TSV → DocBin + labels.json (train et job).
5. `sanity_labels` : check ≥2 classes dans TRAIN.
6. `train` : spaCy textcat (BOW par défaut).
7. `eval` : `spacy evaluate` sur JOB.
8. `aggregate_reports` + `run_meta`.

### 7.2 Quick, crawl multiclasse (web)

Identique, sans YAML d’idéologie. Prévoir classe « long tail » (cap ou regroupement) si nécessaire.

### 7.3 Full, idéologie

Identique mais sans DEV interne par défaut, sharding DocBin plus gros, batchs adaptés.

### 7.4 Baselines scikit‑learn / HF

Après `split_quick_dev` :

* scikit‑learn utilise DEV pour grille `C`.
* HF CPU pour un run court (1–2 époques) ; GPU possible via `USE_GPU=auto`.

---

## 8) Sanitation & déduplication

* **Sanitation** : trims, espaces multiples, normalisation `nbsp/quot`, retrait artefacts (`_blank`, tabs). Implémentée à l’extraction et à l’écriture TSV.
* **Dédup MD5** : appliqué **avant** le split pour éviter fuite d’exemples quasi identiques entre TRAIN/JOB. Log du nombre de doublons retirés par label.

**Raisons** : augmenter la **signal‑to‑noise ratio**, éviter la **leakage**, stabiliser les métriques.

---

## 9) Split & équilibrage

* **Split Train/Job** : 80/20 par défaut, stratifié.
* **Split DEV** : 10–20 % de TRAIN, stratifié, seed fixée.
* **Équilibrage TRAIN seulement** : `none`, `cap_docs`, `cap_tokens`, `alpha_total` (avec garde‑fou `TOTAL>0`). Option `--oversample` pour `cap_docs`.

**Pièges** : cap trop agressif ⇒ classes rares encore plus rares ; préférer `alpha_total` si l’on vise une taille absolue contrôlée du TRAIN.

---

## 10) Entraînement

### 10.1 spaCy (textcat exclusive)

* **BOW** : rapide, baseline robuste.
* **CNN** : plus lent, utile quand beaucoup de données.
* **Batch compounding** : `BATCH_START/BATCH_STOP` contrôlés par Make.
* **Époques** : `EPOCHS_QUICK/FULL` (presets via `CONFIG`).
* **Sorties** : `model-best/`, `model-last/`, `auto_config.cfg`, logs timestampés.

### 10.2 sklearn

* TF‑IDF + LinearSVM/LogReg/SGD/…
* **CV interne** : s’assure de `n_splits <= members_per_class`. Gérer classes rares avec cap/oversample ou réduire `cv`.
* **Export** : métriques macro/weighted, AUC binaire, matrices de confusion.

### 10.3 HF (Transformers)

* **CPU par défaut** (`USE_GPU=0`).
* **GPU auto** si dispo (`USE_GPU=auto`).
* Recommandé : `HF_EPOCHS=1` pour smoke / `2–3` pour quick baseline.

---

## 11) Évaluation, agrégation, méta

* **spaCy** : `spacy evaluate` → JSON (TOK, TEXTCAT macro‑F, ROC‑AUC par label si binaire).
* **sklearn/HF** : F1 macro/weighted, accuracy, AUC, confusion CSV/PNG.
* **Agrégation** : `metrics_aggregate.py` → `reports/summary.csv` (colonnes normalisées pour comparer).
* **Run meta** : `run_meta.py` → `reports/run_meta_*.json` (hashs, git SHA, chemins exacts, horodatage, éventuels paramètres).
* **Sysinfo** : `scripts/sysinfo.py` (CPU/RAM, versions, threads BLAS).

---

## 12) Qualité & tests

### 12.1 Smoke test (rapide, hors prod)

* `CONFIG=debug` :
  
  * époques : 1–2
  * limites TSV/docbin réduites
  * `JOB_LIMIT` bas.

* Commande type :
  
  * `make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web CONFIG=debug SUITE=spacy`

* **Critères de succès** :
  
  * modèles créés (`models/.../model-best/`),
  * fichiers DocBin présents,
  * `reports/summary.csv` non vide,
  * `sanity_labels` OK,
  * aucune exception argparse/import.

### 12.2 Sanity checks automatiques

* `make check MODALITY=web` : vérifie TEI, champs clés, mini transformation.
* `make sanity_labels` : échec si TRAIN n’a qu’un label.

---

## 13) Problèmes rencontrés & résolutions

### 13.1 CLI / argparse

* **Conflit d’option** (`--auto-offset-scan`, `--modality`) : doublons d’`add_argument`. **Action** : dé‑dupliquer la définition (un seul `add_argument` par option), valider via `make check`.

### 13.2 Modalité TEI

* **Erreur `ensure_modality() missing value`** : appel sans `--value`. **Action** : toujours passer `--value web` (via `make add_modality_web`).

### 13.3 Labels uniques

* **spaCy/HF refusent d’entraîner** avec une seule classe dans TRAIN. **Action** : exécuter `sanity_labels`, vérifier mapping YAML (idéologie) et filtrage modalité/split. Sur `crawl`, contrôler le nombre d’exemples par classe après cap.

### 13.4 Sklearn CV

* **`n_splits=3 greater than members per class`** : classes rares. **Actions** :
  
  * relever `cap_docs`/`oversample`,
  * réduire `cv`,
  * augmenter TRAIN (baisser cap),
  * regrouper classes ultra rares ou changer label_field.

### 13.5 Évaluation spaCy

* **`model-last not found`** : entraînement a échoué (voir logs). **Action** : corriger la cause (labels uniques, chemin, erreurs CLI), relancer.

### 13.6 Volumétrie & lenteur

* Torch/HF massifs à l’installation. **Actions** :
  
  * privilégier spaCy/sklearn pour premières itérations,
  * HF avec `EPOCHS=1`,
  * CPU‑only stable, GPU uniquement si environnement prêt.

---

## 14) Performance & tuning

* **Sharding DocBin** : 10–25k (full), 1k (quick ideo) ; évite gros fichiers, accélère I/O.
* **BLAS threads** : `OMP/OPENBLAS/MKL/NUMEXPR=1..WORKERS` (évite over‑subscription).
* **Batch spaCy** : `BATCH_START/BATCH_STOP` (compounding) ; réduire si OOM.
* **JOB_LIMIT** : limiter l’éval coûteuse (`5k` par défaut).
* **Équilibrage** : `alpha_total` pour contraindre la taille du TRAIN, `cap_docs` pour plafonner la queue longue.

---

## 15) Extensibilité ASR/GOLD

* **MODALITY** : passer `MODALITY=asr|gold` (mêmes scripts).
* **Segments** : exploiter `div[type=segments]` pour alignement temporel côté ASR.
* **Comparaisons** : text‑only vs audio‑only vs multimodal (concat ou late‑fusion en phase 2).
* **Métriques** : mêmes rapports → comparabilité conservée.

---

## 16) Sécurité, conformité, éthique

* **PII** : vérifier l’absence de données personnelles sensibles dans les corpus.
* **Logs** : pas de dumps de texte complet dans les logs (compter, ne pas recopier).
* **Licences** : respecter la licence des modèles HF et des ressources de données.

---

## 17) Conventions de nommage & versionnage

* **Dossiers de run** : `family=spacy|sklearn|hf_arch=..._balance=..._seed=..._YYYYMMDD-HHMM` (à formaliser).
* **Rapports** : `reports/<profile>_<modality>_<label>.json/csv`.
* **Meta** : `run_meta_<modality>_<label>_<profile>.json`.

---

## 18) Check‑lists opérationnelles

### 18.1 Avant un run

* [ ] TEI porte bien `<term type="modality">`.
* [ ] `make check MODALITY=...` passe.
* [ ] `sanity_labels` OK (≥2 labels TRAIN).
* [ ] Choix `PROFILE/LABEL_FIELD/MODALITY` clair.
* [ ] Plafonds CPU/RAM si machine partagée (`CEILING=1`).

### 18.2 Après un run

* [ ] `models/.../model-best` présent.
* [ ] `reports/summary.csv` contient la ligne du run.
* [ ] `reports/run_meta_*.json` généré (hashs, SHA).
* [ ] Logs (`logs/run-*.log`) sans erreurs fatales.

---

## 19) Feuille de route

* **Calibration binaire** (Youden / macro‑F1 sur DEV) + ré‑évaluation JOB.
* **Comparateur HTML** d’expériences à partir de `summary.csv`.
* **Export JSONL CIF** (id, label, text, modality, source, url, timestamp, meta) en parallèle des TSV.
* **Multilabel** (textcat multi‑étiquette) si besoin futur.
* **Intégration audio** (alignement segments, features acoustiques optionnelles).

---

## 20) Annexes

### 20.1 Raccourcis Make fréquents

* **Tout‑en‑un, quick, idéologie, web** : `make pipeline PROFILE=quick LABEL_FIELD=ideology MODALITY=web SUITE=all`

* **Matrices spaCy** : `make pipeline PROFILE=quick LABEL_FIELD=crawl SUITE=spacy`

* **Sklearn / HF** : `make pipeline PROFILE=quick LABEL_FIELD=ideology SUITE=sklearn` / `... SUITE=hf USE_GPU=auto`

* **Full + bow** :
  
  ```bash
  make prepare PROFILE=full LABEL_FIELD=ideology && \
  make train PROFILE=full LABEL_FIELD=ideology ARCH=bow && \
  make eval  PROFILE=full LABEL_FIELD=ideology
  ```

### 20.2 Glossaire

* **TEI** : Text Encoding Initiative, schéma XML pour documents textuels.
* **DocBin** : format binaire spaCy pour stocker efficacement des documents.
* **Textcat** : module de classification de texte dans spaCy.
* **Stratifié** : conserve la proportion de classes dans les splits.
* **AUC** : aire sous la courbe ROC (binaire).

---

**Document maintenu par** : Yi Fan & Adrien — 2025.
