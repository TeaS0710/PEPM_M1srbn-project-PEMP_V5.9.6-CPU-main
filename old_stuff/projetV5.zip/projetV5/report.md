# Rapport technique — Projet « classification politique » (WIP)

> **But** : construire une chaîne **reproductible** de l’acquisition web à l’**évaluation** de classifieurs texte (spaCy & CamemBERT), sur un corpus **hétérogène** et **très déséquilibré** (volumes et porosité inter-classes élevés).

---

## Sommaire

1. [Objectif & périmètre](#1-objectif--périmètre)
2. [Acquisition & préparation](#2-acquisition--préparation)
   2.1 [Scraping minet](#21-scrapingminet)
   2.2 [Extraction TEI](#22-extraction-tei)
   2.3 [TEI→TSV (split & rebalance)](#23-teitsv-split--rebalance)
   2.4 [TSV→DocBin](#24-tsvdocbin)
3. [Entraînement & évaluation](#3-entraînement--évaluation)
4. [Matériel & environnement](#4-matériel--environnement)
5. [Résultats préliminaires](#5-résultats-préliminaires)
6. [Problèmes rencontrés & correctifs](#6-problèmes-rencontrés--correctifs)
7. [Recommandations d’amélioration](#7-recommandations-damélioration)
8. [Analyses multi-dimensionnelles (pistes)](#8-analyses-multi-dimensionnelles-pistes)
9. [Recettes reproductibles](#9-recettes-reproductibles)
10. [CamemBERT (GPU ROCm)](#10-camembert-gpu-rocm)
11. [Charge de travail](#11-charge-de-travail)
12. [Gestion surcharge/thermique & quotas](#12-gestion-surchargethermique--quotas)

---

## 1) Objectif & périmètre

* **Chaîne complète** : **scraping** web ciblé → **normalisation TEI** → **TSV** (id, label, texte) → **DocBin** (.spacy) → **entraînement/éval**.
* **Tâche** : classification **exclusive** multi-classes d’“acteurs/labels” (finement poreux, distributions très inégales).
* **Exigences** : reproductibilité (**Makefile**), **rebalance en amont** (pas uniquement post-traitement), traçabilité des métriques.

---

## 2) Acquisition & préparation

### 2.1 Scraping (minet)

* **Outil** : `minet focus-crawl` (périmètre regex strict, reprise, compression, écriture fichiers & metadata CSV).
* **Volume initial** : ~**27 Go** (HTML + métadonnées).
* **Durée collecte** : ~**72 h** (multi-domaine, par lots).
* **Exemple** :

```bash
minet focus-crawl "https://jeune-nation.com/" \
  -O "/data/crawl-jeune-nation-20250928_003021" \
  --only-html --write-files --write-data --resume \
  --compress-transfer --compress-on-disk \
  --domain-parallelism 100 --threads 10 \
  -U '^https?://(?:www\.)?jeune-nation\.com/(?!tag/|auteur/|page/\d+/|feed|rss|.*\?(?:utm_|fbclid|gclid|replytocom)=)' \
  --throttle 0.4 -v
```

* **Bonnes pratiques** : blacklist d’URL bruyantes, nettoyage UTM, reprise sélective, contrôle CSV (`data.csv`) avant extraction texte.

### 2.2 Extraction TEI

* **Extraction** : trafilatura (2.0.0) → **TEI** (xmlns officiel), un seul `corpus.xml` (~**2 Go**).
* **Parsing** : `lxml.iterparse(..., huge_tree=True)` pour lever la limite `XML_PARSE_HUGE`.
* **Structure utile** : `text/body//p`, `text/body/div/head`; métadonnées : `<keywords><term type="crawl">…`.

### 2.3 TEI→TSV (split & rebalance)

* **Script** : `scripts/tei_to_train_job.py`
  **Atouts** :

  * **Streaming** `<TEI>` + **multiprocess** (sérialisation bytes par doc).
  * Filtres : `--min-chars`, `--max-tokens`, dédup **MD5** de texte.
  * **Labels** : `term[type=crawl]` (fallback dossier/xml:id).
  * **Split** : 80/20 (stratifié), `--seed`.
  * **Rebalance amont** :

    * `cap_docs` : plafonne **docs/label** (+option **oversample**, **offset** pour tourner dans les gros labels).
    * `cap_tokens` : plafonne les **tokens/label** (préserve mieux le contenu).
    * `alpha_total` : **échantillonnage tempéré** (garde des proportions globales mais lisse les extrêmes).
  * Sorties : `train.tsv`, `job.tsv` + **sous-TEI** (`corpus_train.xml`, `corpus_job.xml`).

**Run essai (réel)** :

* Collecté détecté : **255 022** `<TEI>`, **limité** : **25 000**, **dédup**: **24 998**.
* Split : train **19 999** / job **4 999**.
* Rebalance train (`cap_docs=5000`, oversample) → **20 000** docs équilibrés (25%/label).
* **Job** **resté asymétrique** (utile pour tester la robustesse).

### 2.4 TSV→DocBin (.spacy)

* **Script** : `scripts/build_spacy_corpus.py`
* Multi-workers, contrôle labels, **DocBin** train/dev, **labels.json**.
* **Pas d’oversample ici** si rebalance déjà faite en TEI→TSV.

---

## 3) Entraînement & évaluation

### 3.1 Entraînement spaCy

* **Script** : `scripts/train_spacy.py` (verbeux, CPU/GPU, ROCm OK).
* **Architectures** :

  1. `arch=cnn` → **tok2vec/CNN** (rapide, robuste).
  2. `arch=trf` → **spaCy-Transformers** (CamemBERT), **GPU ROCm** conseillé.
* **Batcher** : `spacy.batch_by_padded.v1` + `compounding.v1`.
* **Logs** : stats corpus, config imprimée, barres de progression.

### 3.2 Évaluation

* **Script** : `scripts/eval_spacy.py`
  **Sorties** : classification report (TXT), **matrice de confusion** (PNG), **métriques JSON** (macro/weighted/accuracy).

---

## 4) Matériel & environnement

* **CPU** : Intel Core **i5 13ᵉ gen** (architecture hybride) — **20 threads** visibles.
* **RAM** : **32 Go** DDR5.
* **GPU** : AMD **RX 7900 XT** (~**21.5 Go** VRAM visibles sous ROCm).
* **Python** : 3.12.3 — **spaCy 3.8.7** — **torch 2.4.1+rocm6.0**.

Extrait `make sysinfo` :

```
[PY] 3.12.3
[spaCy] 3.8.7
[ENV] OMP=20 OPENBLAS=20 MKL=20
[Torch] installed
[GPU] VISIBLE | torch 2.4.1+rocm6.0 hip 6.0...
 GPU0: AMD Radeon RX 7900 XT
```

---

## 5) Résultats préliminaires

* **Train (équilibré cap_docs=5000)** : **20 000** docs (25% par label).
* **Job (asymétrique)** : **4 999** docs (ex. majoritaire ≈ 76.6%).

**CNN (exclusive multiclass) – métriques réelles** :

* **Accuracy** ≈ **0.727**
* **Macro-F1** ≈ **0.449**
* **Weighted-F1** ≈ **0.733**

Par classe (extraits) :

* `contretemps` : **P=0.84 R=0.81 F1=0.83** (n=3829)
* `initiative-communiste` : **F1=0.43** (n=1003)
* `eco-full` : **F1=0.55** (n=135)
* `cce-full` : **F1=0.00** (n=33)

**Lecture** : bonne **accuracy** portée par la grande classe du **job** ; **macro-F1** en retrait car **petites classes** très peu rappelées → **mismatch distributionnel** + **porosité**.

---

## 6) Problèmes rencontrés & correctifs

* **XML énorme** : `huge_tree=True`, **iterparse** + `el.clear()` pour limiter RAM.
* **Configs spaCy v3.8** : champs invalides (`exclusive_classes` au mauvais niveau, `mixed_precision`, anciens schedulers…) **corrigés**.
* **Déséquilibres massifs** : **rebalance amont** (cap_docs, cap_tokens, alpha_total) + **dédup** texte.
* **Bruit/langue** : besoins identifiés → **filtre langue** (fastText/langid) et **heuristiques anti-spam** (casino, non-FR, vide).

---

## 7) Recommandations d’amélioration

**Avant l’entraînement**

* **Filtrage langue** : ne garder que **fr** (± en).
* **Anti-bruit** : seuils longueur/densité alpha, blacklist (casino, spam).
* **Rebalance tempérée** : privilégier `alpha_total` (α ∈ [0.3, 0.7]) et/ou `cap_tokens` (ex. 1–5 M tokens/label) pour **ne pas laminer** les gros corpus.

**Pendant l’entraînement**

* **CNN** : 8–12 epochs, `dropout` 0.2–0.3, batch max 2048, `patience` > 1000 steps.
* **Transformers (ROCm)** : CamemBERT, **bf16**, **gradient checkpointing**, batch 16→64, accumulate 2–4.

**Après l’entraînement**

* Diagnostics par **longueur**, **domaine**, **période**.
* PR curves par classe, calibration seuil si passage **multi-label**.
* Évaluations **one-vs-rest** ou **hiérarchiques** si porosité trop forte.

---

## 8) Analyses multi-dimensionnelles (pistes)

* **Topics** (NMF / BERTopic) par label → axes idéologiques, variations.
* **Temps** : séries temporelles (volumes, entropie lexicale).
* **Réseaux** : co-mentions personnes/organisations, co-domaines (liens sortants).
* **Style** : lisibilité, POS, entropie, mots fonctionnels.

---

## 9) Recettes reproductibles

```bash
# 0) Environnement
python3 -m venv .venv && source .venv/bin/activate
make setup
make sysinfo

# 1) TEI -> TSV (25k, dédup, rebalance cap_docs=5000)
make quick      # alias quick_capdocs

# 2) DocBin + 3) Train + 4) Eval (inclus dans la recette quick)
```

---

## 10) CamemBERT (GPU ROCm)

```bash
make setup-hf-rocm
make gpu-check
make quick_trf
```

> Conseils : `bf16`, gradient checkpointing, batch progressif 16→64, accumulate 2–4, monitoring `rocm-smi`.

---

## 11) Charge de travail

**Heures “humaines” (hors temps machine)**

1. Environnement/infra : **2–4 h**
2. Scraping minet : **3–6 h** *(crawl long en arrière-plan)*
3. TEI & parsing massif : **3–6 h**
4. Pré-traitements & rebalance : **6–12 h**
5. DocBin & contrôles : **1–2 h**
6. Entraînement spaCy (CNN, ≥2 itérations) : **2–8 h**
7. spaCy-Transformers (1–2 cycles) : **4–10 h**
8. Analyses & reporting : **3–6 h**
9. Docs & Makefile : **2–4 h**

**Ordres de grandeur**

* **Socle reproductible** : **~25–50 h**
* **Montée en qualité** (+filtres + rebalance + Transformers + analyses) : **+20–40 h**

**Position actuelle** : ~**22–35 h** déjà investies (collecte, parsing, rebalance, DocBin, 1er training + éval). Reste **~10–25 h** pour consolider (**filtre langue/bruit**, nouvelle passe & rapport), **+20–40 h** pour l’analyse avancée.

---

## 12) Gestion surcharge/thermique & quotas

### 12.1 Symptômes & risques

* **Freeze/kill** (OOM/throttle cgroup),
* **Températures** proches **100 °C** CPU (Tjunction) et **hotspot GPU** élevé (RDNA3),
* **DDR5** : débit élevé, chauffe PMIC, airflow critique.

### 12.2 Points techniques (i5-13ᵉ, DDR5, RX 7900 XT)

* **i5-13ᵉ** : P-cores (HT) + E-cores (sans HT), exemple 6P+8E = 20 threads ; turbo agressif, TjMax ≈ 100 °C.
* **DDR5** : plus de débit, latence ns souvent ~équivalente/supérieure à DDR4 (ex. 6000 CL36 ≈ 12 ns).
* **RX 7900 XT (ROCm)** : surveiller **hotspot** & **VRAM** (`rocm-smi`), ajuster **ventilation**/power si possible.

### 12.3 Encapsulation cgroup (CPU/RAM/SWAP) + pinning

> `CPUQuota` : 100 % = 1 cœur logique. Sur 20 threads, **600 % ≈ 6 cœurs**.

**CPU-only “safe”** :

```bash
MEM=22G; SWAP=6G; CPUQ=600; CORES=0-19
systemd-run --user --scope \
  -p MemoryMax=$MEM -p MemorySwapMax=$SWAP -p CPUQuota=${CPUQ}% -p AllowedCPUs=$CORES \
  bash -lc '
    export OMP_NUM_THREADS=12 OPENBLAS_NUM_THREADS=12 MKL_NUM_THREADS=12 NUMEXPR_NUM_THREADS=12
    export TOKENIZERS_PARALLELISM=false HIP_VISIBLE_DEVICES=
    taskset -c '"$CORES"' \
    python3 scripts/train_spacy.py \
      --train data/processed/spacy/train_try.spacy \
      --dev   data/processed/spacy/job_try.spacy \
      --out   models/spacy_try_cpu \
      --lang fr --gpu -1 --arch cnn --epochs 5 --eval-freq 200
  '
```

**GPU ROCm (Transformers)** :

```bash
MEM=18G; SWAP=4G; CPUQ=300; CORES=0-11
systemd-run --user --scope \
  -p MemoryMax=$MEM -p MemorySwapMax=$SWAP -p CPUQuota=${CPUQ}% -p AllowedCPUs=$CORES \
  bash -lc '
    export OMP_NUM_THREADS=6 OPENBLAS_NUM_THREADS=6 MKL_NUM_THREADS=6 NUMEXPR_NUM_THREADS=6
    export HIP_VISIBLE_DEVICES=0 ROCR_VISIBLE_DEVICES=0 HSA_VISIBLE_DEVICES=0
    export PYTORCH_HIP_ALLOC_CONF="garbage_collection_threshold:0.5,max_split_size_mb:64"
    python3 scripts/train_spacy.py \
      --train data/processed/spacy/train_try.spacy \
      --dev   data/processed/spacy/job_try.spacy \
      --out   models/spacy_trf_try \
      --lang fr --gpu 0 --arch trf --hf-model camembert-base \
      --epochs 2 --accumulate 2 --batch-start 16 --batch-stop 64 --eval-freq 300
  '
```

**Moniteurs utiles** :

```bash
sudo turbostat --Summary --interval 2
watch -n2 "sensors"
watch -n2 "rocm-smi --showtemp --showpower --showuse --showfan"
htop
```

**TL;DR réglages sûrs** :
CPU-only → `CPUQuota=600%`, `OMP=12`.
GPU ROCm → `CPUQuota=300%`, `OMP=6`, `bf16` + grad checkpointing, VRAM non saturée.
RAM → `MemoryMax=22G`, `Swap=4–6G` (zram si dispo).
Thermique → ventilation boîtier/GPU renforcée.

---

### Annexes — Scripts & rôles

* `tei_to_train_job.py` : TEI→TSV (split + rebalance + dédup + sous-TEI).
* `build_spacy_corpus.py` : TSV→DocBin + `labels.json`.
* `train_spacy.py` : entraînement spaCy (cnn/trf, CPU/GPU, verbeux).
* `eval_spacy.py` : rapports, confusion, métriques JSON.
* `train_eval_transformer.py` : baseline HF “pure”.
* `make_ideology_skeleton.py` : statistiques d’acteurs & gabarit d’idéologie.

---

> **État** : pipeline **fonctionnel** (essai et full), **rebalance amont** opérationnel, **évaluations** produites. Prochaines étapes : **filtrage langue/bruit**, **alpha/cap_tokens**, **CamemBERT ROCm** pour gagner en **macro-F1** sans laminer les gros corpus.
