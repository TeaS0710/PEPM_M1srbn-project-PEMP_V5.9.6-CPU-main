# Projet "Classification politique" — de TEI a spaCy / HF

**Objectif** : pipeline reproductible de classification de textes politiques, de l’acquisition web a l’evaluation, avec **gros volumes**, **desiquilibres massifs** et option **GPU AMD ROCm**.

**Chaîne** : scraping (minet) -> TEI -> TSV -> DocBin (.spacy) -> entrainement/eval (spaCy CNN & spaCy-Transformers / HF).
**Principes** : RAM-first, multithread “raisonnable”, **equilibrage en amont** du train, test honnete (job intact), scripts idempotents, Makefile central.

---

## 1) Vue d’ensemble (mental model fiable)

```
[Web] --minet--> [HTML + data.csv]
      --trafilatura--> [teiCorpus.xml]
      --tei_to_train_job.py--> [train.tsv, job.tsv] (+ sous-TEI)
      --build_spacy_corpus.py--> [train.spacy, job.spacy, labels.json]
      --train_spacy.py (cnn/trf)--> [models/spacy_*]
      --eval_spacy.py--> [metrics.json, confusion.png, classification_report.txt]
```

**Invariants** :

* Le **job** est le test “reel”: **jamais re-equilibre**.
* L’**equilibrage** ne touche que le **train** (cap_docs / cap_tokens / alpha_total).
* Tous les scripts sont **streaming** ou “RAM-first” pour tenir sur machine perso.

---

## 2) Environnement, CPU, threads, ROCm (point cle)

### 2.1 Threads CPU et BLAS (eviter la tempete de threads)

* spaCy “pipeline” (CNN) utilise des threads internes.
* `n_process` (multiproc dans les scripts) **doit rester modere** si BLAS (OpenBLAS/MKL/Numexpr) a beaucoup de threads.
* Recommandation de base (machine 20 threads logiques) :

  * `OMP_NUM_THREADS=12 OPENBLAS_NUM_THREADS=12 MKL_NUM_THREADS=12 NUMEXPR_NUM_THREADS=12`
  * `n_process` / `--workers` autour de **8–16** selon charge I/O.
* Eviter: `n_process=32` + `OMP=32` + batchs geants -> sursaturation, latences, “thrash”.

### 2.2 ROCm (AMD) : realites pratiques

* Exporter explicitement la carte :

  * `HIP_VISIBLE_DEVICES=0` (ou 1, etc.).
* Variables utiles (fragmentation VRAM) :

  * `PYTORCH_HIP_ALLOC_CONF="garbage_collection_threshold:0.5,max_split_size_mb:64"`
* **Precision** : RDNA3 supporte bien **bf16**.
* **Gradient checkpointing** (Transformers) : echange compute <-> memoire.
* **Accumulation** (`--accumulate`) pour simuler de gros batchs sous faible VRAM.

### 2.3 “Safe scopes” (eviter freeze/OOM)

Encapsuler une cible dans un **scope systemd** avec quotas RAM/CPU :

```bash
MEM=22G; SWAP=6G; CPUQ=600; CORES=0-19
systemd-run --user --scope \
  -p MemoryMax=$MEM -p MemorySwapMax=$SWAP -p CPUQuota=${CPUQ}% -p AllowedCPUs=$CORES \
  bash -lc 'export OMP_NUM_THREADS=12 OPENBLAS_NUM_THREADS=12 MKL_NUM_THREADS=12 NUMEXPR_NUM_THREADS=12; \
            taskset -c '"$CORES"' make quick'
```

Moniteurs: `htop`, `watch -n2 sensors`, `watch -n2 "rocm-smi --showtemp --showuse --showfan"`.

---

## 3) Scraping (minet) — erreurs, bruits, reprise

### 3.1 Focus-crawl solide (exemple generique)

```bash
minet focus-crawl "https://site.tld/" \
  -O "./data/crawls/crawl-site-YYYYMMDD_HHMMSS" \
  --only-html --write-files --write-data --resume \
  --compress-transfer --compress-on-disk \
  --domain-parallelism 80 --threads 10 --throttle 0.4 -v \
  -U '^https?://(?:www\.)?site\.tld/(?!tag/|auteur/|page/[0-9]+/|feed|rss|.*\?(utm_|fbclid|gclid|replytocom)=)'
```

**Trappes a bruit** :

* listicles, tags, archives paginees, “/feed”, “/rss”, `?utm_`, `replytocom`…
* **canonical** vs URL dupliquees : minet stocke `resolved_url` (preferer cette colonne pour de-dup).
* Binary/HTML mixtes : garder `--only-html`.

### 3.2 “Refetch propre” (ne pas ecraser, reprendre sur erreurs)

**Principe**: (1) lister cibles valides, (2) lister deja faits, (3) diff, (4) refetch.

```bash
CRAWL="crawl-foo-YYYYMMDD_HHMMSS"
DATA="$CRAWL/data.csv"
JOBS="$CRAWL/jobs.csv"
OUT="$CRAWL/pages"
REPORT="$CRAWL/report_refetch.csv"

A="$(mktemp)"; B="$(mktemp)"

# 1) toutes les cibles valides (http/https non vides)
csvcut -c target "$DATA" \
  | tail -n +2 | tr -d '\r' \
  | awk 'NF && $0 ~ /^https?:\/\//' \
  | sed 's/^[[:space:]]\+//' \
  | LC_ALL=C sort -u > "$A"

# 2) deja faits (resolved_url) depuis jobs + report_refetch (si existe)
{ [ -s "$JOBS" ] && csvcut -c resolved_url "$JOBS" | tail -n +2; \
  [ -s "$REPORT" ] && csvcut -c url "$REPORT" | tail -n +2; } \
  | tr -d '\r' | awk 'NF' | LC_ALL=C sort -u > "$B"

# 3) diff -> a faire
comm -23 "$A" "$B" > urls_to_fetch.txt

# 4) refetch sans ecraser (CSV minimal pour minet fetch)
{ printf "url\n"; cat urls_to_fetch.txt; } > urls_refetch.csv
minet fetch urls_refetch.csv -o "$REPORT" --write-files --resume --compress-on-disk -d "$OUT"
```

**Remove URL fautive et reprendre** :

```bash
# Supprime une URL precise du CSV data
csvgrep -c target -m "https://site.tld/url-probleme" -i "$DATA" > "${DATA%.csv}.clean.csv"
mv "${DATA%.csv}.clean.csv" "$DATA"
# Relance un focus-crawl ou un fetch dedie selon besoin
```

**Pro tips** :

* Toujours `LC_ALL=C sort -u` (stable, rapide).
* Verifier les status HTTP (>=400), tailles extremes (0B ou 50MB), content-type; blacklister si besoin.
* **Resume** est ton ami; evite `--overwrite`.

---

## 4) TEI -> TSV (streaming, dedup, labels)

### 4.1 Parsing “HUGE”

* `lxml.iterparse(..., huge_tree=True)`, nettoyage `el.clear()` pour liberer la RAM au fil de l’eau.
* Normaliser texte (espaces, Unicode NFC/NFKC, quotes droites) avant hashing.

### 4.2 Dedup exact

* Hash **MD5 du texte normalise** (pas de l’URL) -> c’est ce qu’on veut retirer des doublons “copier/coller”.

### 4.3 Labels

* Source preferentielle: `<keywords><term type="crawl">...`
* Fallback possibles: nom de dossier, attribut `xml:id`, heuristiques de host.
* Centraliser une **table de mapping** (`configs/ideology.yml`) si tu fusionnes des crawls.

### 4.4 Split & rebalance amont

* **Stratifie** 80/20 par label (seed fixe).
* Rebalance uniquement le **train** :

  * `cap_docs` : plafonne **nombre de docs/label** (+ `--oversample`, `--offset` pour “tourner” dans les gros).
  * `cap_tokens` : plafonne **nb de tokens/label** (meilleure conservation du contenu).
  * `alpha_total` : echantillonnage **tempare** (garde des proportions globales mais lisse les extremes).

**Quand utiliser quoi ?**

* `cap_docs` : rapide, simple, efficace si docs ~ homogènes.
* `cap_tokens` : mieux si les tailles de docs varient beaucoup.
* `alpha_total` : quand tu veux **eviter** de laminer les gros labels tout en reduisant l’ecart.

---

## 5) TSV -> DocBin (.spacy)

* `nlp.pipe(..., n_process=N)` : attention a la memoire.
* Sauver `labels.json` (ordres/ids fixes).
* **Ne pas** re-equilibrer ici si c’est deja fait en TEI->TSV.

---

## 6) Entrainement — spaCy CNN vs Transformers

### 6.1 CNN (tok2vec)

* **Robuste** et rapide, bon baseline.
* Batching “compounding”: `--batch-start`, `--batch-stop`.
* `--eval-freq` suffisamment frequent (ex. 200–300 steps) pour voir les plateaux.

**Recette CPU sure** :

* `--epochs 8–12`, `--dropout 0.2–0.3`, `--batch-stop 2048`, `OMP=8–12`, `--threads $(THREADS)`.

### 6.2 Transformers (spaCy-Transformers, CamemBERT)

* Necessite `spacy-transformers` + torch ROCm.
* **VRAM** : surveiller `rocm-smi`.
* Reduire le pic memoire : `bf16`, `--grad-checkpoint`, `--accumulate`, batches modestes (ex. start 16 -> stop 64).
* Si instable: basculer **HF pur** (`train_eval_transformer.py`) et garder spaCy pour l’inference CNN.

---

## 7) Evaluation — lecture des scores (pieges classiques)

* **Accuracy** “tire” par la classe majoritaire quand le job est tres desequilibre.
* **Macro-F1** reflète la qualite moyenne sur **toutes** les classes (sensible aux rares).
* **Weighted-F1** pondere par la taille de chaque classe (plus proche de l’accuracy sur desiquilibres forts).

**Bon reflexe** :

* Rapporter **macro-F1**, **balanced accuracy** et la **matrice de confusion** (brute + normalisee).
* En diagnostic, tu peux construire un **job_balanced** (copie equilibree) pour comparer des modeles, mais **ne remplace pas** le job reel.

---

## 8) Perf cookbook (CPU/GPU/Disk)

### 8.1 CPU

* Ne pas depasser “raisonnablement” `n_process ~ Ncoeurs / 2` si BLAS multithread derriere.
* Eviter NUMA cross-sockets si machine bi-CPU (pinning: `taskset -c`).

### 8.2 I/O disque

* **Compresser** HTML/DocBin si l’espace manque (minet fait deja du gz).
* Eviter les millions de petits fichiers en profondeur excessive (latence FS).
* Utiliser `tmpfs` pour intermediaires si RAM large (attention OOM).

### 8.3 GPU ROCm

* `bf16` par defaut si supporte.
* `--accumulate 2–4`, `--grad-checkpoint` si VRAM < 16–20 Go.
* Ajuster `PYTORCH_HIP_ALLOC_CONF` pour eviter la fragmentation.

---

## 9) Reproductibilite

* Figer `SEED` pour le split et l’entrainement.
* Noter que certains kernels (GPU) restent **legerement non deterministes** (libres a l’implementation).
* Versionner `requirements.txt` et `labels.json`.
* Eviter de modifier l’ordre des labels entre runs.

---

## 10) Legal/ethique (rappel rapide)

* Respecter `robots.txt` quand c’est requis par ta politique institutionnelle.
* Ne pas publier de donnees personnelles sensibles.
* Citer les sources si redistribuées; tenir compte des termes d’usage des sites.

---

## 11) Checklists operatoires

**Avant run** :

* `[ ]` Espace disque OK (HTML+DocBin+models).
* `[ ]` `ulimit -n` augmente si gros crawl.
* `[ ]` Variables OMP/BLAS calées.
* `[ ]` ROCm visible (`rocm-smi`, `torch.cuda.is_available()`).

**Pendant run** :

* `[ ]` Moniteurs (CPU, RAM, VRAM, T°).
* `[ ]` Logs gardes (rediriger `tee`).

**Apres run** :

* `[ ]` Sauvegarde `models/*/model-best`.
* `[ ]` Rapports `reports/*`.
* `[ ]` Verifier labels / confusion (classe “autre” qui gonfle = souci de mapping).

---

## 12) Commandes Makefile usuelles (rappel)

```bash
# Setup & diag
make setup
make sysinfo

# Essais CPU (train equilibre, job intact)
make quick            # cap_docs
make quick_captokens  # cap_tokens
make quick_alpha      # alpha_total

# FULL CPU
make full
make full_captokens
make full_alpha

# GPU ROCm
make setup-hf-rocm
make gpu-check
make quick_gpu_cnn
make quick_trf
make full_trf

# HF pur (option)
make hf

# Nettoyage
make clean
```

**Overrides utiles** (au vol) :

```bash
make quick_capdocs LIMIT_TRY=50000 MAX_TOKENS_TRY=900 CAP_PER_LABEL=6000 OFFSET=1000 SEED=2026 NPROC=16 THREADS=16
HIP_VISIBLE_DEVICES=0 make quick_trf GPU_ID=0 TRF_MODEL=camembert-base TRF_EPOCHS_TRY=3 TRF_ACCUM=3 TRF_BATCH_START_TRY=8 TRF_BATCH_STOP_TRY=48 TRF_DROPOUT=0.2
HIP_VISIBLE_DEVICES=0 make full_trf GPU_ID=0 TRF_BATCH_START_FULL=24 TRF_BATCH_STOP_FULL=144 TRF_EPOCHS_FULL=4 TRF_ACCUM=4
```

---

## 13) Erreurs frequentes & correctifs

### 13.1 minet “ValueError” / URL toxique

* **Solution rapide** : retirer l’URL fautive de `data.csv` (cf. section 3.2), relancer.
* Verifier `jobs.csv` et `report_refetch.csv` pour conserver l’historique, eviter refetch en boucle.

### 13.2 lxml `XMLSyntaxError` / entites bizarres

* Ajoute `huge_tree=True` et parser tolerant.
* Filtrer les pages vides ou HTML cassé avant la conversion TEI.

### 13.3 OOM / freeze CPU

* Baisser `--batch-stop`, `LIMIT_TRY`, `NPROC` et threads BLAS.
* Envelopper dans un scope `systemd-run` avec `MemoryMax`.
* Controler que le swap n’est pas sature.

### 13.4 OOM VRAM / fragmentation ROCm

* Activer `bf16`, `--grad-checkpoint`, `--accumulate`.
* Ajuster `PYTORCH_HIP_ALLOC_CONF`.
* Reduire `TRF_BATCH_STOP_*`.

### 13.5 spaCy 3.8 config errors

* Ne pas injecter des champs non supports (ex: `exclusive_classes` au mauvais niveau, schedulers legacy).
* Utiliser le **script** qui imprime la config effective; partir de lui.

### 13.6 Scores “bizarres”

* Job **trop desiquilibre** -> accuracy “pleine”, macro-F1 basse = normal.
* Confusion “diagonale” faible -> labels mal mappes ou classes trop proches -> revoir `ideology.yml`, ou passer a un schema **multi-label** (a moyen terme).

---

## 14) Annexes — Scripts & roles

* `make_ideology_skeleton.py` : inventaire d’acteurs, `configs/ideology.yml`, `reports/actors_counts.tsv`.
* `tei_to_train_job.py` : TEI -> TSV (split + rebalance + dedup + sous-TEI).
* `build_spacy_corpus.py` : TSV -> DocBin + `labels.json`.
* `train_spacy.py` : entrainement spaCy (cnn/trf, CPU/GPU, logs).
* `eval_spacy.py` : `classification_report.txt`, `confusion_matrix.png`, `metrics.json`.
* `train_eval_transformer.py` : CamemBERT HF pur (fallback GPU simple).

---

## 15) Arborescence (exemple)

```
data/
  raw/corpus/corpus.xml
  interim/{splits,splits_try}
  processed/spacy/
models/
reports/
scripts/
Makefile
```

---

## 16) Roadmap qualite (suggestions)

1. **Filtre langue** (FR strict) + heuristiques anti-spam (casino, “article vide”).
2. **cap_tokens** ou **alpha_total** par defaut (moins brutal que cap_docs).
3. **Diagnostics** par longueur/domaine/periode (devoile les biais).
4. **Transformers ROCm**: bf16 + checkpointing + accumulate; sinon HF pur.
5. **Multi-label** si porosites fortes (but: penaliser moins les confusions “voisines”).
6. **Calibration** (seuils par classe) si besoin d’un “top-k” plus utile que l’argmax.

---

## 17) Licences & citation

Projet pedagogique; verifie la licence des contenus scrapes; cite le depot/rapport si reutilisation. Contributions bienvenues (filtres langue, diagnostics perf, configs).
