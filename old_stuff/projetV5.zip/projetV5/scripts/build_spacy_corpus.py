#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, json, os, random, sys
from pathlib import Path
from typing import List, Dict
import pandas as pd
import spacy
from spacy.tokens import DocBin

def oversample(df: pd.DataFrame, label_col: str = "label", seed: int = 42) -> pd.DataFrame:
    random.seed(seed)
    counts = df[label_col].value_counts()
    max_n = counts.max()
    parts = []
    for lab, n in counts.items():
        sub = df[df[label_col] == lab]
        if n < max_n and n > 0:
            extra = sub.sample(max_n - n, replace=True, random_state=seed)
            sub = pd.concat([sub, extra], axis=0)
        parts.append(sub)
    return pd.concat(parts, axis=0).sample(frac=1.0, random_state=seed)

def limit_stratified(df: pd.DataFrame, N: int, seed: int = 42) -> pd.DataFrame:
    if N <= 0 or N >= len(df): return df
    frac = N / float(len(df))
    out = (df.groupby("label", group_keys=False)
             .apply(lambda g: g.sample(frac=min(1.0, frac), random_state=seed)))
    if len(out) > N:
        out = out.sample(n=N, random_state=seed)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tsv", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--labels-out", type=Path, required=True)
    ap.add_argument("--lang", type=str, default="fr")
    ap.add_argument("--workers", type=int, default=max(1, os.cpu_count() or 2))
    ap.add_argument("--batch", type=int, default=1000)
    ap.add_argument("--balance", choices=["none","oversample"], default="none")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--gpu", action="store_true", help="tente spaCy GPU (CUDA uniquement)")
    args = ap.parse_args()

    df = pd.read_csv(args.tsv, sep="\t")
    if args.limit and args.limit > 0:
        df = limit_stratified(df, args.limit, args.seed)
        print(f"[INFO] TSV limité à {len(df)} lignes (essai).")

    if args.balance == "oversample":
        df = oversample(df, "label", seed=args.seed)

    labels = sorted(df["label"].astype(str).unique())
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.labels_out.parent.mkdir(parents=True, exist_ok=True)

    if args.gpu:
        try:
            spacy.require_gpu()
        except Exception:
            print("[WARN] GPU spaCy indisponible, fallback CPU.")

    nlp = spacy.blank(args.lang)
    nlp.max_length = 2_000_000

    texts = df["text"].astype(str).tolist()
    y = df["label"].astype(str).tolist()

    cats_list: List[Dict[str, float]] = []
    for lab in y:
        cats = {L: 0.0 for L in labels}; cats[lab] = 1.0; cats_list.append(cats)

    db = DocBin(store_user_data=False)

    def gen_texts():
        for t in texts: yield t

    for doc, cats in zip(nlp.pipe(gen_texts(), n_process=args.workers, batch_size=args.batch), cats_list):
        doc.cats = cats; db.add(doc)

    db.to_disk(args.out)
    Path(args.labels_out).write_text(json.dumps(labels, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] wrote {args.out} ({len(df)} docs)")
    print(f"[OK] labels → {args.labels_out}: {labels}")

if __name__ == "__main__":
    main()
