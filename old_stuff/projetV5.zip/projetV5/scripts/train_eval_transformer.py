#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, json, os
from pathlib import Path
from typing import Dict, List
import numpy as np, pandas as pd
import torch
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                             classification_report, confusion_matrix)
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                          Trainer, TrainingArguments, DataCollatorWithPadding)

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

# ---------------- utils ----------------
def set_threads(n:int):
    n = max(1, n)
    try:
        torch.set_num_threads(n)
        torch.set_num_interop_threads(max(1, n//2))
    except Exception:
        pass
    try:
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
    except Exception:
        pass
    return n

def plot_cm(cm: np.ndarray, labels: List[str], out: Path):
    fig, ax = plt.subplots(figsize=(max(6, 0.6*len(labels)), max(5, 0.6*len(labels))))
    im = ax.imshow(cm, interpolation="nearest"); ax.figure.colorbar(im, ax=ax)
    ax.set(xticks=np.arange(cm.shape[1]), yticks=np.arange(cm.shape[0]),
           xticklabels=labels, yticklabels=labels, ylabel="True", xlabel="Pred")
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
    if cm.size <= 2500:
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, f"{int(cm[i,j])}", ha='center', va='center', fontsize=8)
    fig.tight_layout(); out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=200, bbox_inches="tight"); plt.close(fig)

class TextDS(torch.utils.data.Dataset):
    def __init__(self, df: pd.DataFrame, tok, label2id: Dict[str,int], max_len: int):
        self.texts = df["text"].astype(str).tolist()
        self.labels = [label2id[x] for x in df["label"].astype(str).tolist()]
        self.tok = tok; self.max_len = max_len
    def __len__(self): return len(self.texts)
    def __getitem__(self, i):
        enc = self.tok(self.texts[i], truncation=True, max_length=self.max_len)
        enc["labels"] = self.labels[i]
        return enc

# ---------- Trainer pondéré ----------
class WeightedTrainer(Trainer):
    def __init__(self, *args, class_weights: torch.Tensor|None=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.class_weights = class_weights

    def compute_loss(self, model, inputs, return_outputs=False):
        labels = inputs.pop("labels")
        outputs = model(**inputs)
        logits = outputs.logits
        loss_fct = torch.nn.CrossEntropyLoss(weight=self.class_weights.to(logits.device)
                                             if self.class_weights is not None else None)
        loss = loss_fct(logits.view(-1, logits.size(-1)), labels.view(-1))
        return (loss, outputs) if return_outputs else loss

# ---------------- main ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--eval",  type=Path, required=True)
    ap.add_argument("--model", type=str, default="camembert-base")
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--max-len", type=int, default=512)
    ap.add_argument("--workers", type=int, default=max(1, os.cpu_count() or 2))
    ap.add_argument("--outdir", type=Path, default=Path("model_out"))
    ap.add_argument("--grad-ckpt", action="store_true", help="activer gradient checkpointing")
    ap.add_argument("--accum", type=int, default=1, help="gradient accumulation steps")
    # ROCm-safety switches
    ap.add_argument("--precision", choices=["auto","fp32","fp16","bf16"], default="auto",
                    help="auto = bf16 si supporté; sinon fp32")
    ap.add_argument("--no-pin-memory", action="store_true",
                    help="désactive pin_memory des DataLoaders")
    ap.add_argument("--no-force-cpu-batches", action="store_true",
                    help="par défaut on force la création des batchs sur CPU (plus sûr sur ROCm)")
    args = ap.parse_args()

    threads = set_threads(args.workers)

    # *** Force les batches sur CPU (évite HIP 'invalid device function' en amont) ***
    if not args.no_force_cpu_batches:
        try:
            torch.set_default_device("cpu")
            print("[CFG] default device forced to CPU for dataloaders")
            try:
                # Désactive les kernels SDPA ‘flash’/mem-efficient (inoffensif sur ROCm)
                torch.backends.cuda.sdp_kernel(enable_flash=False, enable_mem_efficient=False, enable_math=True)
                print("[CFG] SDPA fused kernels disabled (flash/mem_efficient)")
            except Exception:
                pass
        except Exception as e:
            print("[WARN] could not set default device CPU:", e)

    is_gpu = torch.cuda.is_available()
    print(f"[ENV] torch={torch.__version__} | cuda_available={is_gpu} | threads={threads}")
    if is_gpu:
        try: print(f"[ENV] device0={torch.cuda.get_device_name(0)}")
        except Exception: print("[ENV] device0=?")
        try:
            free, total = torch.cuda.mem_get_info()
            print(f"[ENV] VRAM free/total = {int(free/2**20)}MiB / {int(total/2**20)}MiB")
        except Exception: pass

    # Données
    train_df = pd.read_csv(args.train, sep="\t")
    eval_df  = pd.read_csv(args.eval,  sep="\t")
    labels = sorted(list(set(train_df["label"].astype(str)) | set(eval_df["label"].astype(str))))
    label2id = {l:i for i,l in enumerate(labels)}; id2label = {i:l for l,i in label2id.items()}
    print(f"[DATA] labels={labels} | n_train={len(train_df)} | n_eval={len(eval_df)}")

    tok = AutoTokenizer.from_pretrained(args.model, use_fast=True)
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model, num_labels=len(labels), id2label=id2label, label2id=label2id
    )
    if args.grad_ckpt and hasattr(model, "gradient_checkpointing_enable"):
        print("[CFG] gradient checkpointing ON")
        model.gradient_checkpointing_enable()

    # class-weights
    counts = train_df["label"].astype(str).value_counts()
    weights = torch.tensor([1.0 / counts.get(id2label[i], 1.0) for i in range(len(labels))], dtype=torch.float)
    weights = (weights / weights.mean()).clamp_(0.25, 4.0)
    print(f"[CFG] class_weights={weights.tolist()}")

    ds_train = TextDS(train_df, tok, label2id, args.max_len)
    ds_eval  = TextDS(eval_df,  tok, label2id, args.max_len)
    coll = DataCollatorWithPadding(tokenizer=tok)

    def metrics(p):
        preds = p.predictions.argmax(-1); gold = p.label_ids
        acc = accuracy_score(gold, preds)
        p_micro = precision_recall_fscore_support(gold, preds, average="micro", zero_division=0)
        p_macro = precision_recall_fscore_support(gold, preds, average="macro", zero_division=0)
        p_weighted = precision_recall_fscore_support(gold, preds, average="weighted", zero_division=0)
        return {"accuracy": acc,
                "precision_micro": p_micro[0], "recall_micro": p_micro[1], "f1_micro": p_micro[2],
                "precision_macro": p_macro[0], "recall_macro": p_macro[1], "f1_macro": p_macro[2],
                "precision_weighted": p_weighted[0], "recall_weighted": p_weighted[1], "f1_weighted": p_weighted[2]}

    # précision (rocm-safe)
    bf16_supported = is_gpu and getattr(torch.cuda, "is_bf16_supported", lambda: False)()
    if args.precision == "bf16":
        bf16, fp16 = True, False
    elif args.precision == "fp16":
        bf16, fp16 = False, True
    elif args.precision == "fp32":
        bf16, fp16 = False, False
    else:
        bf16, fp16 = (bf16_supported, False)
    print(f"[CFG] precision: bf16={bf16} fp16={fp16}")

    args.outdir.mkdir(parents=True, exist_ok=True)
    targs = TrainingArguments(
        output_dir=str(args.outdir / "hf_runs"),
        per_device_train_batch_size=args.batch,
        per_device_eval_batch_size=args.batch,
        dataloader_num_workers=args.workers,
        dataloader_pin_memory=(is_gpu and not args.no_pin_memory),
        dataloader_prefetch_factor=4 if args.workers > 1 else 2,
        gradient_accumulation_steps=max(1, args.accum),
        num_train_epochs=args.epochs,
        eval_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=2,
        learning_rate=args.lr,
        optim="adamw_torch",
        warmup_ratio=0.06,
        load_best_model_at_end=True,
        metric_for_best_model="f1_macro",
        greater_is_better=True,
        logging_strategy="steps",
        logging_steps=100, logging_first_step=True,
        disable_tqdm=False, report_to=[],
        seed=42,
        fp16=fp16, bf16=bf16,
        eval_accumulation_steps=2,
        gradient_checkpointing=args.grad_ckpt,
    )

    print("[RUN] starting training…")
    trainer = WeightedTrainer(
        model=model, args=targs,
        train_dataset=ds_train, eval_dataset=ds_eval,
        processing_class=tok,            # (au lieu de tokenizer=tok)
        data_collator=coll,
        compute_metrics=metrics,
        class_weights=weights
    )
    trainer.train()
    print("[RUN] training done.")

    print("[RUN] evaluating best model…")
    metrics_eval = trainer.evaluate()
    (args.outdir / "metrics.json").write_text(json.dumps(metrics_eval, indent=2), encoding="utf-8")
    print(f"[SAVE] metrics.json -> {args.outdir / 'metrics.json'}")

    preds = trainer.predict(ds_eval); yt = preds.label_ids; yp = preds.predictions.argmax(-1)
    cm = confusion_matrix(yt, yp, labels=list(range(len(labels))))
    cm_png = args.outdir / "confusion_matrix.png"
    plot_cm(cm, [id2label[i] for i in range(len(labels))], cm_png)
    print(f"[SAVE] confusion_matrix.png -> {cm_png}")

    rep_txt = classification_report(yt, yp, target_names=[id2label[i] for i in range(len(labels))])
    (args.outdir / "classification_report.txt").write_text(rep_txt, encoding="utf-8")
    print(f"[SAVE] classification_report.txt -> {args.outdir / 'classification_report.txt'}")

    trainer.save_model(str(args.outdir / "final_model"))
    print(f"[SAVE] final_model -> {args.outdir / 'final_model'}")
    print("[OK] HF done →", args.outdir)

if __name__ == "__main__":
    main()
