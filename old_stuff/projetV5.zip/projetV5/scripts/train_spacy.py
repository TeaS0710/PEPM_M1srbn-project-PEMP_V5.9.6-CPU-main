#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Train spaCy textcat (exclusive multiclass) à partir de DocBin .spacy
- Arch: bow | cnn | trf
- Réglages anti-OOM: batch_size raisonnable, batcher.buffer réduit, tronquage des docs via corpora.*.max_length
- Compatible CPU (par défaut) ; pour GPU AMD/ROCm, utiliser --arch trf (PyTorch gère le device)
"""
from __future__ import annotations
import os, argparse, json
from pathlib import Path

import spacy
from spacy.cli.init_config import init_config
from spacy.cli.train import train as spacy_train

# ---------------------- utils: threads & logs ----------------------
def set_threads(n: int):
    n = max(1, int(n))
    for k in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
        os.environ[k] = str(n)
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    return n

def print_runtime_env(threads: int, gpu_id: int):
    print(f"[SYS] Threads CPU={threads}")
    try:
        import torch
        ok = torch.cuda.is_available()
        names = []
        if ok:
            for i in range(torch.cuda.device_count()):
                nm = torch.cuda.get_device_name(i)
                try:
                    mem = torch.cuda.get_device_properties(i).total_memory/1e9
                    nm = f"{nm} ({mem:.2f}GB)"
                except Exception:
                    pass
                names.append(nm)
        print(f"[SYS] torch={torch.__version__} hip={getattr(torch.version,'hip',None)} cuda_visible={ok} gpus={names}")
    except Exception as e:
        print(f"[SYS] torch non dispo: {e}")
    print(f"[SYS] spaCy={spacy.__version__} | selected device={'CPU' if gpu_id<0 else f'GPU:{gpu_id}'}")

# ---------------------- config patch helpers ----------------------
def disable_static_vectors(cfg: dict) -> dict:
    # Évite les vecteurs statiques qui explosent la RAM et causent des erreurs si absents
    try:
        emb = cfg["components"]["tok2vec"]["model"]["embed"]
        if "include_static_vectors" in emb:
            emb["include_static_vectors"] = False
    except Exception:
        pass
    return cfg

def set_exclusive_on_textcat(cfg: dict) -> dict:
    # Place exclusive_classes au bon niveau selon l’archi
    try:
        model = cfg["components"]["textcat"]["model"]
        arch = model.get("@architectures", "")
        if "TextCatBOW" in arch:
            model["exclusive_classes"] = True
        elif "TextCatEnsemble" in arch and "linear_model" in model:
            model["linear_model"]["exclusive_classes"] = True
    except Exception:
        pass
    return cfg

def set_transformer_name(cfg: dict, hf_name: str) -> dict:
    try:
        cfg["components"]["transformer"]["model"]["name"] = hf_name
    except Exception:
        pass
    return cfg

def ensure_corpora_limits(cfg: dict, train_max_len: int, dev_max_len: int) -> dict:
    # spaCy readers: spacy.Corpus.v1 accepte max_length (tronque les textes trop longs)
    # docs: “Top-level functions → Readers → spacy.Corpus.v1”
    corp = cfg.setdefault("corpora", {})
    for key, lim in (("train", train_max_len), ("dev", dev_max_len)):
        if key not in corp:
            corp[key] = {"@readers": "spacy.Corpus.v1", "path": "${paths.%s}" % key}
        if lim and lim > 0:
            corp[key]["max_length"] = int(lim)
    return cfg

# ---------------------- main ----------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--dev",   type=Path, required=True)
    ap.add_argument("--out",   type=Path, required=True)
    ap.add_argument("--lang",  type=str,  default="fr")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--gpu",   type=int, default=-1, help="-1=CPU, >=0: id GPU (nécessite CuPy si spaCy GPU)")
    ap.add_argument("--seed",  type=int, default=42)

    ap.add_argument("--arch",  choices=["bow","cnn","trf"], default="cnn")
    ap.add_argument("--hf-model", type=str, default="camembert-base")

    # stabilité mémoire
    ap.add_argument("--dropout", type=float, default=0.1)
    ap.add_argument("--accumulate", type=int, default=1)
    ap.add_argument("--eval-freq", type=int, default=300)

    ap.add_argument("--batch-start", type=int, default=64)
    ap.add_argument("--batch-stop",  type=int, default=512)
    ap.add_argument("--batch-buffer", type=int, default=64, help="taille du préfetch (buffer) du batcher")

    ap.add_argument("--nlp-batch-size", type=int, default=64, help="batch logique nlp (contrôle mémoire)")
    ap.add_argument("--train-max-length", type=int, default=1600, help="tronque les docs train trop longs (tokens)")
    ap.add_argument("--dev-max-length",   type=int, default=1600, help="tronque les docs dev trop longs (tokens)")

    ap.add_argument("--threads", type=int, default=max(1, (os.cpu_count() or 2)//2))
    args = ap.parse_args()

    # Threads BLAS/OpenMP
    threads = set_threads(args.threads)
    print_runtime_env(threads, args.gpu)

    # ⚠️ Ne pas faire require_gpu() par défaut (CuPy nécessaire, pas dispo sur AMD/ROCm).
    # Si tu veux forcer (NVIDIA/CuPy), exporte SPACY_FORCE_GPU=1.
    if args.gpu >= 0 and os.getenv("SPACY_FORCE_GPU") == "1":
        try:
            spacy.require_gpu(args.gpu)
            print(f"[INFO] spaCy GPU activé (id={args.gpu}).")
        except Exception as e:
            print("[WARN] Impossible d'activer le GPU spaCy, on reste CPU:", e)

    # 1) auto-config selon arch
    if args.arch == "bow":
        cfg = init_config(lang=args.lang, pipeline=["textcat"], optimize="efficiency")
    elif args.arch == "cnn":
        cfg = init_config(lang=args.lang, pipeline=["textcat"], optimize="accuracy")
        cfg = disable_static_vectors(cfg)
    else:
        try:
            import spacy_transformers  # noqa: F401
        except Exception as e:
            raise SystemExit("[ERR] --arch trf nécessite 'spacy-transformers' installé.") from e
        cfg = init_config(lang=args.lang, pipeline=["transformer","textcat"], optimize="accuracy")
        cfg = set_transformer_name(cfg, args.hf_model)

    # 2) hyperparams & batcher
    cfg["nlp"]["lang"] = args.lang
    cfg["nlp"]["batch_size"] = int(args.nlp_batch_size)  # clé valide (contrôle mémoire)
    cfg["training"]["max_epochs"] = int(args.epochs)
    cfg["training"]["seed"] = int(args.seed)
    cfg["training"]["dropout"] = float(args.dropout)
    cfg["training"]["accumulate_gradient"] = max(1, int(args.accumulate))
    cfg["training"]["eval_frequency"] = max(50, int(args.eval_freq))

    # batcher officiel + buffer réduit (réduit RAM) — docs “Batchers”
    cfg["training"]["batcher"] = {
        "@batchers": "spacy.batch_by_padded.v1",
        "discard_oversize": True,
        "buffer": int(args.batch_buffer),
        "size": {
            "@schedules": "compounding.v1",
            "start": int(args.batch_start),
            "stop": int(args.batch_stop),
            "compound": 1.001
        }
    }

    # 3) textcat exclusif
    cfg = set_exclusive_on_textcat(cfg)

    # 4) chemins & corpora (tronquage max_length pour protéger la RAM) — docs “Readers”
    cfg.setdefault("paths", {})
    cfg["paths"]["train"] = str(args.train)
    cfg["paths"]["dev"]   = str(args.dev)
    cfg = ensure_corpora_limits(cfg, args.train_max_length, args.dev_max_length)

    # pas de vecteurs nécessaires
    cfg.setdefault("initialize", {})
    cfg["paths"]["vectors"] = None
    cfg["initialize"]["vectors"] = None

    # logger verbeux
    cfg["training"]["logger"] = {
        "@loggers": "spacy.ConsoleLogger.v1",
        "progress_bar": True
    }

    # 5) sauvegarde + train
    args.out.mkdir(parents=True, exist_ok=True)
    cfg_path = args.out / "auto_config.cfg"
    cfg.to_disk(cfg_path)
    print("[CONFIG] training.batcher:", json.dumps(cfg["training"]["batcher"], indent=2))
    print(f"[INFO] Config écrite → {cfg_path}")
    print("[INFO] Démarrage de l'entraînement spaCy…")

    spacy_train(
        config_path=str(cfg_path),
        output_path=str(args.out),
        overrides={},        # ne pas injecter d'overrides ici
        use_gpu=args.gpu     # -1 = CPU ; >=0 tente GPU (nécessite CuPy côté spaCy)
    )
    print("[OK] Entraînement terminé. Modèle →", args.out / "model-best")


if __name__ == "__main__":
    main()
