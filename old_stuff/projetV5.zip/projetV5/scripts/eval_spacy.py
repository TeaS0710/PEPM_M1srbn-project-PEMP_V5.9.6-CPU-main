#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eval_spacy_plus.py  (verbeux + Matplotlib 3.9+ safe)
- Évalue un modèle spaCy (model-best) sur un DocBin .spacy (job)
- Génère: metrics.json, classification_report.txt, confusion_matrix*.png, per_class_metrics.csv,
          probs_hist.png, confidence_boxplot.png, lengths_*png, roc_micro.png, pr_micro.png,
          scatter_*png, confusion.csv, misclassified.tsv
- Logs console détaillés pour chaque étape + récap final des sorties.
"""
from __future__ import annotations
import argparse, json, os, csv, time, sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import List, Dict, Optional, Tuple

import numpy as np
import pandas as pd
import spacy
from spacy.tokens import DocBin

from sklearn.metrics import (
    accuracy_score, precision_recall_fscore_support,
    classification_report, confusion_matrix, roc_curve, auc,
    precision_recall_curve
)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans

# matplotlib headless
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---------- utils console ----------
def log(msg: str):
    print(f"[eval_spacy_plus] {msg}", flush=True)

def tic():
    return time.perf_counter()

def toc(t0, label=""):
    dt = time.perf_counter() - t0
    log(f"{label}done in {dt:.2f}s")
    return dt

# ---------- utils graphiques ----------
def _autosize_fig_for_labels(n: int, base=(6,5), step=0.35) -> Tuple[float, float]:
    return (max(base[0], base[0] + step * max(0, n-10)),
            max(base[1], base[1] + step * max(0, n-10)))

def _savefig(fig, out_png: Path):
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=200, bbox_inches='tight')
    plt.close(fig)
    log(f"  └─ saved: {out_png}")

def plot_confusion(cm, labels, out_png, title="Confusion"):
    fig, ax = plt.subplots(figsize=(max(6, 0.6*len(labels)), max(5, 0.6*len(labels))))
    im = ax.imshow(cm, interpolation='nearest')
    ax.figure.colorbar(im, ax=ax)
    ax.set(xticks=np.arange(cm.shape[1]), yticks=np.arange(cm.shape[0]),
           xticklabels=labels, yticklabels=labels, ylabel='True', xlabel='Pred', title=title)
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right', rotation_mode='anchor')
    is_float = np.issubdtype(np.asarray(cm).dtype, np.floating)
    # Evite surcharge de texte sur grosses matrices
    if cm.size <= 2500:
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                txt = f"{cm[i,j]:.2f}" if is_float else f"{int(cm[i,j])}"
                ax.text(j, i, txt, ha='center', va='center', fontsize=8)
    fig.tight_layout()
    _savefig(fig, out_png)

def plot_confusion_norm(cm, labels, out_png):
    cmn = cm.astype('float')
    row_sum = cmn.sum(axis=1, keepdims=True) + 1e-12
    cmn = cmn / row_sum
    plot_confusion(cmn, labels, out_png, title="Confusion (normalisee par ligne)")

def bar_per_class_metrics(per_class_df: pd.DataFrame, out_png: Path):
    lablist = per_class_df["label"].tolist()
    w, h = _autosize_fig_for_labels(len(lablist))
    fig, ax = plt.subplots(figsize=(w, h))
    x = np.arange(len(lablist))
    width = 0.28
    ax.bar(x - width, per_class_df["precision"], width, label="precision")
    ax.bar(x,          per_class_df["recall"],    width, label="recall")
    ax.bar(x + width,  per_class_df["f1"],        width, label="f1")
    ax.set_xticks(x)
    ax.set_xticklabels(lablist, rotation=45, ha='right')
    ax.set_ylabel("score")
    ax.set_title("Scores par classe")
    ax.legend()
    fig.tight_layout()
    _savefig(fig, out_png)

def hist_probs(conf_correct: np.ndarray, conf_wrong: np.ndarray, out_png: Path):
    fig, ax = plt.subplots(figsize=(7,5))
    ax.hist(conf_correct, bins=30, alpha=0.7, label="correct", density=True)
    ax.hist(conf_wrong,   bins=30, alpha=0.7, label="faux",    density=True)
    ax.set_xlabel("proba du label predit")
    ax.set_ylabel("densite")
    ax.set_title("Distribution des confiances")
    ax.legend()
    fig.tight_layout()
    _savefig(fig, out_png)

def boxplot_confidence(conf_correct: np.ndarray, conf_wrong: np.ndarray, out_png: Path):
    fig, ax = plt.subplots(figsize=(6,5))
    bp = ax.boxplot([conf_correct, conf_wrong], showfliers=False)
    ax.set_xticks([1, 2], ["correct", "faux"])
    ax.set_ylabel("proba du label predit")
    ax.set_title("Boites a moustaches des confiances")
    fig.tight_layout()
    _savefig(fig, out_png)

def lengths_plots(df_len: pd.DataFrame, out_hist: Path, out_box: Path, by="gold"):
    # Histogramme global
    fig, ax = plt.subplots(figsize=(7,5))
    ax.hist(df_len["tokens"], bins=40, alpha=0.8)
    ax.set_title("Distribution des longueurs (tokens)")
    ax.set_xlabel("tokens"); ax.set_ylabel("freq")
    fig.tight_layout()
    _savefig(fig, out_hist)

    # Boxplots par classe
    by_labels = sorted(df_len[by].unique().tolist())
    w, h = _autosize_fig_for_labels(len(by_labels), base=(9,5), step=0.25)
    fig, ax = plt.subplots(figsize=(w,h))
    data = [df_len.loc[df_len[by]==lab, "tokens"].to_numpy() for lab in by_labels]
    ax.boxplot(data, showfliers=False)
    ax.set_xticks(range(1, len(by_labels)+1))
    ax.set_xticklabels(by_labels, rotation=45, ha='right')
    ax.set_title(f"Longueurs (tokens) par classe [{by}]")
    ax.set_ylabel("tokens")
    fig.tight_layout()
    _savefig(fig, out_box)

def plot_roc_pr_micro(y_true_bin: np.ndarray, y_score: np.ndarray, out_roc: Path, out_pr: Path):
    # ROC micro
    fpr, tpr, _ = roc_curve(y_true_bin.ravel(), y_score.ravel())
    roc_auc = auc(fpr, tpr)
    fig, ax = plt.subplots(figsize=(6,5))
    ax.plot(fpr, tpr, label=f"micro-avg ROC (AUC={roc_auc:.3f})")
    ax.plot([0,1],[0,1],'--', lw=1, color='gray')
    ax.set_xlabel("FPR"); ax.set_ylabel("TPR")
    ax.set_title("ROC micro-average")
    ax.legend()
    fig.tight_layout()
    _savefig(fig, out_roc)

    # PR micro
    prec, rec, _ = precision_recall_curve(y_true_bin.ravel(), y_score.ravel())
    ap = auc(rec, prec)
    fig, ax = plt.subplots(figsize=(6,5))
    ax.plot(rec, prec, label=f"micro-avg PR (AP={ap:.3f})")
    ax.set_xlabel("Recall"); ax.set_ylabel("Precision")
    ax.set_title("Precision-Recall micro-average")
    ax.legend()
    fig.tight_layout()
    _savefig(fig, out_pr)

def scatter_2d(X2d: np.ndarray, colors: List[str], _labels_legend: List[str], title: str, out_png: Path, alpha=0.6, size=10):
    fig, ax = plt.subplots(figsize=(7,6))
    uniq = sorted(set(colors), key=lambda z: z)
    for u in uniq:
        idx = [i for i,c in enumerate(colors) if c == u]
        ax.scatter(X2d[idx,0], X2d[idx,1], s=size, alpha=alpha, label=str(u))
    ax.set_title(title)
    ax.legend(markerscale=2, frameon=True, fontsize=8)
    ax.set_xticks([]); ax.set_yticks([])
    fig.tight_layout()
    _savefig(fig, out_png)

# ---------- réduction dimensionnelle ----------
def project_texts_2d(texts: List[str], max_points=5000, random_state=42) -> Tuple[np.ndarray, List[int]]:
    """TF-IDF -> (optionnel) SVD(<=50) -> UMAP/TSNE, sur échantillon si besoin."""
    n = len(texts)
    if n == 0:
        return np.zeros((0,2)), []

    if n > max_points:
        rng = np.random.default_rng(random_state)
        idx = sorted(rng.choice(n, size=max_points, replace=False).tolist())
    else:
        idx = list(range(n))
    sample_texts = [texts[i] for i in idx]

    tfidf = TfidfVectorizer(
        max_features=20000, lowercase=True, strip_accents="unicode",
        ngram_range=(1,2), min_df=2
    )
    X = tfidf.fit_transform(sample_texts)

    n_features = X.shape[1]
    if n_features >= 3:
        n_comp = min(50, n_features - 1)
        X_red = TruncatedSVD(n_components=n_comp, random_state=random_state).fit_transform(X)
    else:
        X_red = X.toarray()

    try:
        import umap  # type: ignore
        reducer = umap.UMAP(n_components=2, n_neighbors=30, min_dist=0.1, random_state=random_state)
        X2 = reducer.fit_transform(X_red)
    except Exception:
        perplex = min(30, max(5, len(idx)//50))
        X2 = TSNE(n_components=2, learning_rate="auto", init="pca",
                  perplexity=perplex, random_state=random_state).fit_transform(X_red)
    return X2, idx

# ---------- lecture mapping ideologique (optionnel) ----------
def load_ideology_map(path: Optional[Path]) -> Optional[Dict[str,str]]:
    if not path:
        return None
    try:
        if path.suffix.lower() in (".yml",".yaml"):
            import yaml  # PyYAML
            d = yaml.safe_load(path.read_text(encoding="utf-8"))
        else:
            d = json.loads(path.read_text(encoding="utf-8"))
        return {str(k): str(v) for k,v in d.items()}
    except Exception as e:
        log(f"[WARN] ideology-map illisible: {e}")
        return None

# ---------- programme principal ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, required=True, help="dossier contenant model-best")
    ap.add_argument("--job",   type=Path, required=True, help="DocBin .spacy (job)")
    ap.add_argument("--labels", type=Path, required=True, help="labels.json (ordre des labels)")
    ap.add_argument("--workers", type=int, default=max(1, os.cpu_count() or 2))
    ap.add_argument("--outdir", type=Path, default=Path("eval_out"))
    ap.add_argument("--max-points", type=int, default=5000, help="échantillon max pour scatter 2D")
    ap.add_argument("--random-state", type=int, default=42)
    ap.add_argument("--ideology-map", type=Path, default=None, help="YAML/JSON {label: left|right|other}")
    ap.add_argument("--progress-every", type=int, default=200, help="fallback progrès (si tqdm indisponible)")
    args = ap.parse_args()

    t0_all = tic()
    args.outdir.mkdir(parents=True, exist_ok=True)
    labels: List[str] = json.loads(Path(args.labels).read_text(encoding="utf-8"))
    lab2id = {l:i for i,l in enumerate(labels)}

    # 1) charge le modèle & job
    log(f"Loading model: {args.model / 'model-best'}")
    nlp = spacy.load(str(args.model / "model-best"))
    log(f"Reading DocBin job: {args.job}")
    t0 = tic()
    gold_docs = list(DocBin().from_disk(args.job).get_docs(nlp.vocab))
    toc(t0, "  ")

    n_docs = len(gold_docs)
    log(f"Docs in job: {n_docs}")
    # stats classes gold (si dispo dans DocBin)
    try:
        gold_counts = Counter(max(d.cats.items(), key=lambda kv: kv[1])[0] for d in gold_docs)
        log("Gold label distribution:")
        for lab in labels:
            log(f"  - {lab:>24s}: {gold_counts.get(lab,0)}")
    except Exception:
        pass

    # 2) extractions de base
    log("Extracting gold labels, texts & lengths…")
    t0 = tic()
    gold_labels: List[str] = []
    texts: List[str] = []
    lens_tokens: List[int] = []
    lens_chars: List[int] = []
    for d in gold_docs:
        gold = max(d.cats.items(), key=lambda kv: kv[1])[0]
        gold_labels.append(gold)
        texts.append(d.text)
        lens_tokens.append(len(d))
        lens_chars.append(len(d.text))
    toc(t0, "  ")

    # 3) prédictions + scores
    log(f"Predicting with spaCy.pipe (workers={args.workers}, batch=256)…")
    t0 = tic()
    pred_labels: List[str] = []
    pred_max_scores: List[float] = []
    pred_all_scores: List[Dict[str,float]] = []

    # tqdm si dispo
    use_tqdm = False
    try:
        from tqdm import tqdm  # type: ignore
        iterator = tqdm(nlp.pipe(texts, n_process=args.workers, batch_size=256), total=n_docs)
        use_tqdm = True
    except Exception:
        iterator = nlp.pipe(texts, n_process=args.workers, batch_size=256)

    for i, doc in enumerate(iterator, 1):
        cats = dict(doc.cats)
        pred, score = max(cats.items(), key=lambda kv: kv[1])
        pred_labels.append(pred)
        pred_max_scores.append(float(score))
        pred_all_scores.append({lab: float(cats.get(lab, 0.0)) for lab in labels})
        if not use_tqdm and (i % max(1, args.progress_every) == 0):
            log(f"  …{i}/{n_docs} docs")

    toc(t0, "  ")

    # 4) encodage numeric + masquage labels inconnus
    log("Encoding labels & aligning scores…")
    yt = np.array([lab2id.get(l, -1) for l in gold_labels])
    yp = np.array([lab2id.get(l, -1) for l in pred_labels])
    mask = (yt >= 0) & (yp >= 0)
    yt, yp = yt[mask], yp[mask]
    if len(yt) != n_docs:
        log(f"[WARN] {n_docs - len(yt)} samples filtered due to unknown labels")

    Y_true = np.zeros((len(yt), len(labels)), dtype=np.float32)
    for i, c in enumerate(yt):
        Y_true[i, c] = 1.0
    Y_score = np.zeros_like(Y_true)
    pred_all_scores_np = np.array(pred_all_scores, dtype=object)[mask]
    for i, dct in enumerate(pred_all_scores_np):
        for j, lab in enumerate(labels):
            Y_score[i,j] = float(dct.get(lab, 0.0))

    # 5) métriques
    log("Computing metrics…")
    acc = accuracy_score(yt, yp)
    p_micro = precision_recall_fscore_support(yt, yp, average='micro', zero_division=0)
    p_macro = precision_recall_fscore_support(yt, yp, average='macro', zero_division=0)
    p_weighted = precision_recall_fscore_support(yt, yp, average='weighted', zero_division=0)
    metrics = {
        "accuracy": acc,
        "precision_micro": p_micro[0], "recall_micro": p_micro[1], "f1_micro": p_micro[2],
        "precision_macro": p_macro[0], "recall_macro": p_macro[1], "f1_macro": p_macro[2],
        "precision_weighted": p_weighted[0], "recall_weighted": p_weighted[1], "f1_weighted": p_weighted[2],
        "n_docs": int(n_docs)
    }
    (args.outdir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    log(f"  accuracy={acc:.4f} | f1_macro={p_macro[2]:.4f} | f1_weighted={p_weighted[2]:.4f}")

    log("Writing classification report & per-class metrics…")
    report_txt = classification_report(
        yt, yp, labels=list(range(len(labels))), target_names=labels, zero_division=0
    )
    (args.outdir / "classification_report.txt").write_text(report_txt, encoding="utf-8")

    prec, rec, f1, support = precision_recall_fscore_support(
        yt, yp, average=None, zero_division=0, labels=list(range(len(labels)))
    )
    per_class_df = pd.DataFrame({
        "label": labels, "precision": prec, "recall": rec, "f1": f1, "support": support
    })
    per_class_df.to_csv(args.outdir / "per_class_metrics.csv", index=False)
    # Affiche les 5 plus faibles recalls pour debug terrain
    low_recall = per_class_df.sort_values("recall", ascending=True).head(5)
    log("  lowest recalls (top-5):")
    for _, r in low_recall.iterrows():
        log(f"    {r['label']:>24s}  recall={r['recall']:.3f}  support={int(r['support'])}")

    # 6) matrices de confusion
    log("Building confusion matrices & plots…")
    cm = confusion_matrix(yt, yp, labels=list(range(len(labels))))
    pd.DataFrame(cm, index=labels, columns=labels).to_csv(args.outdir / "confusion.csv")
    plot_confusion(cm, labels, args.outdir / "confusion_matrix.png")
    plot_confusion_norm(cm, labels, args.outdir / "confusion_matrix_norm.png")

    # 7) confiances
    log("Plotting confidence histograms/boxplots…")
    conf = np.array(pred_max_scores)[mask]
    correct_mask = (yt == yp)
    hist_probs(conf[correct_mask], conf[~correct_mask], args.outdir / "probs_hist.png")
    boxplot_confidence(conf[correct_mask], conf[~correct_mask], args.outdir / "confidence_boxplot.png")

    # 8) longueurs
    log("Plotting lengths hist/boxplots…")
    df_len = pd.DataFrame({
        "gold": np.array(gold_labels)[mask],
        "pred": np.array(pred_labels)[mask],
        "tokens": np.array(lens_tokens)[mask],
        "chars": np.array(lens_chars)[mask],
        "conf": conf
    })
    lengths_plots(df_len, args.outdir / "lengths_hist.png", args.outdir / "lengths_boxplot_gold.png", by="gold")
    lengths_plots(df_len, args.outdir / "lengths_hist_pred.png", args.outdir / "lengths_boxplot_pred.png", by="pred")

    # 9) ROC/PR micro-average
    log("Computing ROC/PR micro-average…")
    try:
        plot_roc_pr_micro(Y_true, Y_score, args.outdir / "roc_micro.png", args.outdir / "pr_micro.png")
    except Exception as e:
        log(f"[WARN] ROC/PR micro impossible: {e}")

    # 10) Nuages de points 2D
    log("Projecting texts to 2D (TF-IDF -> SVD -> UMAP/TSNE)…")
    try:
        X2d, idx = project_texts_2d(list(np.array(texts)[mask]), max_points=args.max_points, random_state=args.random_state)
        if len(idx) > 0:
            colors_gold = list(np.array(np.array(gold_labels)[mask])[idx])
            scatter_2d(X2d, colors_gold, labels, "Projection 2D (gold)", args.outdir / "scatter_2d_gold.png", alpha=0.6, size=9)
            colors_pred = list(np.array(np.array(pred_labels)[mask])[idx])
            scatter_2d(X2d, colors_pred, labels, "Projection 2D (pred)", args.outdir / "scatter_2d_pred.png", alpha=0.6, size=9)
            if len(idx) >= 2:
                kmeans = KMeans(n_clusters=2, n_init=10, random_state=args.random_state)
                cl = kmeans.fit_predict(X2d)
                colors_k2 = [f"cluster{c}" for c in cl]
                scatter_2d(X2d, colors_k2, ["cluster0","cluster1"], "Clusters k=2 (indicatif)", args.outdir / "scatter_clusters_k2.png", alpha=0.6, size=9)
    except Exception as e:
        log(f"[WARN] Scatter 2D indisponible: {e}")

    # 11) Projection blocs idéologiques (optionnel)
    ideomap = load_ideology_map(args.ideology_map)
    if ideomap:
        log("Projecting blocks (ideology-map)…")
        try:
            gold_blocks = [ideomap.get(lbl, "other") for lbl in np.array(gold_labels)[mask]]
            if 'X2d' not in locals():
                X2d, idx = project_texts_2d(list(np.array(texts)[mask]), max_points=args.max_points, random_state=args.random_state)
            if len(idx) > 0:
                blocks_sub = list(np.array(gold_blocks)[idx])
                scatter_2d(X2d, blocks_sub, sorted(set(blocks_sub)), "Projection 2D - blocs ideologiques (gold)", args.outdir / "scatter_left_right.png", alpha=0.7, size=11)
        except Exception as e:
            log(f"[WARN] Scatter blocs ideologiques impossible: {e}")

    # 12) erreurs marquantes
    log("Writing top misclassified (most confident errors)…")
    try:
        rows = []
        gold_arr = np.array(gold_labels)[mask]
        pred_arr = np.array(pred_labels)[mask]
        texts_arr = np.array(texts)[mask]
        conf_arr = conf
        wrong_idx = np.where(gold_arr != pred_arr)[0]
        if wrong_idx.size > 0:
            order = wrong_idx[np.argsort(-conf_arr[wrong_idx])]
            top = order[: min(500, order.size)]
            for i in top:
                rows.append({
                    "gold": gold_arr[i],
                    "pred": pred_arr[i],
                    "conf_pred": f"{conf_arr[i]:.4f}",
                    "tokens": int(df_len.iloc[i]["tokens"]),
                    "chars":  int(df_len.iloc[i]["chars"]),
                    "text": texts_arr[i].replace("\t"," ").replace("\n"," ")
                })
        with (args.outdir / "misclassified.tsv").open("w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["gold","pred","conf_pred","tokens","chars","text"], delimiter="\t")
            w.writeheader()
            for r in rows:
                w.writerow(r)
        log(f"  └─ saved: {args.outdir / 'misclassified.tsv'}  (rows={len(rows)})")
    except Exception as e:
        log(f"[WARN] Ecriture des erreurs impossible: {e}")

    # 13) barres per-class
    log("Plotting per-class bars…")
    try:
        bar_per_class_metrics(per_class_df, args.outdir / "per_class_bars.png")
    except Exception as e:
        log(f"[WARN] Barres per-class impossible: {e}")

    # 14) inventaire final
    produced = [
        "metrics.json",
        "classification_report.txt",
        "per_class_metrics.csv",
        "confusion.csv",
        "confusion_matrix.png",
        "confusion_matrix_norm.png",
        "probs_hist.png",
        "confidence_boxplot.png",
        "lengths_hist.png",
        "lengths_boxplot_gold.png",
        "lengths_hist_pred.png",
        "lengths_boxplot_pred.png",
        "roc_micro.png",
        "pr_micro.png",
        "scatter_2d_gold.png",
        "scatter_2d_pred.png",
        "scatter_clusters_k2.png",
        "scatter_left_right.png",
        "misclassified.tsv",
    ]
    log("Generated files:")
    for name in produced:
        p = args.outdir / name
        if p.exists():
            log(f"  - {p}")
    toc(t0_all, "All steps ")

    # résumé court console
    log(f"SUMMARY: accuracy={metrics['accuracy']:.4f}  f1_macro={metrics['f1_macro']:.4f}  "
        f"f1_weighted={metrics['f1_weighted']:.4f}  (n={metrics['n_docs']})")
    log(f"Outputs in: {args.outdir}")

if __name__ == "__main__":
    main()
